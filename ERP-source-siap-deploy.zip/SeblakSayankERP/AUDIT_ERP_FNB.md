# Evaluasi ERP F&B 2.22 (catatan historis)

Audit implementasi dan pengujian lokal pada 29 Oktober 2026. Ini bukan audit akuntansi, sertifikasi keamanan, atau pengujian semua kondisi perangkat/format POS.

## Perbaikan yang diterapkan

| Area | Temuan | Hasil |
|---|---|---|
| Identitas | Nama Seblak tetap pada login, breadcrumb, dashboard/admin | Nama usaha mengikuti Pengaturan; fallback dan instalasi baru netral |
| Unit produk | Semua unit utama bergantung kata seblak | Jenis per menu: utama/tambahan/lainnya, atau kata kunci yang dapat diatur |
| Riwayat POS | Risiko aturan baru mengubah unit historis | Snapshot klasifikasi untuk impor baru; snapshot lama memakai aturan legacy |
| Pembayaran | Non Tunai selalu dianggap QRIS | Pengaturan non-tunai umum/QRIS/transfer, metode eksplisit tetap dibaca |
| Ringkasan pembayaran | Hanya Tunai/QRIS terlihat | Tampilkan juga Transfer, Non-tunai umum dan Belum diketahui |
| HPP | Transaksi item biasa mengabaikan override kanal | Override ShopeeFood/GrabFood/GoFood dipakai, mutasi stok tetap dari resep |
| Laba | HPP nol diperbolehkan tetapi mudah terlewat | Peringatan laporan untuk penjualan berpendapatan dengan total HPP Rp0 |
| Cabang/admin | Form admin relasi tidak memakai pembatas cabang aplikasi | Form employee/attendance/product/recipe memakai form scoped |
| Instalasi | Database bawaan berisiko tertimpa saat ekstrak | ZIP kode tanpa database/akun; BAT migrasi dan minta admin bila belum ada |
| Kunci sesi | Kunci development sama dalam kode | Kunci unik lokal yang persisten atau ERP_SECRET_KEY dari lingkungan |
| PDF | Identitas dan potongan kurang jelas | Nama usaha dinamis, potongan bertanda minus, layout modern dipertahankan |

## Verifikasi

132 pengujian unik lulus (suite 131 dan pengujian tambahan pembatas admin), diikuti pemeriksaan sistem dan konsistensi migrasi.

- Suite otomatis mencakup payroll harian/bulanan/rentang tanggal, overlap, bonus, potongan, preview/PDF/layout, absensi, lama kerja, stok/reversal, rekap, CSV/PDF/XLSX, kategori, impor antarcabang, laporan, dashboard, pembatas cabang serta mata uang.
- Skenario kedai kopi: Kopi Susu utama, Extra Shot tambahan, Botol lainnya; tidak perlu kata seblak. Klasifikasi snapshot tidak berubah saat jenis/aturan kemudian diedit.
- Skenario kata kunci khusus dan Non Tunai umum/QRIS/transfer diuji.
- Migrasi salinan database pengguna: 2 karyawan, 12 absensi, 1 payroll, 4 penjualan tetap; nama usaha dan aturan legacy dipertahankan; foreign_key_check bersih.
- Migrasi database kosong: Usaha F&B, Cabang Utama, mode jenis item, Non Tunai umum, tidak ada akun bawaan.
- PDF dengan nama usaha lain dirender dan diperiksa visual. Rendering HTML diuji melalui Django; browser interaktif dan Windows asli belum diuji di lingkungan ini.
- Django check dan pemeriksaan migrasi bersih. Check --deploy masih memberi peringatan HTTPS/cookie aman/HSTS/DEBUG untuk konfigurasi lokal.

## Batasan yang masih berlaku

1. Satu usaha per database. Identitas usaha, layout slip, aturan POS dan persentase HPP impor digunakan bersama semua cabang. Semua akun operasional dapat mengakses cabang; belum ada isolasi perusahaan atau izin kasir per modul/cabang. Usaha milik orang lain harus memakai database dan instalasi terpisah.
2. Paket untuk komputer lokal. Belum siap publik: perlu server produksi, HTTPS, pengelolaan akun/izin, backup dan konfigurasi deployment. Runserver bukan server produksi. Kunci lokal perlu tetap disimpan; pindah folder dapat membatalkan sesi lama.
3. XLSX hanya format Riwayat Penjualan yang didukung; satu tanggal/outlet/kanal, tanpa campuran/refund/ekstra tersembunyi. Format POS lain perlu adapter. Settlement online tidak memberikan porsi/menu jika tidak ada rincian item.
4. Impor rekap tidak mengurangi stok otomatis. Penjualan item internal memiliki mutasi resep. Jangan menggabungkan kedua alur untuk omzet yang sama. Opname memperbaiki posisi fisik; nilai stok laporan adalah saat ini, bukan rekonstruksi stok historis.
5. Porsi berarti jumlah unit produk utama, bukan pelanggan unik atau selalu satu piring. Semua item termasuk tambahan/lainnya tetap masuk omzet dan HPP. Akurasi bergantung klasifikasi dan mapping pengguna.
6. Non-tunai umum bukan bukti QRIS. Tidak ada biaya MDR otomatis, rekonsiliasi bank, saldo kas/laci, buku piutang atau jurnal berpasangan.
7. Laporan laba operasional, bukan arus kas atau laporan akuntansi lengkap. Tidak memodelkan pajak/penyusutan/modal/utang. HPP estimasi/0/parsial dapat membuat laba berbeda dari aktual. Opname tidak dibebankan pada periode dengan rekap untuk mencegah biaya ganda sesuai kebijakan sebelumnya.
8. Payroll dibukukan pada bulan/tanggal akhir periode, bukan dialokasikan setiap hari atau saat kas dibayarkan. Gaji pokok bulanan tetap dibulatkan naik ke ribuan sesuai kebijakan sebelumnya; belum ada aturan lembur/pajak/BPJS. Absensi cabang bertugas tidak memindahkan beban gaji dari cabang asal.
9. Mengedit resep, biaya, jenis item atau aturan tidak mengubah snapshot impor/payroll lama. Koreksi HPP impor lama belum memiliki alur revisi lengkap; jangan mengimpor ulang file untuk menggandakan omzet. Lengkapi pembayaran hanya pada file identik yang belum menyimpan rinciannya.
10. Masa kerja dan ringkasan absensi nonaktif masih berbasis tanggal mulai sampai hari ini karena tanggal berhenti belum dimodelkan. Hari kosong bukan otomatis absen.

## Kebijakan data

Tidak menghapus/mengganti database pengguna. Upgrade membuat backup sebelum migrasi. Data QA tidak dimasukkan ke ZIP. Instalasi kosong hanya seed pengaturan netral, cabang dan kanal standar; pengguna membuat akun sendiri. Nama kanal standar Offline/ShopeeFood/GrabFood/GoFood dipakai adapter dan analisis platform; pertahankan namanya agar integrasi tetap cocok.

## Pembaruan 2.26

Potongan absensi otomatis kini tersedia per cabang; snapshot kebijakan menjaga slip lama, penghitungan ulang terbaru perlu opsi eksplisit. Cabang kerja pada slip disimpan per periode. Rincian terbaru dan verifikasi 145 pengujian dijelaskan pada README versi 2.26.
