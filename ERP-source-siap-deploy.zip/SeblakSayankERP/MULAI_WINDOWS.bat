@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    py -m venv .venv
    if errorlevel 1 goto error
)
rem Pulihkan pip pada virtual environment yang belum lengkap.
".venv\Scripts\python.exe" -m pip --version >nul 2>&1
if errorlevel 1 (
    echo Menyiapkan pip pada virtual environment...
    ".venv\Scripts\python.exe" -m ensurepip --upgrade
    if errorlevel 1 goto pip_error
)
".venv\Scripts\python.exe" -m pip --version >nul 2>&1
if errorlevel 1 goto pip_error
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto error
".venv\Scripts\python.exe" manage.py upgrade_erp
if errorlevel 1 goto error
".venv\Scripts\python.exe" manage.py ensure_admin
if errorlevel 1 goto error
echo.
echo Buka http://127.0.0.1:8000 di browser.
echo Jika belum punya akun, buka terminal lain dan jalankan:
echo .venv\Scripts\python.exe manage.py createsuperuser
echo.
".venv\Scripts\python.exe" manage.py runserver
pause
exit /b 0
:pip_error
echo.
echo Pip belum berhasil dipulihkan. Tutup jendela ini.
echo Ubah nama folder .venv menjadi .venv_lama, lalu jalankan BAT ini lagi.
echo Jangan mengubah atau menghapus db.sqlite3.
pause
exit /b 1
:error
echo.
echo Ada kendala. Periksa pesan di atas. Jangan hapus database lama.
pause
exit /b 1
