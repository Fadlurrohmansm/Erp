export default {
  async fetch(request, env) {
    if (!env.ERP_ORIGIN) return new Response("ERP_ORIGIN belum dikonfigurasi.", { status: 503 });
    let backend;
    try { backend = new URL(env.ERP_ORIGIN); }
    catch { return new Response("ERP_ORIGIN tidak valid.", { status: 503 }); }
    if (backend.protocol !== "https:") return new Response("ERP_ORIGIN harus menggunakan HTTPS.", { status: 503 });

    const incoming = new URL(request.url);
    const target = new URL(incoming.pathname + incoming.search, backend);
    const headers = new Headers(request.headers);
    headers.delete("host");
    headers.set("x-forwarded-host", incoming.host);
    headers.set("x-forwarded-proto", incoming.protocol.slice(0, -1));
    const upstreamRequest = new Request(target, {
      method: request.method,
      headers,
      body: request.method === "GET" || request.method === "HEAD" ? null : request.body,
      redirect: "manual",
    });
    const response = await fetch(upstreamRequest);
    const location = response.headers.get("location");
    if (location) {
      try {
        const redirectUrl = new URL(location, backend);
        if (redirectUrl.origin === backend.origin) {
          const responseHeaders = new Headers(response.headers);
          responseHeaders.set("location", `${incoming.origin}${redirectUrl.pathname}${redirectUrl.search}${redirectUrl.hash}`);
          return new Response(response.body, { status: response.status, statusText: response.statusText, headers: responseHeaders });
        }
      } catch { /* Preserve non-URL Location values. */ }
    }
    return response;
  },
};
