# ERP F&B — versi 2.52

Untuk warung makan, kedai kopi, minuman, bakery, dan usaha makanan/minuman lain. Satu database untuk satu usaha dengan beberapa cabang. Paket ini tidak menyertakan database atau akun pelanggan. Catatan versi lama di bawah menjelaskan riwayat fitur; panduan versi 2.22 berikut adalah acuan konfigurasi F&B umum.

Modul Manajemen HPP tersedia dari sidebar. Lihat [Panduan Smart HPP](PANDUAN_HPP.md) untuk pemasangan, costing, dan batas data historis.

## Memulai usaha lain

1. Ekstrak ke folder baru. Jangan menyalin database usaha lain.
2. Instal Python 3.12, jalankan MULAI_WINDOWS.bat. Database baru dibuat otomatis dan akun administrator diminta bila belum ada.
3. Pengaturan usaha: isi nama, tagline, alamat, telepon, aturan unit POS, arti Non Tunai, dan tarif platform sesuai usaha sendiri.
4. Edit nama Cabang Utama; tambah bahan, kategori, menu dan resep.
5. Pada menu tentukan jenis item: Produk utama / porsi, Tambahan / add-on, atau Lainnya. Kopi/minuman dapat dihitung sebagai unit produk utama; topping/sirup sebagai tambahan.
6. Gunakan mode Jenis item pada menu ERP untuk usaha dengan banyak produk. Mode Kata kunci tersedia untuk kebutuhan khusus; isi kata kunci dipisah koma.
7. Impor POS memakai format Riwayat Penjualan yang didukung; lihat pratinjau dan cocokkan setiap menu sebelum simpan. Sistem ini belum membaca setiap format POS secara otomatis.

## Memperbarui instalasi yang sudah dipakai

Cadangkan db.sqlite3 terbaru, hentikan server, gunakan folder kode baru bersama database tersebut, lalu jalankan MULAI_WINDOWS.bat. Jangan memakai database QA/demo. Nama usaha dan cabang yang sudah digunakan tetap dipertahankan. Instalasi Seblak lama mempertahankan mode kata kunci seblak dan Non Tunai = QRIS; untuk usaha lain ubah melalui Pengaturan. Jenis produk lama dipetakan ke utama bila namanya mengandung seblak, sisanya tambahan, agar peralihan awal konsisten. Tinjau sebelum beralih ke mode Jenis item. Riwayat POS menyimpan klasifikasi saat impor; mengubah aturan/menu tidak menghitung ulang angka lama.

Kunci sesi lokal sekarang berbeda per instalasi dan disimpan dalam .erp_secret_key di folder aplikasi. Akun/password tetap pada database, tetapi sesi lama dapat perlu login ulang setelah pindah folder. Untuk server gunakan ERP_SECRET_KEY sendiri. ERP_DEBUG/ERP_ALLOWED_HOSTS hanya konfigurasi dasar; bukan paket deployment publik.

## Evaluasi dan batas penggunaan

Baca AUDIT_ERP_FNB.md untuk cakupan pengujian, perbaikan, serta batas stok rekap, pembukuan gaji, akses pengguna dan impor. Tidak ada data transaksi lama yang diubah untuk membuat laba terlihat benar. HPP nol tetap diizinkan dan ditandai untuk ditinjau pada laporan.

---

# Seblak Sayank ERP · Versi 2.16 · Cabang & pembulatan ribuan

ERP operasional satu usaha berbasis Django dan SQLite. Tampilan responsif dengan identitas pink Seblak Sayank, sidebar, dashboard, kalender absensi, dan formulir terintegrasi. Aset CSS/JavaScript tersimpan lokal; UI tidak membutuhkan CDN.

## Mulai di Windows

1. **Cadangkan seluruh folder proyek lama, terutama `db.sqlite3`.** Hentikan server sebelum mengganti file.
2. Ekstrak ZIP ke folder baru. Paket membawa database asli unggahan, **tanpa transaksi demo dan tanpa dimigrasi**. Jika database di komputer sudah lebih baru, salin database terbaru milikmu ke folder hasil ekstrak; jangan menimpanya dengan database dari ZIP.
3. Pastikan Python 3.12 atau 3.13 sudah terpasang dan komputer terhubung internet saat mengunduh dependensi pertama kali.
4. Klik dua kali **MULAI_WINDOWS.bat**. Skrip menyiapkan virtual environment, memasang dependensi, membuat backup database, menjalankan migrasi, lalu menyalakan server.
5. Buka **http://127.0.0.1:8000**. Gunakan akun lama. Jika ini database baru, buka terminal pada folder yang berisi `manage.py`, lalu buat akun:

```powershell
.venv\Scripts\python manage.py createsuperuser
```

Jalankan secara manual jika lebih nyaman:

```powershell
py -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
.venv\Scripts\python manage.py upgrade_erp
.venv\Scripts\python manage.py runserver
```

`upgrade_erp` membuat backup SQLite dalam folder `backups` di sebelah database sebelum menjalankan migrasi. Backup baru memiliki nama dengan waktu unik. Tidak menghapus data lama.

Untuk macOS/Linux, gunakan `python3 -m venv .venv`, lalu ganti `.venv\Scripts\python` dengan `.venv/bin/python`.

## Urutan penyiapan usaha

1. **Pengaturan usaha** — isi nama, alamat, telepon, dan nama kanal. Persentase lama hanya referensi; rekap memakai nominal aktual.
2. **Persediaan → Tambah bahan** — pilih satuan dasar: gram, ml, atau pcs. Isi batas minimum untuk pengingat belanja.
3. **Pembelian** — masukkan stok awal/belanja beserta total biaya. Contoh 1 kg kerupuk: masukkan 1000 gram, bukan 1. Stok awal dicatat dengan nilai biaya perolehannya.
4. **Menu & resep** — opsional sebagai referensi HPP; tidak diperlukan untuk input rekap POS.
5. **Karyawan** — isi gaji pokok, jatah libur, uang bensin bulanan, dan bonus per hari tepat waktu.
6. Mulai mengisi **Penjualan**, **Pengeluaran**, dan **Absensi**. Setelah rekap bulanan lengkap, buat **Payroll** dan periksa **Laporan keuangan**.

## Fitur yang tersedia

| Modul | Alur yang tersedia |
| --- | --- |
| Dashboard | Filter bulan, pendapatan, biaya, laba operasional, nilai stok saat ini, grafik harian, kanal penjualan, transaksi terbaru, stok minimum, kehadiran hari ini |
| Penjualan | Rekap harian POS per kanal, jumlah pesanan, omzet, voucher, komisi, biaya lain, HPP, cetak rekap dan pembatalan beralasan |
| Menu & resep | Harga jual, HPP manual, resep per porsi, tambah/hapus baris bahan, menu aktif/nonaktif |
| Persediaan | Bahan, stok, biaya rata-rata bergerak, nilai stok, pembelian, stok opname, riwayat mutasi dan pengingat minimum |
| Pengeluaran | Biaya operasional per kategori/bulan, pencatatan dan pembatalan dengan riwayat tetap tersimpan |
| Karyawan | Data karyawan, tunjangan, jatah libur, status aktif/nonaktif, pencarian |
| Absensi | Kalender bulanan, Masuk/Izin/Sakit/Libur Jatah/Tidak Hadir, waktu masuk/pulang, bonus tepat waktu, sisa/kelebihan libur |
| Payroll | Rekap bulanan, bonus dan bensin, potongan manual, snapshot gaji/absensi, slip PDF |
| Laporan | Laba operasional bulanan, HPP, biaya platform, payroll, penyesuaian stok, ekspor CSV dan cetak |
| Pengaturan | Identitas usaha, tarif kanal, backup SQLite untuk akun superuser |

## Rekap hasil POS HP

ERP ini bukan kasir. Buka **Penjualan → Input rekap POS** dan salin laporan harian untuk **Offline, ShopeeFood, GrabFood, dan GoFood** secara terpisah. Gunakan tanggal penjualan, bukan tanggal pencairan platform.

Isi jumlah pesanan, omzet bruto, voucher yang ditanggung usaha, komisi aktual, biaya lain (termasuk admin/QRIS), serta total HPP bahan dan kemasan terjual dari POS. Masukkan angka rupiah tanpa pemisah ribuan. Jangan memasukkan diskon yang sepenuhnya ditanggung platform sebagai biaya usaha. Isi 0 jika tidak ada biaya; HPP wajib diisi, dan angka laba hanya benar jika HPP lengkap.

**Pendapatan bersih = bruto − voucher − komisi − biaya lain.** Ini bukan laba dan belum tentu sama dengan pencairan saldo platform. **Laba kotor = pendapatan bersih − HPP.** Persentase pengaturan tidak dipakai otomatis agar sama dengan potongan aktual di laporan merchant.

Contoh: bruto Rp300.000, voucher Rp20.000, komisi Rp50.000, biaya lain Rp1.000, HPP Rp120.000, 25 pesanan → pendapatan bersih Rp229.000, laba kotor Rp109.000.

Simpan satu rekap per tanggal per kanal. Pengiriman ulang formulir yang sama aman. Jika perlu koreksi, buka Detail → Batalkan dengan alasan, lalu input ulang. Rekap yang dibatalkan tetap ada di riwayat dan tidak masuk laba. Hari tanpa penjualan boleh dicatat dengan jumlah pesanan dan omzet 0.

Transaksi lama tetap tersimpan. Sistem menolak rekap baru apabila tanggal dan kanal tersebut sudah memiliki penjualan aktif, termasuk transaksi lama, agar tidak dihitung dua kali. Tinjau dahulu apakah catatan lama sudah tercakup dalam rekap; jangan membatalkan transaksi lama tanpa memeriksa dampak pengembalian stoknya.

## Persediaan dan laba

Rekap POS **tidak mengubah stok** karena tidak memuat rincian menu. Pembelian tetap menambah persediaan dan memperbarui biaya rata-rata. Sesuaikan stok melalui opname berdasarkan stok fisik.

Pada bulan yang memiliki rekap POS aktif, selisih nilai opname **tidak ditambahkan/dikurangkan dari laba** karena pemakaian bahan sudah dimasukkan dalam HPP POS. Kebijakan ini berlaku untuk seluruh bulan tersebut, termasuk bila terdapat transaksi lama. HPP POS harus mencakup biaya bahan terpakai dan kerugian bahan yang ingin dibebankan; jangan menduplikasi biaya itu di Pengeluaran. Pada bulan yang hanya berisi transaksi lama, aturan penyesuaian persediaan lama tetap berlaku.

Pembelian bahan tidak dikurangi lagi dari laba. Pengeluaran dipakai untuk biaya operasional, sementara gaji berasal dari Payroll. Jika HPP POS tidak tersedia, hitung totalnya dahulu; laba tanpa HPP lengkap akan terlalu tinggi.

Menu/resep tetap tersedia sebagai referensi. Riwayat lama mempertahankan harga, HPP, dan mutasi stok historis. Pembatalan rekap tidak memengaruhi stok; pembatalan transaksi lama mengembalikan bahan resep. Saldo stok bukan rekonstruksi posisi akhir bulan historis.

## Kebijakan absensi dan payroll

**Gaji bersih = gaji pokok + uang bensin bulanan + (hari Masuk yang tepat waktu × bonus per hari) + total bonus/tunjangan manual − potongan manual.**

Gaji pokok dan bensin dibayar penuh. Tidak ada prorata atau pemotongan otomatis untuk izin, sakit, absen, kelebihan libur, atau mulai kerja di tengah bulan. Isi potongan manual sesuai kebijakan usaha. Hari yang belum diisi bukan otomatis Tidak Hadir.

Default karyawan: jatah libur 2 hari/bulan, bensin Rp0, bonus Rp10.000/hari. Sesuaikan sebelum membuat payroll. Jam masuk/pulang divalidasi untuk hari yang sama; shift lewat tengah malam belum didukung. Zona waktu Asia/Jakarta.

Satu karyawan hanya boleh memiliki satu payroll per bulan. Rekap dan tarif disimpan saat dibuat; edit hanya mengubah potongan/catatan. Perubahan absensi atau master tidak menghitung ulang payroll lama. Payroll lama dari versi awal mempertahankan nilainya; kolom baru yang dulu belum direkam bernilai 0. Pembayaran payroll belum memiliki status transfer/lunas; payroll dimasukkan ke laporan sebagai beban sesuai bulan gaji.

## Arti laporan laba

**Laba operasional = pendapatan bersih − HPP terjual − pengeluaran operasional − payroll periode + selisih nilai opname.**

Pembelian bahan **tidak dikurangi lagi** sebagai biaya agar tidak terhitung ganda dengan HPP terjual. Jangan mencatat bahan atau gaji di Pengeluaran. Nilai stok pada dashboard/laporan selalu posisi **saat ini**, bukan saldo akhir bulan historis.

Laporan bukan saldo kas/bank dan belum mencakup pajak, penyusutan aset, cicilan, modal/pengambilan pemilik, utang/piutang, atau rekonsiliasi saldo platform. Lengkapi seluruh transaksi dan payroll sebelum menilai laba. Integrasi GoFood/ShopeeFood/GrabFood adalah pencatatan manual berdasarkan kanal; bukan koneksi API ke platform.

## Backup dan pemulihan

Akun superuser dapat mengunduh salinan konsisten database melalui **Pengaturan → Unduh backup database**. File berisi akun dan data usaha; simpan secara pribadi.

Untuk memulihkan:

1. Hentikan server Django.
2. Simpan salinan database yang sedang dipakai.
3. Salin file cadangan ke folder proyek dan beri nama `db.sqlite3`.
4. Jalankan `manage.py upgrade_erp`, lalu nyalakan server kembali.

Aplikasi ini untuk satu usaha/satu workspace. Semua akun yang dapat login memiliki akses operasional yang sama; backup dan admin hanya untuk superuser/staff sesuai Django. Beberapa cabang sudah tersedia. Pembatasan peran kasir per modul/cabang dan konfigurasi hosting publik belum tersedia.

## Mencoba data demo (opsional)

Gunakan **database terpisah**, jangan menjalankan demo pada data usaha asli. Pada PowerShell:

```powershell
$env:ERP_DB_PATH = "$PWD\demo.sqlite3"
.venv\Scripts\python manage.py migrate
.venv\Scripts\python manage.py createsuperuser
.venv\Scripts\python manage.py seed_demo
.venv\Scripts\python manage.py runserver
```

Data demo sepenuhnya fiktif dan diberi catatan DATA DEMO. `seed_demo` menolak database yang telah memiliki karyawan atau data operasional. Akun demo tidak disediakan secara bawaan; buat akun sendiri. Tarif demo merupakan contoh, bukan tarif resmi platform.

Setelah server dihentikan, kembali ke database usaha dengan `Remove-Item Env:ERP_DB_PATH` pada PowerShell atau buka terminal baru.

## Validasi pengembangan

```powershell
.venv\Scripts\python manage.py test core operations
.venv\Scripts\python manage.py check
.venv\Scripts\python manage.py makemigrations --check --dry-run
```

110 pengujian otomatis lulus pada Python 3.12 dan Django 5.2.18 di Linux. Skrip pembuka Windows disertakan, tetapi belum dijalankan pada Windows asli.

Pengujian mencakup payroll, PDF, validasi absensi, formulir, perhitungan platform, rata-rata stok, konsumsi resep, rollback stok kurang, pengiriman formulir ganda, reversal, snapshot biaya, laporan laba dan hak akses backup. Template halaman diuji melalui Django Test Client. Pemeriksaan visual browser tidak berhasil dilakukan pada lingkungan pengerjaan ini karena akses pratinjau dibatasi.

## Jika muncul No module named pip

Skrip MULAI_WINDOWS.bat memeriksa pip dan menjalankan ensurepip bila belum ada. Untuk memperbaiki instalasi lama tanpa mengganti file proyek, buka Command Prompt dan jalankan:

```bat
cd /d C:\SeblakSayankERP
.venv\Scripts\python.exe -m ensurepip --upgrade
MULAI_WINDOWS.bat
```

Jika ensurepip gagal, tutup server, ubah nama folder `.venv` menjadi `.venv_lama`, lalu jalankan BAT kembali agar lingkungan dibuat ulang. Jangan hapus `db.sqlite3`. Python yang dipasang harus menyertakan pip dan dukungan venv.

## Impor CSV online delivery

Buka **Penjualan → Impor CSV**, pilih file, lalu klik **Tampilkan pratinjau**. Periksa tanggal, kanal, jumlah pesanan, omzet, seluruh potongan dan pendapatan bersih. Isi total HPP setiap tanggal/kanal, centang bahwa laporan lengkap dan benar, lalu klik **Simpan seluruh rekap**. File asli tidak dimasukkan ke paket proyek dan tidak mengubah stok.

Format yang didukung:

- ShopeeFood Income Details: memakai Order Create Time untuk tanggal, Order Amount untuk bruto, subsidi voucher merchant dan diskon langsung untuk voucher, Commission untuk komisi, serta biaya merchant untuk biaya lain. Hanya Delivery order berstatus Settled diproses; Cancelled/Canceled dilewati. PB1 atau Platform Flash Sale Subsidy bukan nol ditolak untuk ditinjau manual. File beberapa Store ID ditolak.
- GoFood sesuai contoh unggahan: Waktu Transaksi, Nomor Pesanan, Penjualan, Total Biaya, Pendapatan Bersih, Refund, Jumlah Refund, Gopay Source. Hanya goresto_online tanpa refund diterima. **Total Biaya masuk Biaya lain**, bukan perkiraan komisi. Kolom promo tidak ditambahkan lagi untuk mencegah potongan ganda. Tanggal diambil dari transaksi, bukan nama file.
- GrabFood: PDF Laporan Bisnis Harian kini didukung langsung (lihat bagian versi 2.4). Untuk CSV format standar, Unduh template standar di halaman impor. Satu baris per pesanan, tanggal YYYY-MM-DD, kanal GrabFood/GoFood/ShopeeFood, status selesai atau batal. Nominal tanpa pemisah ribuan, titik untuk desimal; ID pesanan wajib unik. Seluruh kolom wajib ada. Template hanya berisi header, tanpa transaksi contoh yang berisiko ikut diimpor.

Semua baris harus cocok: bruto - voucher - komisi - biaya lain = bersih. Format/status yang belum dikenal, refund, tanggal masa depan, nilai negatif dan baris bermasalah ditolak dengan nomor baris; tidak dilewati diam-diam. CSV harus UTF-8, maksimal 2 MB/10.000 baris/366 rekap harian.

**Pastikan laporan lengkap untuk satu tanggal dan kanal.** Sistem tidak dapat mengetahui apakah platform hanya mengekspor sebagian transaksi. File GoFood contoh unggahan hanya berisi satu pesanan. HPP tidak tersedia dari file platform; isi manual atau aktifkan estimasi otomatis satu kali di Pengaturan usaha. Nilai 0 hanya jika memang benar tidak ada HPP.

Data disimpan sebagai rekap harian, bukan pesanan kasir. Seluruh batch disimpan sekaligus atau dibatalkan seluruhnya bila ada konflik. Tanggal/kanal dengan penjualan aktif menolak impor baru, termasuk file yang periode ekspornya tumpang tindih. File identik yang pernah diimpor tidak bisa diimpor lagi, termasuk setelah rekapnya dibatalkan; koreksi memakai rekap manual. Jangan memasukkan ulang hasil impor sebagai rekap manual.

Pratinjau belum menyimpan penjualan. Pratinjau menggunakan sesi login dan perlu diulang jika sesi habis; membuka unggahan baru membatalkan pratinjau sebelumnya. Rekap yang sudah disimpan muncul di Penjualan dan langsung masuk dashboard/laporan. Pajak atau komponen yang belum didukung dapat dimasukkan lewat rekap manual setelah diperiksa.

## Bonus manual dan penghapusan (versi 2.3)

Buka **Payroll → Buat payroll** atau **Edit**. Bagian **Bonus dan tunjangan manual** menerima beberapa baris dengan catatan dan nominal, misalnya Bensin tambahan Rp200.000 serta Bonus target Rp50.000. Klik **Tambah bonus / tunjangan** untuk baris baru. Catatan wajib untuk setiap nominal; nominal harus positif. Centang Hapus pada baris untuk menghapus bonus saat menyimpan. Baris kosong tidak disimpan. Maksimal 50 baris per payroll.

Bonus hanya berlaku untuk karyawan dan periode payroll tersebut. Bonus tersimpan, muncul pada daftar payroll/slip PDF, serta otomatis menambah biaya payroll di laporan. Jangan mencatat bonus yang sama lagi di Pengeluaran. Bensin bulanan dari data karyawan tetap dihitung, jadi jangan menduplikasinya sebagai bonus manual. Jika seluruh bensin ingin diinput manual, setel uang bensin bulanan karyawan menjadi 0 sebelum membuat payroll baru; payroll lama mempertahankan snapshot awal.

**Payroll → Hapus** membuka konfirmasi. Setelah dicentang dan dikonfirmasi, payroll beserta rincian bonusnya dihapus permanen; karyawan dan absensi tetap ada. Payroll periode tersebut bisa dibuat ulang dengan snapshot terbaru. Biaya payroll dalam laporan periode itu berkurang setelah dihapus.

**Karyawan → Hapus** menampilkan jumlah absensi dan payroll yang terkait. Setelah dicentang dan dikonfirmasi, data karyawan, seluruh absensi, payroll dan bonus terkait dihapus permanen. Untuk hanya menonaktifkan karyawan tanpa mengubah riwayat/laporan, gunakan **Edit → Nonaktif**. Halaman konfirmasi tidak menghapus data saat hanya dibuka. Cadangkan database sebelum menghapus data usaha asli.

Migrasi baru hanya menambah tabel bonus; tidak menghapus data lama secara otomatis. Gunakan MULAI_WINDOWS.bat atau manage.py upgrade_erp agar database dicadangkan dan dimigrasi. Paket telah diuji dengan 110 pengujian otomatis dan slip PDF contoh diperiksa secara visual. Eksekusi Windows asli belum diuji.

## Impor PDF settlement Grab langsung (versi 2.4)

Tidak perlu mengubah PDF menjadi CSV. Buka **Penjualan → Impor CSV / PDF**, unggah PDF asli **Laporan Bisnis Harian** Grab, lihat pratinjau dan simpan. Format yang diuji adalah contoh laporan 28 Oktober 2026; hasil pembacaan mencocokkan seluruh 30 pesanan dengan omzet Rp843.460, promo Rp268.903, biaya jasa Rp114.911,40 dan pendapatan Rp459.645,60. Nama Grab Sumbersari merujuk outlet yang sama dengan Sigura-gura sesuai penjelasan pemilik; tidak dibuat cabang baru.

Parser membaca tanggal laporan, jumlah pesanan, bruto, promo merchant, biaya jasa dan subsidi ongkir. Seluruh rincian pesanan dan ringkasan harus cocok. PDF foto/scan, terenkripsi, lebih dari 30 halaman, pajak/tagihan atau bentuk penyesuaian yang belum didukung ditolak dengan penjelasan. Maksimal file 2 MB. File identik atau tanggal/kanal yang sudah aktif ditolak untuk mencegah pencatatan ganda. PDF asli tidak diubah.

### Agar tidak mengetik HPP setiap impor

Sekali di awal, buka **Pengaturan usaha → Estimasi HPP impor (% dari omzet bruto)**. Isi rasio biaya bahan dan kemasan terhadap omzet bruto menurut usaha sendiri. Contoh angka 40 berarti biaya diperkirakan 40% dari bruto; angka ini contoh, tidak diterapkan otomatis dan bukan rekomendasi rasio usahamu. Simpan pengaturan.

Sesudah itu, impor CSV ShopeeFood/GoFood maupun PDF Grab akan menawarkan estimasi otomatis yang sudah dicentang. Kolom HPP manual disembunyikan selama otomatis aktif; cukup tinjau dan simpan. HPP dihitung server per rekap dan persentase disimpan pada catatan. Perubahan persentase berikutnya tidak mengubah impor lama.

**HPP dan laba otomatis adalah estimasi.** Settlement tidak memuat jumlah porsi/menu atau biaya bahan aktual. Penanda estimasi tampil di detail transaksi, dashboard, laporan dan ekspor CSV. Jika punya HPP aktual, hilangkan centang estimasi lalu isi HPP manual. Jika persentase belum diatur, HPP manual tetap wajib; sistem tidak mengasumsikan biaya 0 atau memilih persentase sendiri. Penjualan/potongan/pendapatan bersih tetap memakai angka aktual dari settlement, tanpa menghitung ulang tarif platform.

Tidak ada penjualan usaha yang diimpor otomatis selama pembaruan. Data contoh hanya dipakai untuk pengujian di database terpisah. Jalankan MULAI_WINDOWS.bat untuk memasang pypdf dan migrasi baru; pertahankan db.sqlite3 terbarumu.

## Workflow harian empat sumber (versi 2.5)

1. **ShopeeFood:** Penjualan → Impor CSV / PDF → unggah CSV → tinjau → simpan.
2. **GoFood:** halaman yang sama → unggah CSV → tinjau → simpan.
3. **GrabFood:** halaman yang sama → unggah PDF settlement asli → tinjau → simpan.
4. **Offline:** Penjualan → HPP dari XLSX POS → pilih XLSX Riwayat Penjualan dan kanal Offline → cocokkan menu → hitung → tinjau → simpan.

Ekspor POS contoh milik pemilik adalah khusus pembeli Offline, termasuk metode Non Tunai. Format yang didukung mengikuti DOC-20261029-WA0003.xlsx: sheet Riwayat Penjualan, nomor struk, tanggal DD-MM-YYYY, menu, jumlah dan total. Struk induk diwariskan ke baris menu/topping berikutnya yang kosong nomor struk/tanggalnya. Baris Total tidak dihitung sebagai menu. Contoh terbaca 12 struk tanggal 28 Oktober 2026, 34 produk termasuk topping, total Rp317.000.

**Penyiapan sekali:** lengkapi Menu & resep, termasuk topping dan tambahan level pedas. Setiap menu POS harus dipetakan ke menu ERP. Nama sama dipilih otomatis; pencocokan lain diingat setelah impor disimpan. Biaya bahan resep harus tersedia dari pembelian, atau pakai HPP manual menu jika tidak mempunyai resep. HPP nol tetap diterima; laba akan lebih tinggi jika biaya belum dilengkapi. Tidak ada HPP dummy atau data uji yang ditambahkan ke database asli.

Saat belum ada rekap Offline pada tanggal file, impor otomatis membuat omzet, jumlah struk, diskon transaksi dan HPP resep dalam satu penyimpanan. Bila rekap Offline sudah ada, total bersih harus cocok dan hanya HPP yang diganti; omzet tidak bertambah lagi. Pembayaran Tunai/Non Tunai digabung sebagai total kanal Offline. Subtotal produk memakai angka sesudah diskon produk sesuai ekspor POS; diskon transaksi dipisahkan. Pajak/ongkir/kemasan tambahan di luar menu yang bukan nol belum didukung dan ditolak untuk ditinjau manual.

Total HPP = jumlah setiap produk/topping terjual × HPP per unit dari menu ERP. Biaya rata-rata resep diambil saat pratinjau, disimpan sebagai snapshot lengkap, dan tidak berubah ketika resep/harga bahan berikutnya diedit. Impor ini tidak mengurangi stok; gunakan opname untuk penyesuaian fisik sebagaimana alur rekap.

**Batas HPP online:** file POS ini hanya Offline. Jangan menggunakannya untuk menghitung HPP ShopeeFood/GrabFood/GoFood. Settlement online belum memuat rincian menu/porsi, jadi HPP online tetap manual atau estimasi persentase. Penggunaan HPP resep online memerlukan laporan item terjual khusus kanal tersebut. Halaman XLSX juga dapat mengisi HPP saja pada rekap online yang telah dibuat, tetapi hanya jika pengguna memang memiliki ekspor satu hari/satu kanal online dengan format item yang sama.

Seluruh penyimpanan bersifat atomik. File identik atau rekap yang sudah mempunyai impor HPP POS tidak dapat diimpor lagi. Untuk koreksi, batalkan rekap lama dan buat rekap pengganti; file identik yang telah disimpan tetap diblokir, sehingga koreksi HPP perlu ditinjau oleh pengelola. Simpan ekspor dan database cadangan. Format lain, campuran tanggal/outlet, refund/batal, jumlah negatif/pecahan, ekstra tersimpan di kolom terpisah, atau total tidak cocok akan ditolak; sistem tidak melewati data diam-diam. XLSX maksimal 5 MB/10.000 baris/100 nama menu.

Pembaruan menambah dependensi openpyxl dan tabel riwayat HPP/pemetaan nama. Jalankan MULAI_WINDOWS.bat setelah menggunakan database terbarumu. 69 pengujian lulus; file XLSX asli diuji penuh pada salinan database dengan HPP dummy khusus QA. Harga bahan/resep usahamu tetap harus dilengkapi sendiri.

## HPP manual tiap platform (versi 2.6)

Pada **Menu & resep → Tambah menu / Edit & resep**, isi HPP ShopeeFood, GrabFood, dan GoFood per porsi. Ketiga kolom opsional, dapat berbeda untuk menu yang sama, dan tampil pada daftar menu. Angka adalah biaya bahan/kemasan, bukan harga jual atau komisi/voucher. Kolom kosong berarti memakai HPP resep atau, jika tidak ada resep, HPP manual dasar. Nilai 0 berbeda dengan kosong; nominal negatif ditolak. Impor HPP POS menerima HPP nol.

Contoh HPP dasar Rp4.000, ShopeeFood Rp5.000, GrabFood Rp5.500, GoFood Rp6.000. Impor rincian menu khusus kanal GrabFood memakai Rp5.500 per porsi; Offline tetap memakai resep/HPP dasar. HPP manual khusus kanal diprioritaskan meskipun menu mempunyai resep. Snapshot yang telah disimpan tidak berubah saat HPP menu diperbarui.

Kolom ini **tidak bisa menentukan jumlah menu terjual dari settlement**. Rekap settlement tanpa rincian menu masih membutuhkan HPP manual total/estimasi persentase. Kolom HPP per-menu dipakai ketika ada rincian produk terjual yang dicocokkan dengan menu ERP; XLSX Offline milikmu tetap khusus Offline, jangan dipakai untuk kanal online.

Migrasi menambah tiga kolom kosong tanpa mengganti HPP dasar atau riwayat lama. Total 72 pengujian lulus (69 pengujian regresi dan 3 pengujian fitur ini); migrasi berhasil pada database salinan.

## Jabatan dan payroll mingguan (versi 2.7)

1. Buka **Jabatan & gaji → Tambah jabatan**. Isi nama, misalnya Dapur; pilih sistem Harian; isi tarif per hari, misalnya Rp50.000. Sistem Bulanan menggunakan Gaji pokok bulanan. Kolom yang tidak dipakai boleh 0. Tarif sistem yang dipilih harus positif. Jabatan bisa diedit dan dihapus melalui halaman ini.
2. Buka **Karyawan → Edit**, pilih **Jabatan & aturan gaji**, lalu simpan. Jabatan lama belum otomatis diubah karena nama jabatan tidak cukup untuk menentukan tarif yang benar. Jika tidak memilih jabatan, aturan gaji lama karyawan tetap dipakai.
3. Lengkapi absensi. Untuk sistem harian, **Masuk dan Masuk terlambat** dibayar; Sakit, Izin, Libur Jatah, Tidak Hadir dan tanggal tanpa absensi tidak dibayar. Tidak ada lembur, setengah hari, atau hari libur berbayar otomatis.
4. Buka **Payroll → Buat payroll**, pilih Rentang tanggal / mingguan, pilih karyawan, isi Dari dan Sampai, misalnya 1–7 Oktober. Kedua tanggal termasuk perhitungan. Tambahkan bonus/tunjangan dan potongan jika perlu, lalu simpan/unduh slip PDF. Pilihan Bulanan tetap tersedia.

**Gaji harian = (hari Masuk + Masuk terlambat) × tarif harian.** Contoh 6 hari hadir × Rp50.000 = Rp300.000; 1 hari tidak masuk tidak dibayar. Bonus tepat waktu mengikuti pengaturan karyawan dan hanya dihitung pada hari Masuk yang memenuhi syarat. Sistem harian tidak menambahkan bensin bulanan otomatis agar hari tidak masuk tidak menerima tunjangan tetap; uang bensin bisa ditambahkan melalui bonus manual beserta catatan.

Untuk jabatan Bulanan dengan rentang sebagian bulan, gaji pokok dan bensin bulanan diprorata berdasarkan jumlah hari kalender pada masing-masing bulan, termasuk hari tidak hadir sesuai kebijakan gaji bulanan sebelumnya. Contoh Rp3.100.000 pada Oktober (31 hari), periode 1–7 Oktober → Rp700.000. Payroll Bulanan biasa tetap dibayar penuh. Kuota libur tetap bulanan, bukan diberikan ulang setiap minggu; slip rentang hanya menampilkan jumlah libur tercatat.

Periode bertumpuk ditolak untuk karyawan yang sama, termasuk payroll mingguan yang bertumpuk dengan payroll bulanan lama. Rentang berturutan boleh, misalnya 1–7 lalu 8–14. Jika mengganti payroll bulanan yang terlanjur dibuat, tinjau dan hapus payroll yang salah dahulu. Maksimal satu rentang 366 hari; tanggal awal tidak boleh sebelum mulai bekerja. Lengkapi absensi dahulu karena periode disimpan sebagai snapshot, bukan terus dihitung ulang.

Edit payroll hanya mengubah bonus manual, potongan dan catatan; periode, rekap absensi, nama jabatan, sistem gaji dan tarif awal dipertahankan. Mengubah nominal jabatan memengaruhi payroll baru untuk semua karyawan yang terhubung, tidak mengubah slip lama. Menghapus jabatan memerlukan konfirmasi dan menyalin aturan terakhir ke karyawan terkait; karyawan/absensi/payroll tetap ada. Setelah jabatan dihapus, pilih jabatan baru pada Edit karyawan jika ingin mengganti aturannya.

**Laporan bulanan membukukan seluruh gaji pada bulan tanggal akhir rentang**, termasuk periode yang melintasi bulan; belum membagi biaya akrual per hari. Contoh 30 Oktober–2 November seluruhnya masuk November. Payroll bulanan lama tetap masuk bulan gajinya. Pengaturan tarif dan uang bensin merupakan kebijakan aplikasi yang bisa kamu sesuaikan.

Migrasi hanya menambah tabel jabatan/kolom periode dan snapshot serta memperbarui batas duplikasi. Data payroll lama, absensi, bonus dan karyawan dipertahankan. 80 pengujian lulus, migrasi pada database salinan berhasil, dan contoh slip mingguan diperiksa secara visual. Jalankan MULAI_WINDOWS.bat setelah menyalin database terbarumu ke folder proyek baru.

## Tampilan baru dan Rupiah (versi 2.8)

Desain mengikuti arah referensi pemilik: workspace abu-abu lembut, menu aktif hijau lime, kartu peach/lavender/aqua, sudut membulat dan panel analitik putih. Identitas dan seluruh modul Seblak Sayank dipertahankan. Dashboard menampilkan pendapatan bersih, jumlah pesanan, laba operasional, grafik pendapatan/laba kotor harian, komposisi pendapatan kanal, biaya/HPP/payroll, rekap terbaru dan pengingat stok. Tidak ada angka pertumbuhan atau statistik pelanggan rekaan. Grafik berasal dari data tercatat; tabel angka harian tersedia melalui Lihat angka harian.

Seluruh nilai uang ditampilkan sebagai Rupiah Indonesia, termasuk ribuan titik dan desimal koma bila ada pecahan: Rp1.000.000 atau Rp459.645,60. Ini adalah perubahan format, bukan konversi kurs. Input uang mempunyai awalan Rp; tetap ketik angka pada kolom, tanpa mengetik Rp/pemisah ribuan. Kolom jumlah, tanggal dan persentase tidak diberi prefix uang. Slip gaji juga memakai format Rupiah yang mempertahankan pecahan jika ada.

Pada HP sidebar tetap memakai tombol menu; tabel dan grafik dapat digeser di dalam panel. CSS/JavaScript lokal tanpa CDN/font eksternal. Jika tampilan lama masih muncul setelah mengganti paket, muat ulang paksa dengan Ctrl+F5 atau hapus cache situs lokal.

Tidak ada migrasi database tambahan untuk versi 2.8. Pertahankan db.sqlite3 terbaru milikmu. 82 pengujian lulus untuk regresi, chart data aktual, format Rupiah dan formulir. Halaman terisi/blank berhasil dirender melalui Django Test Client. Pemeriksaan screenshot browser belum berhasil karena browser headless tidak tersedia dan unduhannya gagal di lingkungan pengerjaan; tampilan perlu dikonfirmasi di browser Windows pengguna.

## Debug bonus mingguan dan hitung ulang absensi (versi 2.9)

Tanggal 24–30 mencakup 7 hari termasuk tanggal awal/akhir dan akhir pekan. Bonus hanya menghitung status Masuk dengan penanda tepat waktu Ya. Payroll menyimpan snapshot; menambahkan/mengedit absensi setelah membuat payroll tidak otomatis mengubah slip. Menekan Simpan/Edit biasa juga mempertahankan rekap awal.

Buka **Payroll → Edit → Pemeriksaan bonus tepat waktu**. Tabel menunjukkan setiap tanggal dalam periode, status, kelayakan bonus dan alasannya (memenuhi bonus, belum ada absensi, tidak ditandai tepat waktu, atau status bukan Masuk). Bandingkan jumlah tersimpan di slip dengan jumlah berdasarkan absensi terbaru.

Untuk memperbarui, klik **Hitung ulang absensi → centang konfirmasi → Konfirmasi hitung ulang**. Rekap hadir, sakit, izin, libur, absen dan hari bonus diperbarui. Tarif gaji/bonus, jabatan, uang bensin, bonus manual dan potongan tetap memakai snapshot lama. Sistem harian menghitung ulang gaji pokok dari hari hadir terbaru; gaji pokok bulanan tetap. Jika potongan menjadi lebih besar daripada penghasilan baru, seluruh perubahan dibatalkan dan pesan ditampilkan. Laporan dan slip berikutnya memakai hasil hitung ulang.

Pengujian mereproduksi payroll dibuat ketika baru 5 hari tepat waktu, kemudian 2 hari lagi ditambahkan: sebelum hitung ulang slip tetap 5, sesudah hitung ulang menjadi 7. Ini kemungkinan penyebab laporan pengguna, tetapi database terbaru milik pengguna belum diperiksa sehingga penyebab kasus Rahman belum dipastikan. Tabel diagnosis membedakan snapshot lama dari dua absensi yang belum memenuhi syarat.

85 pengujian lulus. Tidak ada migrasi database baru atau penghitungan ulang massal otomatis. Gunakan database terbarumu saat memasang pembaruan.

## Preview slip gaji (versi 2.10)

Buka **Payroll → Preview slip**. Preview HTML menampilkan periode, karyawan, jabatan, gaji pokok/harian, bensin, bonus tepat waktu, rincian bonus manual, potongan, gaji bersih dan rekap absensi tersimpan. Dapat dibuka dari Edit payroll juga. Angka memakai snapshot yang sama dengan unduhan PDF, tanpa menulis/menghitung ulang absensi.

Tombol **Lihat PDF asli** membuka file PDF secara inline pada tab baru jika browser mendukung. **Unduh PDF** tetap mengunduh; **Cetak preview** mencetak halaman HTML tanpa navigasi. Tata letak HTML responsif bisa berbeda dari PDF; gunakan Lihat PDF asli untuk memeriksa dokumen yang sama persis dengan unduhan. Jika browser HP memilih mengunduh PDF, preview HTML tetap bisa dibaca.

Halaman preview memerlukan login, tidak disimpan dalam cache browser, dan catatan bonus di-escape agar tidak menjadi HTML aktif. 88 pengujian lulus. Tidak ada migrasi database baru. Pemeriksaan visual browser masih belum tersedia di lingkungan pengerjaan.

## Analisis penjualan delivery harian (versi 2.11)

Dashboard memuat **Kontribusi penjualan harian**. Tanggal awal adalah hari ini, bisa diubah melalui Lihat tanggal. Pilihan tanggal analisis terpisah dari filter bulan untuk ringkasan/grafik bulanan; mengganti salah satu mempertahankan pilihan lainnya.

Grafik donat dan batang menampilkan ShopeeFood, GrabFood, GoFood, dan Offline beserta omzet Rupiah dan persentase. Total Online adalah gabungan tiga aplikasi tersebut, bukan kanal kelima yang menambah total. Tersedia ringkasan total omzet, jumlah pesanan, pendapatan bersih, kontribusi online/offline, tabel per kanal dan kanal dengan omzet terbesar.

**Kontribusi = omzet bruto kanal / total omzet bruto tanggal terpilih × 100%.** Contoh Shopee Rp400rb, Grab Rp300rb, GoFood Rp200rb, Offline Rp100rb → 40%, 30%, 20%, 10%; total Online 90%. Omzet sebelum voucher/komisi, bukan jumlah pesanan atau pendapatan bersih. Pendapatan bersih ditampilkan terpisah agar tidak tertukar.

Hanya rekap aktif pada tanggal penjualan/laporan yang dihitung. Pembatalan tidak ikut total. Jika ada kanal tambahan/namanya berbeda, nilainya masuk Kanal lainnya agar kontribusi tetap utuh. Nama standar yang dikenali adalah ShopeeFood, GrabFood, GoFood, Offline (variasi spasi/huruf besar kecil disamakan). Hari tanpa omzet menampilkan 0% dan pesan belum ada data, tanpa pembagian nol. Angka dibulatkan untuk tampilan sehingga persentase dapat berselisih 0,1% bila dijumlahkan.

Pastikan empat sumber telah diimpor lengkap; kanal bernilai nol bisa berarti laporan belum dimasukkan. Tidak ada asumsi penjualan yang belum tercatat. Tidak perlu migrasi tambahan. 91 pengujian lulus untuk agregasi harian, pemilihan tanggal, kanal, persentase, transaksi batal, hari kosong dan regresi seluruh modul. Pemeriksaan screenshot browser tetap belum tersedia di lingkungan pengerjaan.

## Pendapatan bersih harian dan tambah menu massal (versi 2.12)

Dashboard menampilkan kartu **Total pendapatan bersih tanggal terpilih** di atas total omzet. Ini adalah jumlah pendapatan bersih rekap aktif semua kanal pada tanggal yang dipilih, sesudah voucher/komisi/biaya lain. Bukan laba: HPP, pengeluaran dan payroll belum dikurangkan. Nilai tetap Rupiah, termasuk pecahan settlement.

Buka **Menu & resep → Tambah banyak menu**. Tersedia 5 baris awal dan tombol Tambah baris menu, maksimal 100 menu per penyimpanan. Isi nama, harga jual, HPP manual dasar, HPP khusus ShopeeFood/GrabFood/GoFood opsional, serta status aktif. Centang Hapus pada baris yang ingin diabaikan. Baris kosong boleh dibiarkan (minimal satu menu harus diisi).

Klik Simpan semua menu. Seluruh daftar disimpan sekaligus; jika satu baris tidak valid atau ada nama berulang/sudah terdaftar (tanpa membedakan huruf besar kecil), tidak ada menu baru yang disimpan. Gunakan Edit untuk menu yang sudah ada. Resep bahan tetap dilengkapi per menu melalui Edit & resep setelah menu massal tersimpan. Fitur ini formulir banyak baris, bukan impor file Excel.

95 pengujian lulus mencakup nilai pendapatan bersih, posisi kartu di atas omzet, nominal HPP tiap kanal, validasi negatif, nama ganda, pengabaian baris dan login. Tidak ada migrasi database tambahan. Tetap gunakan db.sqlite3 terbarumu; muat ulang Ctrl+F5 jika aset lama tersimpan di cache. Pemeriksaan visual browser belum tersedia di lingkungan pengerjaan.

## Form karyawan dan posisi layar absensi (versi 2.13)

Kolom Uang bensin bulanan dihapus dari formulir Tambah/Edit karyawan. Nilai lama pada database dipertahankan, bukan dihapus atau diubah menjadi nol. Karena itu nilai lama tetap mengikuti kebijakan perhitungan payroll yang sudah ada; tunjangan tambahan tetap dapat diisi pada Bonus/tunjangan manual payroll. Tidak ada migrasi atau penghitungan ulang slip otomatis.

Memilih tanggal absensi memuat ulang kalender dan formulir secara parsial tanpa navigasi penuh. Posisi scroll dipertahankan, URL tanggal terpilih diperbarui, dan klik tanggal beruntun membatalkan permintaan lama agar hasil terakhir tidak tertimpa. Tautan biasa tetap berfungsi bila JavaScript tidak tersedia. Bila permintaan parsial gagal, sistem kembali ke navigasi biasa dengan upaya memulihkan posisi scroll. Setelah Simpan kehadiran, posisi scroll dipulihkan pada halaman hasil redirect.

97 pengujian Django lulus, JavaScript lolos pemeriksaan sintaks dan simulasi pergantian tanggal mempertahankan scroll pada 720px tanpa navigasi penuh. Pemeriksaan browser visual belum tersedia di lingkungan pengerjaan. Aset mempunyai versi cache baru; Ctrl+F5 bila browser masih menampilkan perilaku lama.

## Catatan potongan dan gaji pokok bulat (versi 2.14)

Form Buat/Edit payroll memiliki **Catatan potongan (contoh: Kasbon / cicilan)**. Isi nominal potongan dan keterangannya. Preview HTML dan PDF memakai isi catatan sebagai nama baris potongan, bukan teks Potongan manual. Jika catatan kosong, tampil Potongan. Catatan slip umum tetap terpisah dan tidak diubah otomatis.

Gaji pokok bulanan (termasuk prorata untuk payroll mingguan) dibulatkan ke Rupiah terdekat, setengah ke atas: Rp338.709,68 menjadi Rp338.710. Total gaji bersih dan laporan memakai dasar bulat yang sama, sehingga angka pada slip sesuai perhitungan. Payroll baru menyimpan dasar bulat. Snapshot bulanan lama dengan pecahan tetap disimpan di database, tetapi nilai dasar yang dibayarkan/ditampilkan dan totalnya mengikuti pembulatan baru; selisih dapat kurang dari Rp1. Ini tidak menghitung ulang absensi atau mengubah nominal bonus/potongan. Gaji harian dan nilai settlement tetap mengikuti presisi sebelumnya.

Jalankan MULAI_WINDOWS.bat/upgrade_erp untuk mencadangkan database dan menambah kolom catatan potongan. Data lama tidak dihapus. 100 pengujian lulus dan contoh PDF telah dirender serta diperiksa secara visual.

## Pengaturan layout slip gaji (versi 2.15)

Buka **Payroll → Atur layout slip**, atau tombol yang sama pada halaman Preview slip. Pilih bagian yang ingin ditampilkan: kode karyawan, jabatan/sistem gaji, gaji pokok/harian, uang bensin, bonus tepat waktu, rincian bonus manual, potongan beserta catatannya, rekap absensi/libur, rincian hari/tarif, catatan slip dan catatan penutup. Judul serta isi penutup dapat diedit. Hilangkan centang Rekap absensi dan libur untuk slip ringkas tanpa tabel kehadiran.

Klik Simpan lalu buka Preview slip / Lihat PDF asli / Unduh PDF. Pengaturan berlaku secara global untuk semua karyawan dan slip yang dihasilkan berikutnya, termasuk payroll lama yang dibuka kembali. PDF yang telah terunduh sebelumnya tidak berubah. Nama karyawan, periode dan gaji bersih selalu tampil. Menyembunyikan komponen hanya mengubah layout; komponen tetap ikut perhitungan sehingga total mungkin tidak sama dengan jumlah rincian yang terlihat. Tidak ada perubahan absensi atau nominal payroll.

Secara bawaan semua bagian dicentang agar tampilan lama dipertahankan. Pengaturan ini pilihan tampil/sembunyi, bukan editor drag-and-drop atau pengubahan ukuran/posisi bebas. Jalankan MULAI_WINDOWS.bat untuk migrasi tabel layout. 103 pengujian lulus (100 regresi + 3 layout), termasuk kesamaan total saat bagian disembunyikan, penyimpanan pengaturan, login dan PDF. Contoh PDF ringkas tanpa absensi/bensin sudah dirender dan diperiksa secara visual.

## Pemilih cabang dan data terpisah (versi 2.16)

Di pojok kiri atas/sidebar terdapat **Cabang aktif** dan **Tambah cabang**. Pilih cabang melalui dropdown. Untuk cabang baru klik Tambah cabang, isi nama, lalu Simpan. Cabang baru langsung dipilih; empat kanal Offline/ShopeeFood/GrabFood/GoFood dibuat otomatis tanpa data penjualan, menu, bahan atau karyawan.

Saat pembaruan pertama, semua data lama ditempatkan di cabang awal **Sigura-gura**. Tidak ada data usaha yang dipindahkan ke cabang baru. Setelah memilih cabang, dashboard, laporan, penjualan, impor CSV/PDF/XLSX, biaya, stok, pembelian, menu/resep, jabatan, karyawan, absensi dan payroll dibatasi pada cabang itu. Nama menu/kode karyawan boleh sama di cabang berbeda. Pemetaan nama POS dan riwayat impor juga dipisahkan. Tidak ada fitur transfer stok/pegawai atau laporan gabungan lintas cabang pada versi ini.

Pergantian cabang membersihkan pratinjau impor yang belum disimpan agar tidak masuk cabang yang salah. Jika cabang diganti di tab lain, pengiriman formulir dari tab lama ditolak dengan pesan untuk membuka ulang halaman. Pilihan cabang disimpan pada sesi login, bukan sebagai data perusahaan global. Semua akun login operasional mempunyai hak memilih cabang seperti pola akses aplikasi sebelumnya; belum ada pembatasan pengguna per cabang. Backup database oleh superuser tetap berisi seluruh cabang.

Identitas usaha, pengaturan persentase HPP impor dan layout slip digunakan bersama. Pengaturan tarif kanal (voucher/komisi) berada pada kanal masing-masing cabang. Slip menambahkan nama cabang karyawan pada header PDF/preview. Cabang baru memerlukan pengisian data sendiri; tidak menyalin menu/resep/harga dari cabang lama otomatis. Cabang belum bisa dihapus lewat UI.

### Pembulatan gaji pokok bulanan ke atas per Rp1.000

Permintaan contoh 338.709 menjadi 339 ditafsirkan sebagai **Rp338.709 → Rp339.000**. Gaji pokok bulanan/prorata sekarang dibulatkan **ke atas ke kelipatan Rp1.000**: Rp338.709,68 → Rp339.000, Rp339.000 tetap Rp339.000, Rp339.000,01 → Rp340.000. Berlaku juga pada dasar bulanan snapshot lama saat dihitung sebagai nilai dibayarkan. Total bersih dan laporan mengikuti dasar bulat yang sama. Gaji harian, komponen bonus/potongan/bensin dan settlement tidak dibulatkan ke ribuan otomatis.

Jalankan **MULAI_WINDOWS.bat** untuk backup dan migrasi. Jangan mengganti database terbaru di komputer dengan database lama dari paket. Migrasi pada salinan db.sqlite3 unggahan berhasil tanpa mengurangi jumlah karyawan/payroll/absensi/penjualan. Pemeriksaan FK bersih. 110 pengujian lulus, termasuk pemisahan data cabang, akses URL lintas cabang ditolak, pilihan form, pindah cabang, cabang baru dan pembulatan. Contoh PDF Rp339.000 diperiksa visual. Screenshot browser belum tersedia.

## Versi 2.17 — Impor POS dengan HPP nol

Impor XLSX POS tetap dapat disimpan meskipun HPP menu Rp0 atau harga bahan resep belum tersedia. Berlaku untuk rekap Offline baru maupun pembaruan HPP rekap yang sudah ada. Pencocokan menu tetap wajib. HPP disimpan sesuai nilai saat pratinjau; melengkapi harga menu kemudian tidak memperbarui riwayat impor secara otomatis.

## Versi 2.18 — Nama cabang, masa kerja dan penempatan harian

Pilih cabang di kiri atas lalu klik Edit nama cabang. Nama harus unik; perubahan tidak memindahkan atau menghapus data. Daftar Karyawan menampilkan lama bekerja dalam tahun/bulan/hari sejak tanggal mulai bekerja sampai hari ini, termasuk untuk karyawan nonaktif (belum tersedia tanggal berhenti).

Pada kalender Absensi pilih Cabang bertugas hari ini sebelum menyimpan. Nama cabang ditampilkan di kalender. Cabang bertugas dapat berbeda dari cabang asal karyawan. Absensi tetap dikelola dari cabang asal dan tetap dihitung satu kali pada payroll karyawan tersebut; fitur ini tidak memindahkan beban payroll antarcabang. Absensi lama otomatis memakai cabang asalnya pada migrasi.

## Versi 2.19 — Kategori, impor antarcabang, laporan harian dan absensi dashboard

Menu & resep: centang menu pada halaman yang sedang terbuka, isi nama kategori baru (contoh Adds on topping seblak atau Paket seblak) atau pilih kategori yang ada, lalu Terapkan. Satu menu memiliki satu kategori; kategori juga tersedia pada edit/tambah menu dan sebagai filter daftar.

Impor menu cabang lain: pilih sumber dan konfirmasi untuk menyalin seluruh menu, kategori, harga, HPP manual per kanal dan resep. Nama menu yang sudah ada di tujuan dilewati, tanpa menimpa data. Bahan baru dibuat dengan stok nol dan biaya rata-rata sumber. Bahan yang sudah ada tetap memakai biaya tujuan; satuan berbeda membatalkan seluruh impor. Stok, penjualan, pemetaan POS dan riwayat tidak disalin. Tinjau biaya bahan di tujuan setelah impor.

Laporan keuangan: pilih Harian dan tanggal, lalu Tampilkan. CSV dan cetak mengikuti periode. Payroll rentang tanggal dibukukan pada tanggal akhir periode, payroll bulanan pada hari terakhir bulan; bukan alokasi gaji per hari atau arus kas pembayaran. Laporan bulanan tetap tersedia.

Dashboard: ringkasan absensi tiap karyawan cabang aktif, default sejak tanggal mulai bekerja sampai hari ini. Pilih bulan atau Sejak awal. Hadir mencakup status masuk dan terlambat; tepat waktu merupakan bagian dari hadir. Hari tanpa catatan dipisahkan dari tidak hadir. Karyawan nonaktif tetap ditampilkan berdasarkan tanggal mulai bekerja (belum ada tanggal berhenti).

PDF slip memakai tampilan navy/hijau, hierarki judul, total gaji menonjol, garis tabel ringan dan nomor halaman. Pilihan bagian slip di Pengaturan layout tetap berlaku. 120 pengujian lulus; PDF diperiksa secara visual. Gunakan database terbaru, jalankan MULAI_WINDOWS.bat untuk migrasi, lalu Ctrl+F5.

## Versi 2.20 — Porsi seblak dan tambahan topping dari POS

Jumlah porsi memakai jumlah item dengan nama asli POS yang mengandung seblak, tanpa membedakan huruf besar/kecil. Semua nama lain dihitung sebagai tambahan topping. Kategori ERP dan nama hasil pemetaan tidak mengubah aturan ini. Contoh satu struk dengan 2 Seblak Sayank dan 3 Bakso: 1 pesanan, 2 porsi, 3 tambahan topping. Semua item tetap dihitung dalam omzet dan HPP.

Angka ditampilkan pada pratinjau impor, daftar/detail penjualan, ringkasan dashboard dan laporan/CSV. Ringkasan memakai periode laporan, hanya impor POS yang aktif, bukan settlement tanpa rincian item. Riwayat impor lama dihitung otomatis dari nama item snapshot yang sudah tersimpan, tanpa mengubah nilai transaksi atau perlu impor ulang.

## Versi 2.21 — Tunai dan QRIS dari ekspor POS

Impor XLSX membaca Metode Pembayaran pada baris induk setiap struk, satu kali per struk. Tunai/Cash dicatat sebagai Tunai; Non Tunai/Non-Tunai/QRIS dicatat sebagai QRIS sesuai penggunaan POS outlet. Baris topping tidak menambah jumlah struk atau pembayaran. Kolom/nilai kosong ditandai belum diketahui, bukan otomatis Tunai. Nilai metode lain ditolak untuk ditinjau. Tidak ada biaya QRIS rekaan atau potongan otomatis.

Rincian nominal dan jumlah struk muncul saat pratinjau, pada detail/daftar penjualan serta ringkasan pembayaran Offline di dashboard/laporan/CSV. Angka ini bagian dari omzet yang sama, tidak ditambahkan ke omzet lagi. Jumlah struk bukan jumlah pelanggan unik; ekspor ini tidak menyediakan identitas pelanggan yang cukup untuk menghitung orang unik.

Riwayat impor lama yang belum menyimpan rincian pembayaran dapat dilengkapi dengan mengunggah file identik di kanal Offline yang sama lalu mengonfirmasi Lengkapi pembayaran. Sistem hanya menambahkan rincian pada impor tersebut, tanpa mengubah omzet/HPP. Total harus cocok dan rekap masih aktif. Setelah lengkap, impor ulang tetap diblokir. Tidak ada pembagian pembayaran otomatis untuk riwayat yang sumbernya tidak tersedia.

## Versi 2.23 — Dashboard tanpa banner ringkasan di atas judul

Pembayaran POS, jumlah unit terjual dan peringatan HPP nol adalah informasi data, bukan notifikasi sementara. Ketiganya dipindahkan ke panel Rincian POS & kelengkapan biaya setelah analisis penjualan harian. Panel tertutup saat halaman dibuka dan dapat dibuka/tutup tanpa JavaScript. Jumlah catatan HPP nol tetap ditampilkan pada judul panel. Tidak ada nilai transaksi yang diubah.

## Versi 2.24 — Kategori menu dan centang lintas halaman

Daftar Menu & resep dikelompokkan menurut kategori dalam dua kolom tabel pada layar lebar dan satu kolom pada layar kecil. Filter kategori otomatis menampilkan nama kategori terpilih dan menunya; pencarian/paginasi tetap mempertahankan filter. Tanpa kategori memiliki filter tersendiri. HPP dasar terlihat pada tabel, HPP tiap platform tersedia lewat rincian Per platform.

Centang menu pada halaman 1, lanjut halaman lain atau cari/filter kategori, lalu centang menu tambahan. Pilihan tersimpan untuk akun dan cabang yang sama pada tab browser tersebut. Toolbar menampilkan jumlah seluruh pilihan dan daftar nama untuk ditinjau, termasuk menu dari halaman lain. Pilih kategori tujuan atau isi nama kategori baru, lalu Simpan. Semua pilihan diterapkan sekaligus, pilihan dikosongkan setelah sukses, dan halaman menampilkan kategori hasilnya. Jika nama baru dan kategori lama sama-sama diisi, nama baru diprioritaskan.

Tombol Pilih di tabel ini hanya memilih menu kategori yang terlihat pada halaman saat ini, bukan seluruh database. Batalkan semua pilihan menghapus semua centang tersimpan. Penyimpanan lintas halaman memerlukan JavaScript dan sessionStorage browser; tidak mengikuti tab/browser lain dan berakhir saat tab ditutup. Server tetap membatasi perubahan ke menu cabang aktif. Tidak ada migrasi atau perubahan transaksi.

## Versi 2.25 — Atur layout kategori Menu & resep

Buka Atur layout di Menu & resep. Centang Tampilkan semua untuk semua kategori termasuk kategori baru; atau hilangkan centang itu, pilih satu/beberapa kategori serta Tanpa kategori bila diperlukan, lalu Simpan layout. Pilihan tersimpan di database per akun dan cabang serta tetap berlaku setelah login ulang. Minimal satu pilihan diperlukan. Kategori/menu tidak dihapus atau diubah oleh layout.

Dropdown filter dapat menampilkan kategori tertentu atau Semua kategori untuk sementara. Pilih Sesuai layout tersimpan untuk kembali ke layout. Setelah menyimpan layout, halaman kembali ke layout default tanpa filter sementara. Pilihan centang menu untuk penerapan kategori tetap terpisah dan tetap mendukung lintas halaman. Layout memakai susunan dua kolom tabel versi sebelumnya.

## Versi 2.26 — Pop-up hapus, cabang kerja pada slip, potongan absensi

Tombol Hapus karyawan/jabatan/payroll dan Batalkan penjualan/pengeluaran membuka dialog di halaman yang sedang dilihat. Rincian dampak penghapusan tetap ditampilkan; konfirmasi melakukan POST dengan CSRF. Pembatalan transaksi tetap membutuhkan alasan dan mempertahankan riwayat. Jika JavaScript/dialog browser tidak tersedia, halaman konfirmasi lama tetap dapat digunakan. Centang hapus pada baris form resep/bonus tetap mengikuti penyimpanan formulirnya.

Slip PDF dan preview menampilkan cabang kerja menurut absensi status Masuk/Terlambat dalam periode payroll (mingguan atau bulanan). Satu cabang hanya namanya; beberapa cabang menunjukkan jumlah hari tiap cabang. Hari izin/sakit/libur tidak dihitung sebagai bekerja. Payroll baru menyimpan snapshot nama/hari cabang. Untuk payroll lama tanpa snapshot, rincian diambil dari absensi sampai dilakukan Hitung ulang absensi. Bila belum ada hari hadir, cabang asal ditampilkan. Layout slip menyediakan centang Cabang kerja dan jumlah hari.

Buka Payroll atau Jabatan → Atur potongan absensi. Aturan per cabang, default nonaktif. Pilih apakah Izin, Sakit, Tidak hadir, atau Libur melebihi jatah dipotong. Izin/sakit/tidak hadir yang dipilih dipotong setiap hari dan tidak memakai jatah libur. Jatah libur berasal dari Edit karyawan dan hanya berlaku pada status Libur Jatah, dihitung kumulatif per bulan kalender. Contoh kuota 2: libur pertama dan kedua dalam bulan tidak dipotong; libur ketiga dst dipotong. Payroll mingguan melihat libur dari awal bulan untuk menentukan jatah terpakai; hanya hari dalam rentang payroll yang dibebankan, dan kuota direset pada bulan baru. Hari tanpa catatan absensi tidak otomatis dihitung tidak hadir.

Nominal potongan harian dapat diisi tetap. Bila 0, tarif = snapshot gaji pokok bulanan / jumlah hari kalender bulan tanggal absensi, dibulatkan ke dua desimal per hari. Gaji harian tidak dikurangi lagi karena hanya hadir yang dibayar. Rincian potongan otomatis terpisah dari potongan manual dan ikut mengurangi gaji bersih/laporan. Total potongan tidak boleh melebihi penghasilan; jika hitung ulang menghasilkan gaji negatif, perubahan dibatalkan.

Payroll baru menyimpan aturan saat dibuat; perubahan pengaturan tidak mengubah slip lama otomatis. Untuk payroll lama: Edit → Hitung ulang absensi → centang Gunakan aturan potongan absensi terbaru → konfirmasi. Tarif gaji tersimpan tetap digunakan; jika payroll legacy tidak punya tarif bulanan snapshot, penghitungan ulang dengan opsi ini mengambil tarif bulanan jabatan/karyawan saat ini sebagai dasar potongan. Jatah libur pada payroll tetap snapshot awal. Hitung ulang biasa mempertahankan aturan potongan tersimpan.

145 pengujian lulus; dialog dimuat GET dan konfirmasi hanya POST diuji lewat simulasi JavaScript, PDF diperiksa visual, migrasi salinan database menjaga jumlah data dan nominal lama. Browser interaktif dan Windows asli belum diuji di lingkungan ini. Backup database, jalankan MULAI_WINDOWS.bat untuk migrasi, lalu Ctrl+F5.

## Versi 2.27 — Hapus menu dipilih, toolbar laporan dan akun login

Menu & resep: centang menu (termasuk pilihan dari halaman/filter lain), klik Hapus menu dipilih. Pop-up menampilkan nama menu dan dampaknya. Menu yang belum dipakai dihapus permanen bersama resepnya. Menu yang dilindungi karena pernah dipakai pada penjualan/pemetaan POS menjadi Nonaktif; tidak menghapus riwayat, stok atau transaksi. Menu nonaktif tetap dapat dilihat dan diedit pada daftar. Tutup/Batal pada dialog tidak mengubah data. Server hanya menerima menu cabang aktif dan konfirmasi POST. Pilihan dikosongkan setelah berhasil.

Laporan keuangan: jenis laporan, input periode, Tampilkan, Unduh CSV dan Cetak disusun grid dengan tinggi tombol konsisten. Hanya input tanggal atau bulan yang sesuai jenis laporan ditampilkan. CSV mengikuti periode yang telah ditampilkan; klik Tampilkan setelah mengubah filter sebelum mengunduh. Tampilan menyusun ulang pada layar kecil.

Sidebar Akun & password: administrator/superuser dapat membuat akun operasional baru, dengan validasi password Django dan konfirmasi password. Akun baru tidak menjadi staff/superuser, meskipun ada permintaan field tambahan. Akun operasional tetap memiliki akses seluruh fitur/cabang usaha sebagaimana kebijakan aplikasi saat ini; belum ada pembatas modul/izin per cabang. Daftar akun hanya untuk administrator.

Ganti password saya tersedia bagi setiap akun login. Wajib memasukkan password lama, password baru dan pengulangannya; sesi pengguna yang mengganti password tetap aktif. Fitur ini tidak mengganti password akun lain. Nama pengguna/email/data akun tidak diubah. Akun/password baru disimpan pada database yang sedang digunakan; backup harus disimpan privat.

145 pengujian regresi dan 7 pengujian baru berhasil (pengujian terarah 12 mencakup 7 baru dan 5 alur terkait). Pemeriksaan sistem, migrasi dan sintaks JavaScript bersih. Tidak ada migrasi database tambahan pada versi ini.

## Versi 2.28 — Jatah gabungan libur, izin dan sakit

Di Atur potongan absensi tersedia Aturan jatah libur: Gabungan atau Terpisah. Mode Gabungan adalah pilihan awal untuk pengaturan baru. Aktifkan potongan otomatis agar diterapkan pada payroll baru. Jumlah jatah dapat diatur per karyawan melalui Edit karyawan (default 2 hari/bulan).

Gabungan: Libur Jatah, Izin dan Sakit memakai jatah bersama berdasarkan urutan tanggal. Dengan kuota 2, dua hari pertama dari ketiga status tersebut tidak dipotong; hari ketiga dst dipotong per hari. Contoh libur 2 + sakit 1 + izin 1 = 2 hari potongan. Sakit 1 + izin 1 + libur 1 = 1 hari potongan. Pilihan potong izin/sakit/libur individual hanya berlaku pada mode Terpisah, sehingga disembunyikan pada mode Gabungan. Tidak hadir mengikuti opsi potong tersendiri, di luar kuota gabungan.

Perhitungan melihat catatan dari awal bulan untuk menentukan kuota terpakai, tetapi hanya hari dalam periode payroll yang dibebankan. Kuota tidak diulang setiap minggu dan direset saat ganti bulan. Kalender absensi menunjukkan pemakaian gabungan sesuai pengaturan cabang. Gaji harian tetap tidak dipotong dua kali. Tarif nominal/rumus kalender dan pembatas gaji negatif tetap berlaku.

Aturan Terpisah mempertahankan opsi sebelumnya: kuota hanya Libur Jatah, izin/sakit/tidak hadir dapat dipotong langsung sesuai centang. Ini memungkinkan bisnis lain menetapkan kebijakannya sendiri.

Snapshot payroll lama tetap memakai aturan lamanya (snapshot tanpa mode dianggap Terpisah). Untuk memakai Gabungan pada slip yang sudah dibuat, atur kebijakan cabang lalu Edit payroll → Hitung ulang absensi → centang Gunakan aturan potongan absensi terbaru. Jumlah kuota pada payroll memakai snapshot saat dibuat, bukan otomatis mengikuti edit karyawan berikutnya.

13 pengujian terarah berhasil meliputi kuota gabungan/terpisah, urutan status, lintas bulan, payroll mingguan, hitung ulang, data lama dan gaji harian. Migrasi berhasil pada database salinan.

## Versi 2.29 — Tombol dashboard sejajar

Filter bulan ringkasan, tanggal penjualan, dan bulan absensi memakai input/tombol setinggi 44px. Lebar tombol seragam, kolom aksi rata kanan, label konsisten, dan kontrol menyusun ulang pada layar kecil. Mengubah filter ringkasan atau penjualan mempertahankan filter absensi. Tidak ada perubahan perhitungan atau database.

## Versi 2.30 — Total gaji yang sudah diberikan

Pada tab Payroll tersedia ringkasan Gaji yang sudah diberikan, default bulan ini, dengan input bulan pembayaran. Rincian menampilkan tanggal, nama karyawan/periode slip, nominal snapshot, status dan catatan. Dashboard memakai bulan ringkasan yang dipilih dan menampilkan total pembayaran pada cabang aktif. Filter bulan pembayaran terpisah dari filter bulan/periode slip payroll. Ringkasan pembayaran mencakup seluruh karyawan cabang aktif, tidak dibatasi pencarian slip di bawahnya.

Setelah uang benar-benar diberikan, klik Catat sudah dibayar pada slip, isi tanggal dan catatan, lalu Simpan. Ini mencatat pelunasan penuh sebesar gaji bersih, bukan cicilan atau transfer uang. Tanggal masa depan dan gaji bersih nol/negatif ditolak. Nominal diperiksa kembali saat simpan; perubahan sejak form dibuka harus ditinjau ulang. Satu slip hanya memiliki satu pembayaran aktif, sehingga pengiriman ganda tidak menggandakan total.

Total mengikuti tanggal pembayaran sebenarnya, bukan bulan gaji atau tanggal pembuatan slip. Contoh slip September dibayar 1 Oktober masuk ringkasan Oktober. Payroll lama tidak otomatis diasumsikan sudah dibayar; catat tanggal pembayaran riilnya untuk melengkapi rekap.

Koreksi pembayaran membuka pop-up alasan dan menandai catatan dibatalkan; nominal tidak dihitung pada total aktif, riwayat tetap tersimpan. Ini bukan pengembalian dana. Setelah koreksi, slip dapat diperbarui dan dicatat dibayar kembali dengan nominal/tanggal benar. Slip dengan pembayaran aktif tidak dapat diedit/dihitung ulang. Payroll atau karyawan yang memiliki riwayat pembayaran tidak dapat dihapus; gunakan Nonaktif pada karyawan untuk menjaga jejak transaksi. Riwayat pembayaran menyimpan nominal, nama karyawan dan periode saat pencatatan.

Pencatatan pembayaran tidak menambah biaya payroll kedua kali pada laporan laba. Laporan laba tetap membukukan payroll berdasarkan periode seperti sebelumnya; ringkasan dibayar adalah informasi uang yang sudah diberikan. Semua akun operasional yang dapat mengelola payroll dapat mencatat/mengoreksi pembayaran sesuai kebijakan akses aplikasi saat ini.

155 pengujian regresi berhasil; 7 pengujian baru dan pengujian ulang alur terkait berhasil (18 pengujian terarah). Migrasi salinan database mempertahankan data lama dan tidak membuat pembayaran asumsi. Backup database terbaru, jalankan MULAI_WINDOWS.bat untuk migrasi, lalu Ctrl+F5.

## Versi 2.31 — Karyawan antarcabang dengan absensi bersama

Pilih cabang tujuan dari dropdown kiri atas → Karyawan → Impor karyawan cabang lain. Pilih cabang sumber, centang orang yang benar, lalu konfirmasi Hubungkan karyawan dipilih. Tidak ada salinan karyawan atau absensi: cabang tujuan mendapat akses ke identitas karyawan yang sama. Impor ulang karyawan yang sama dilewati; sumber yang telah mengimpor karyawan juga dapat menghubungkannya ke cabang ketiga.

Riwayat absensi lama langsung terlihat dari cabang terhubung. Perubahan status, jam masuk/pulang, bonus tepat waktu, catatan, tanggal dan cabang bertugas disimpan satu kali dan terlihat dari semua cabang terhubung. Tidak perlu impor ulang setelah mengubah absensi. Pilih tanggal yang sama untuk memeriksa perubahan. Catatan baru tetap milik identitas karyawan/cabang asal, dengan cabang bertugas terpisah; pilihan cabang bertugas untuk catatan baru mengikuti cabang aktif bila belum ditentukan.

Data utama (nama, kode, status, jabatan dan aturan gaji) hanya diedit di cabang asal, lalu otomatis terlihat di cabang terhubung karena memakai satu identitas. Karyawan bersama tidak dapat dihapus melalui daftar; gunakan status Nonaktif dari cabang asal untuk mempertahankan riwayat. Ini bukan penyalinan atau pemindahan data ke orang baru.

Payroll/pembayaran tetap dikelola dari cabang asal. Membuat payroll karyawan bersama dari cabang tujuan ditolak untuk mencegah gaji ganda. Absensi dari cabang mana pun ikut tersedia saat menghitung payroll di cabang asal. Slip/payroll yang sudah tersimpan tidak berubah otomatis saat absensi diedit: gunakan Hitung ulang absensi seperti sebelumnya; payroll yang sudah dibayar perlu koreksi pencatatan pembayaran dahulu. Beban gaji tidak dialokasikan otomatis ke cabang bertugas.

Nama/kode sama tidak otomatis berarti orang yang sama. Impor memilih ID karyawan sumber yang eksplisit. Jika kode bentrok dengan identitas lain di cabang tujuan, seluruh impor dibatalkan; selesaikan kode yang bentrok dahulu. Dua record yang sebelumnya dibuat manual untuk satu orang belum memiliki fitur penggabungan riwayat otomatis. Jangan membuat record baru di cabang tujuan jika ingin data tersinkron; gunakan fitur impor ini.

Karyawan dan absensi yang belum dihubungkan tetap mengikuti pembatas cabang seperti sebelumnya. Semua akun operasional di workspace masih mengikuti kebijakan akses cabang yang sama. Ringkasan absensi tiap cabang mencakup karyawan yang terhubung (bukan semata jumlah orang yang bertugas fisik di cabang itu); cabang kerja per tanggal tetap dapat dilihat di kalender/slip.

168 pengujian lulus, termasuk sinkronisasi dua arah, satu record per hari, impor ulang, penolakan bentrok kode, pilihan form yang diperbarui saat pindah cabang, dan penghitungan dashboard tanpa duplikasi pada tiga cabang. Migrasi database salinan mempertahankan data lama tanpa membuat hubungan identitas otomatis. Backup db.sqlite3 terbaru, jalankan MULAI_WINDOWS.bat untuk migrasi, lalu Ctrl+F5.

## Versi 2.32 — Nama unduhan slip gaji

Unduhan PDF menggunakan `slipgaji_nama_tanggal_bulan.pdf`, misalnya `slipgaji_rahman_30_oktober.pdf`. Tanggal mengikuti akhir periode gaji; slip bulanan lama memakai tanggal terakhir bulan tersebut. Spasi nama menjadi garis bawah.

## Versi 2.33 — Slip gaji PNG

Klik Unduh PNG di daftar payroll atau preview slip. Desain dan layout mengikuti PDF, resolusi 144 dpi; halaman panjang digabung vertikal. Nama file mengikuti slipgaji_nama_tanggal_bulan.png. Jalankan MULAI_WINDOWS.bat untuk memasang dependensi tambahan secara otomatis.

## Versi 2.34 — Impor Grab dengan pesanan batal

Pesanan batal dengan status eksplisit dan tujuh kolom nominal berupa tanda minus dilewati. Jumlah ringkasan Grab mencakup pesanan selesai dan batal, sedangkan jumlah penjualan ERP hanya pesanan selesai. Total nominal tetap wajib cocok seluruhnya.

## Versi 2.35 — Tata letak kategori dan tombol

Kartu kategori mengalir dalam dua kolom mandiri sehingga kategori pendek dapat mengisi ruang di samping kategori panjang. Kartu tidak dipotong antarkolom; layar kecil tetap satu kolom. Tombol utama dan kontrol filter setinggi minimal 44px, tombol tabel 34px, jarak antaraksi seragam dan responsif. Cache aset diperbarui.

## Versi 2.36 — Laporan Transaksi GoFood

Impor menerima Laporan Transaksi GoFood dengan tanggal ISO beserta zona waktu, tipe GoFood Pesan Antar dan mata uang IDR. Rincian biaya dikurangi pengurangan biaya layanan wajib cocok dengan Total Biaya, lalu Penjualan dikurangi Total Biaya wajib cocok dengan Pendapatan Bersih. Kolom kosong biaya dianggap nol. Format GoFood lama tetap didukung. Transaksi refund/jenis lain ditolak untuk ditinjau manual. Tidak menggandakan transaksi dari format laporan berbeda pada kanal/tanggal yang sudah tercatat.

## Versi 2.37 — Tampilkan semua menu secara lengkap

Mode Semua kategori serta layout Tampilkan semua menampilkan seluruh menu hasil pencarian dalam satu halaman tanpa batas 20 menu. Filter kategori tertentu tetap menggunakan halaman.

## Versi 2.38 — Tampilan laporan keuangan

Menghapus blok notifikasi di atas judul laporan keuangan: HPP nol/estimasi, pembayaran POS dan porsi POS. Data serta perhitungan laporan tetap tersimpan seperti sebelumnya.

## Versi 2.39 — Absensi beberapa tanggal

Centang beberapa tanggal pada kalender karyawan/bulan yang dipilih, isi formulir lalu klik Simpan N tanggal. Seluruh isian mengganti catatan tanggal terpilih; tanggal lain tidak berubah. Tanpa centang tetap simpan satu tanggal terbuka. Maksimal 31 pilihan, tanggal harus dalam bulan yang sama dan sesudah mulai bekerja. Semua tanggal divalidasi sebelum disimpan dalam satu transaksi. Pilihan bertahan saat membuka tanggal lain tanpa pindah bulan. Cabang terhubung tetap memakai data absensi yang sama.

## Versi 2.40 — Pembayaran campuran POS

Ekspor dengan Metode Pembayaran Tunai, Non Tunai didukung. Karena POS tidak memberi nominal per metode pada struk tersebut, seluruh total dicatat sekali pada kategori Campuran (rincian nominal tidak tersedia), bukan ditambahkan ke Tunai maupun QRIS. Metode yang tidak dikenal tetap ditolak.

## Versi 2.41 — UI absensi

Filter karyawan dan bulan sejajar, kartu ringkasan tiga kolom, kotak tanggal seragam dengan checkbox di pojok kanan atas, penghitung pilihan dan tombol hapus sejajar. Formulir simpan memenuhi lebar panel dan berada di bawah kalender pada layar kecil.

## Versi 2.42 — Pilih sebulan dan scroll absensi

Centang Pilih seluruh bulan untuk memilih seluruh tanggal kalender, atau hapus centang untuk membatalkan. Pergantian bulan lewat panah memuat kalender tanpa pindah posisi scroll; filter bulan ikut diperbarui. Pilihan tanggal bulan lama tidak terbawa ke bulan baru. Filter bulan melalui formulir juga memulihkan scroll setelah halaman dimuat. Validasi tanggal termasuk mulai kerja tetap berlaku.

## Versi 2.43 — Scroll filter dashboard

Filter bulan ringkasan, tanggal kontribusi penjualan dan bulan absensi memulihkan posisi scroll setelah ditampilkan. Tombol Sejak awal juga didukung. Posisi hanya disimpan sementara di tab browser yang sama.

## Versi 2.44 — Top 5 hari penjualan

Dashboard menampilkan lima tanggal dengan omzet bruto tertinggi pada bulan ringkasan terpilih, seluruh kanal cabang aktif digabung per tanggal. Tabel memuat nama hari, tanggal, omzet bruto, pendapatan bersih dan jumlah pesanan. Transaksi dibatalkan dan hari tanpa omzet dikecualikan. Nilai sama diurutkan berdasarkan jumlah pesanan, lalu tanggal lebih awal.

## Versi 2.45 — Keseragaman dashboard

Ringkasan penjualan empat kartu sejajar, panel analisis berjarak seragam, pasangan panel berlebar sama, dan tema abu-abu/lime yang konsisten. Kartu ringkasan menyesuaikan menjadi dua/satu kolom di layar kecil; filter dan tampilan tabel tetap responsif.

## Versi 2.46 — Input Rekap Manual

Form rekap penjualan menjadi Input Rekap Manual: isi tanggal, kanal, jumlah pesanan, omzet, potongan, HPP dan catatan tanpa file. Perhitungan serta validasi duplikasi tetap berlaku.

## Versi 2.47 — Seleksi absensi dengan drag

Pada komputer, tahan klik pada kotak tanggal lalu drag ke tanggal akhir untuk memilih rentang hari. Mulai dari tanggal yang sudah dicentang untuk membatalkan pilihan pada rentang tersebut. Klik biasa tetap membuka formulir tanggal; centang langsung dan pilih seluruh bulan tetap tersedia. Drag tidak menyimpan otomatis. Kotak centang diperkecil menjadi 12px dengan area klik berpadding. Sentuhan HP tetap memakai centang agar gulir tidak terganggu.

## Versi 2.48 — Petunjuk dan notifikasi seragam

Kotak petunjuk di seluruh modul memakai ikon, ukuran teks, padding dan jarak seragam. Informasi berwarna hijau lembut, peringatan kuning lembut dan error merah lembut. Pesan hasil tindakan serta bantuan isian mengikuti ritme yang sama, responsif di HP. Petunjuk absensi, pengeluaran dan rekap manual dipersingkat.

## Versi 2.49 — Pembayaran tunai dan QRIS manual

Pada Penjualan → Input Rekap Manual, pilih kanal Offline. Isi nominal tunai dan/atau QRIS bila rincian diketahui. Jumlah keduanya harus sama dengan omzet bruto dikurangi voucher, sebelum komisi dan biaya admin. Rincian tampil pada penjualan dan bagian Rincian pembayaran di dashboard. Jika rekap yang sama punya rincian dari XLSX POS, dashboard memakai isian manual. Jalankan MULAI_WINDOWS.bat untuk memperbarui skema database.

## Versi 2.50 — Porsi terjual dan pembayaran Offline POS

Pada Penjualan → Input Rekap Manual, masukkan Porsi terjual untuk tanggal rekap. Kosongkan jika jumlah porsi belum diketahui. Tunai dan QRIS tampil berdampingan di bagian Pembayaran Offline POS. Rincian pembayaran muncul di dashboard dan CSV laporan. Jika rekap yang sama juga memiliki rincian XLSX POS, angka manual dipakai untuk total porsi dan pembayaran ketika diisi. Jalankan MULAI_WINDOWS.bat untuk memperbarui database yang sudah ada.
