# Panduan deployment ERP

Arsitektur yang disiapkan: Django memakai PostgreSQL di server aplikasi; Cloudflare Pages memakai `_worker.js` sebagai proxy dan memberi alamat `*.pages.dev`. Database SQLite lokal dan secret lokal tidak diunggah.

## 1. Siapkan PostgreSQL

Buat database PostgreSQL yang dapat diakses dari Render dan simpan connection string-nya. Jangan masukkan URL database ke GitHub. Render Free Postgres bukan pilihan untuk data operasional permanen karena masa berlakunya terbatas. Siapkan backup sebelum memindahkan data ERP.

## 2. Deploy backend Django

Setelah source tersedia di branch `main` GitHub:

1. Buat Web Service dari `render.yaml` di dashboard Render.
2. Saat diminta, isi `DATABASE_URL` dengan URL PostgreSQL.
3. Biarkan Render membuat `ERP_SECRET_KEY` secara acak.
4. Tunggu build dan migration selesai, lalu periksa alamat `.onrender.com/health/`.

Free Web Service Render dapat tidur setelah tidak aktif dan membutuhkan waktu untuk menyala kembali.

## 3. Deploy alamat Cloudflare Pages

1. Buat Pages project yang terhubung ke repository GitHub, branch `main`.
2. Gunakan output directory `cloudflare-pages`; folder ini memakai `_worker.js` Advanced Mode.
3. Tambahkan environment variable `ERP_ORIGIN` berisi origin backend, contoh `https://nama-service.onrender.com` tanpa path.
4. Deploy. Cloudflare akan memberikan alamat `*.pages.dev`.

## Migrasi data lama

Deployment tidak otomatis menyalin data dari `db.sqlite3`. Pastikan backup terbaru tersedia dan rencanakan migrasi SQLite ke PostgreSQL sebelum ERP dipakai. Jangan unggah database atau secret key ke repository publik.
