from datetime import date
from decimal import Decimal as D
from django.test import TestCase
from django.contrib.auth import get_user_model
from django.urls import reverse
from .models import Product,Ingredient,Recipe
from .forms import ProductForm
from .pos_import import snapshot_lines

class ChannelHPPTests(TestCase):
    def setUp(self):
        self.client.force_login(get_user_model().objects.create_user('hppowner',password='testing'))
        self.p=Product.objects.create(name='Menu Test',price=12000,manual_cost=4000,hpp_shopeefood=5000,hpp_grabfood=5500,hpp_gofood=6000)
    def test_independent_channel_values_and_fallback(self):
        self.assertEqual(self.p.cost_for_channel('ShopeeFood'),5000)
        self.assertEqual(self.p.cost_for_channel('GrabFood'),5500)
        self.assertEqual(self.p.cost_for_channel('GoFood'),6000)
        self.assertEqual(self.p.cost_for_channel('Offline'),4000)
        self.p.hpp_grabfood=None
        self.assertEqual(self.p.cost_for_channel('GrabFood'),4000)
        i=Ingredient.objects.create(name='Bumbu HPP',stock=1000,average_cost=30)
        Recipe.objects.create(product=self.p,ingredient=i,quantity=50)
        self.assertEqual(self.p.cost_for_channel('GrabFood'),1500)
        self.assertEqual(self.p.cost_for_channel('GoFood'),6000)
    def test_form_persists_and_can_clear_override(self):
        data={'name':self.p.name,'price':12000,'manual_cost':4000,'hpp_shopeefood':5000,'hpp_grabfood':5500,'hpp_gofood':6000,'active':'on','recipes-TOTAL_FORMS':0,'recipes-INITIAL_FORMS':0}
        self.assertEqual(self.client.post(reverse('product_edit',args=[self.p.pk]),data).status_code,302)
        self.p.refresh_from_db();self.assertEqual(self.p.hpp_grabfood,D('5500'))
        data['hpp_grabfood']=''
        self.assertEqual(self.client.post(reverse('product_edit',args=[self.p.pk]),data).status_code,302)
        self.p.refresh_from_db();self.assertIsNone(self.p.hpp_grabfood)
        data['hpp_gofood']='-1'
        self.assertFalse(ProductForm(data,instance=self.p).is_valid())
        self.assertContains(self.client.get(reverse('product_list')),'HPP SHOPEEFOOD')
    def test_pos_snapshot_uses_channel_override(self):
        draft={'channel':'GrabFood','items':[{'name':'Menu Test','quantity':'3'}]}
        rows=snapshot_lines(draft,{'product_0':self.p})
        self.assertEqual(rows[0]['unit_cost'],'5500.00');self.assertEqual(rows[0]['total'],'16500.00')
        self.assertEqual(rows[0]['cost_basis'],'HPP manual GrabFood')
        draft['channel']='Offline'
        self.assertEqual(snapshot_lines(draft,{'product_0':self.p})[0]['total'],'12000.00')
