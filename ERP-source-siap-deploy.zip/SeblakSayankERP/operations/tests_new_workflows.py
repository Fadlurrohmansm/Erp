from datetime import date
from decimal import Decimal
from django.test import TestCase
from django.urls import reverse
from django.contrib.auth import get_user_model
from core.models import Employee,Attendance,Payroll
from tenancy.models import Branch
from .models import Product,MenuCategory,Ingredient,Recipe,Channel
from .services import post_daily_recap
import uuid

class NewWorkflowTests(TestCase):
    def setUp(self):
        self.user=get_user_model().objects.create_user('newflows',password='testing');self.client.force_login(self.user)
        self.a=Branch.objects.first();self.b=Branch.objects.create(name='Sumber')
        self.p=Product.objects.create(name='Menu lokal',price=10000)
    def test_bulk_category_and_foreign_menu_protected(self):
        foreign=Product.objects.create(branch=self.b,name='Menu asing',price=1)
        response=self.client.post(reverse('product_list'),{'selected':[self.p.pk,foreign.pk],'category_name':'Adds on topping'})
        self.assertEqual(response.status_code,302)
        self.p.refresh_from_db();foreign.refresh_from_db()
        self.assertEqual(self.p.category.name,'Adds on topping');self.assertIsNone(foreign.category)
        self.assertContains(self.client.get(reverse('product_list')),'Adds on topping')
    def test_import_copies_recipes_without_stock_and_is_repeat_safe(self):
        cat=MenuCategory.objects.create(branch=self.b,name='Paket seblak')
        source=Product.objects.create(branch=self.b,name='Paket A',category=cat,price=15000,hpp_grabfood=5000)
        ingredient=Ingredient.objects.create(branch=self.b,name='Bumbu',unit='g',stock=999,average_cost=20)
        Recipe.objects.create(branch=self.b,product=source,ingredient=ingredient,quantity=50)
        for _ in range(2):
            self.assertEqual(self.client.post(reverse('product_import_branch'),{'source':self.b.pk,'confirm':'on'}).status_code,302)
        copied=Product.objects.get(branch=self.a,name='Paket A')
        self.assertEqual(copied.category.branch,self.a);self.assertEqual(copied.hpp_grabfood,5000)
        recipe=copied.recipes.get();self.assertEqual(recipe.quantity,50);self.assertEqual(recipe.ingredient.stock,0)
        self.assertEqual(recipe.ingredient.branch,self.a);self.assertEqual(copied.estimated_cost,1000)
        self.assertEqual(Product.objects.filter(branch=self.a,name='Paket A').count(),1)
    def test_incompatible_ingredient_rolls_back_entire_import(self):
        source=Product.objects.create(branch=self.b,name='Conflict',price=1)
        foreign=Ingredient.objects.create(branch=self.b,name='Air',unit='ml')
        Recipe.objects.create(branch=self.b,product=source,ingredient=foreign,quantity=1)
        Ingredient.objects.create(name='Air',unit='g')
        self.client.post(reverse('product_import_branch'),{'source':self.b.pk,'confirm':'on'})
        self.assertFalse(Product.objects.filter(branch=self.a,name='Conflict').exists())
    def test_daily_report_books_only_period_end_and_matches_csv(self):
        employee=Employee.objects.create(employee_code='D',full_name='Daily',position='Crew',hire_date=date(2026,1,1))
        Payroll.objects.create(employee=employee,month=10,year=2026,start_date=date(2026,10,24),end_date=date(2026,10,30),base_salary=300000)
        post_daily_recap(data=dict(token=uuid.uuid4(),date=date(2026,10,28),channel=Channel.objects.get(name='Offline'),order_count=1,subtotal=Decimal(10000),voucher_amount=Decimal(0),commission_amount=Decimal(0),other_fees=Decimal(0),cost=Decimal(0)),user=self.user)
        response=self.client.get(reverse('reports'),{'mode':'daily','day':'2026-10-28'})
        self.assertEqual(response.context['stats']['revenue'],10000);self.assertEqual(response.context['stats']['payroll'],0)
        response=self.client.get(reverse('reports'),{'mode':'daily','day':'2026-10-30'})
        self.assertEqual(response.context['stats']['payroll'],300000);self.assertEqual(response.context['stats']['revenue'],0)
        response=self.client.get(reverse('reports'),{'mode':'daily','day':'2026-10-28','export':'csv'})
        self.assertIn('2026-10-28',response.content.decode('utf-8-sig'))
    def test_dashboard_attendance_since_hire_and_month_filter(self):
        employee=Employee.objects.create(employee_code='A',full_name='Attendance Test',position='Crew',hire_date=date(2026,1,1))
        Attendance.objects.create(employee=employee,date=date(2026,1,2),status='present',punctual=True)
        Attendance.objects.create(employee=employee,date=date(2026,2,2),status='sick')
        response=self.client.get(reverse('dashboard'))
        row=response.context['attendance_rows'][0];self.assertEqual(row['present'],1);self.assertEqual(row['sick'],1)
        response=self.client.get(reverse('dashboard'),{'attendance_month':'2026-02'})
        row=response.context['attendance_rows'][0];self.assertEqual(row['present'],0);self.assertEqual(row['sick'],1)
