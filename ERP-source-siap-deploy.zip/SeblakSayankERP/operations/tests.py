import uuid
from datetime import date
from decimal import Decimal as D
from django.test import TestCase
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.urls import reverse
from django.utils import timezone
from core.models import Employee, Payroll
from .models import Ingredient, Product, Recipe, Channel, Sale, SaleItem, StockMovement, Expense
from .services import receive_stock, count_stock, post_sale, void_sale
from .reporting import summary, period
from .forms import IngredientForm, SaleForm, ExpenseForm


class OperationsTests(TestCase):
    def setUp(self):
        self.user=get_user_model().objects.create_user('owner',password='test-password')
        self.client.force_login(self.user)
        self.today=timezone.localdate()
        self.i=Ingredient.objects.create(name='Bumbu',minimum_stock=100)
        self.p=Product.objects.create(name='Seblak Sayank',price=12000,manual_cost=5000)
        self.channel=Channel.objects.get(name='Offline')
        self.purchase(D('1000'),D('20000'))

    def purchase(self,qty,cost,**extra):
        return receive_stock(ingredient=self.i,quantity=qty,total_cost=cost,user=self.user,date=self.today,**extra)

    def sale(self,quantity=2,price=D('12000'),token=None,channel=None):
        header=dict(token=token or uuid.uuid4(),date=self.today,channel=channel or self.channel,payment_method='cash',notes='')
        return post_sale(header=header,rows=[dict(product=self.p,quantity=quantity,unit_price=price)],user=self.user)

    def recipe(self,quantity='50'):
        return Recipe.objects.create(product=self.p,ingredient=self.i,quantity=D(quantity))

    def test_weighted_average_purchase(self):
        self.purchase(D('1000'),D('40000'))
        self.i.refresh_from_db()
        self.assertEqual(self.i.stock,D('2000'))
        self.assertEqual(self.i.average_cost,D('30'))
        self.assertEqual(self.i.stock_value,D('60000'))

    def test_recipe_consumption_and_manual_fallback(self):
        manual=self.sale()
        self.assertEqual(manual.cost,D('10000'))
        self.i.refresh_from_db();self.assertEqual(self.i.stock,D('1000'))
        self.recipe()
        s=self.sale()
        self.i.refresh_from_db()
        self.assertEqual(s.cost,D('2000'))
        self.assertEqual(self.i.stock,D('900'))
        self.assertEqual(self.i.stock_value,D('18000'))

    def test_voucher_before_commission_snapshot(self):
        self.channel.voucher_rate=D('22');self.channel.commission_rate=D('25');self.channel.save()
        s=self.sale(quantity=1,price=D('20000'))
        self.assertEqual((s.voucher_amount,s.commission_amount,s.net_revenue),(D('4400'),D('3900'),D('11700')))
        self.channel.commission_rate=99;self.channel.save()
        self.p.manual_cost=1;self.p.save()
        s.refresh_from_db();self.assertEqual(s.cost,D('5000'));self.assertEqual(s.commission_rate,D('25'))

    def test_insufficient_stock_rolls_back_all(self):
        self.recipe('600')
        with self.assertRaises(ValidationError):self.sale()
        self.assertFalse(Sale.objects.exists())
        self.assertFalse(SaleItem.objects.exists())
        self.i.refresh_from_db();self.assertEqual(self.i.stock,D('1000'))
        self.assertEqual(StockMovement.objects.count(),1)

    def test_shared_ingredient_across_menu_rows(self):
        self.recipe('600')
        p2=Product.objects.create(name='Seblak Baper',price=13000)
        Recipe.objects.create(product=p2,ingredient=self.i,quantity=500)
        with self.assertRaises(ValidationError):
            post_sale(header=dict(token=uuid.uuid4(),date=self.today,channel=self.channel,payment_method='cash'),rows=[dict(product=self.p,quantity=1,unit_price=D('12000')),dict(product=p2,quantity=1,unit_price=D('13000'))],user=self.user)
        self.assertFalse(Sale.objects.exists())

    def test_idempotent_sale_and_void(self):
        self.recipe();token=uuid.uuid4()
        s=self.sale(token=token)
        again=self.sale(token=token)
        self.assertEqual(s.pk,again.pk)
        self.i.refresh_from_db();self.assertEqual(self.i.stock,D('900'))
        void_sale(s,user=self.user,reason='Pesanan batal')
        void_sale(s,user=self.user,reason='Dikirim ulang')
        self.i.refresh_from_db();s.refresh_from_db()
        self.assertEqual(self.i.stock,D('1000'))
        self.assertEqual(s.status,'void')
        self.assertEqual(s.movements.filter(kind='reversal').count(),1)

    def test_reversal_restores_historical_value_after_purchase(self):
        self.recipe();s=self.sale()
        self.purchase(D('100'),D('4000'))
        void_sale(s,user=self.user,reason='Batal')
        self.i.refresh_from_db()
        self.assertEqual(self.i.stock,D('1100'))
        self.assertAlmostEqual(self.i.stock_value,D('24000'),places=2)

    def test_stock_count_and_negative_rejection(self):
        count_stock(ingredient=self.i,counted=D('900'),user=self.user,date=self.today,notes='Rusak')
        self.i.refresh_from_db();self.assertEqual(self.i.stock_value,D('18000'))
        with self.assertRaises(ValidationError):count_stock(ingredient=self.i,counted=D('-1'),user=self.user,date=self.today)
        with self.assertRaises(ValidationError):count_stock(ingredient=self.i,counted=D('900'),user=self.user,date=self.today)

    def test_idempotent_purchase_and_count(self):
        token=uuid.uuid4()
        self.purchase(D('100'),D('1000'),token=token)
        self.purchase(D('100'),D('1000'),token=token)
        self.i.refresh_from_db();self.assertEqual(self.i.stock,D('1100'))
        token2=uuid.uuid4()
        for _ in range(2):count_stock(ingredient=self.i,counted=D('1000'),user=self.user,date=self.today,token=token2)
        self.assertEqual(StockMovement.objects.filter(kind='count').count(),1)

    def test_profit_no_double_count_purchase(self):
        self.recipe();s=self.sale()
        Expense.objects.create(date=self.today,category='rent',description='Sewa',amount=3000,created_by=self.user)
        e=Employee.objects.create(employee_code='E01',full_name='Tim',position='Crew',hire_date=self.today,base_salary=1000)
        Payroll.objects.create(employee=e,month=self.today.month,year=self.today.year,base_salary=1000)
        start,end=period(self.today.strftime('%Y-%m'))
        data=summary(start,end)
        self.assertEqual(data['purchases'],D('20000'))
        self.assertEqual(data['profit'],D('18000')) # 24k - 2k HPP - 3k expense - 1k payroll
        count_stock(ingredient=self.i,counted=D('800'),user=self.user,date=self.today,notes='Bahan rusak')
        self.assertEqual(summary(start,end)['profit'],D('16000'))
        void_sale(s,user=self.user,reason='Pesanan batal')
        self.assertEqual(summary(start,end)['revenue'],0)

    def test_unit_cannot_change_after_history(self):
        form=IngredientForm(dict(name=self.i.name,unit='pcs',minimum_stock=0,active=True),instance=self.i)
        self.assertFalse(form.is_valid());self.assertIn('unit',form.errors)

    def test_expense_form_rejects_invalid_amount_future(self):
        self.assertFalse(ExpenseForm(dict(date='2099-01-01',category='rent',description='Sewa',amount=-1,token=uuid.uuid4())).is_valid())

    def test_pages_render_empty_and_populated(self):
        for name in ['dashboard','product_list','product_create','inventory','ingredient_create','purchase_create','stock_count','stock_movements','sale_list','sale_create','expense_list','expense_create','reports','business_settings']:
            response=self.client.get(reverse(name));self.assertEqual(response.status_code,200,name)
        s=self.sale()
        for name,args in [('sale_detail',[s.pk]),('sale_cancel',[s.pk]),('product_edit',[self.p.pk]),('ingredient_edit',[self.i.pk])]:
            self.assertEqual(self.client.get(reverse(name,args=args)).status_code,200,name)
        response=self.client.get(reverse('reports')+'?export=csv')
        self.assertEqual(response.status_code,200)
        self.assertIn('Laba operasional',response.content.decode('utf-8-sig'))

    def test_unauthenticated_blocked(self):
        self.client.logout()
        for name in ['sale_list','inventory','reports','business_settings','expense_create']:
            self.assertEqual(self.client.get(reverse(name)).status_code,302)

    def test_backup_superuser_only_and_post_only(self):
        self.assertEqual(self.client.get(reverse('backup_download')).status_code,405)
        self.assertEqual(self.client.post(reverse('backup_download')).status_code,403)

    def recap_data(self, **overrides):
        data=dict(token=str(uuid.uuid4()),date=self.today.isoformat(),channel=self.channel.pk,order_count=25,subtotal='300000',voucher_amount='20000',commission_amount='50000',other_fees='1000',cost='120000')
        data.update(overrides)
        return data

    def test_post_sale_form_and_duplicate_request(self):
        data=self.recap_data()
        for _ in range(2):self.assertEqual(self.client.post(reverse('sale_create'),data).status_code,302)
        s=Sale.objects.get()
        self.assertTrue(s.is_recap)
        self.assertEqual(s.net_revenue,D('229000'))
        self.assertEqual(s.gross_profit,D('109000'))
        self.i.refresh_from_db();self.assertEqual(self.i.stock,D('1000'))
        self.assertFalse(s.items.exists());self.assertFalse(s.movements.exists())

    def test_manual_offline_payment_split_reconciles_and_is_counted_once(self):
        from .models import POSCostImport

        offline = Channel.objects.get(name='Offline')
        invalid = self.recap_data(channel=offline.pk, manual_cash='150000', manual_qris='100000')
        response = self.client.post(reverse('sale_create'), invalid)
        self.assertEqual(response.status_code, 200)
        self.assertFalse(Sale.objects.exists())

        data = self.recap_data(
            channel=offline.pk, commission_amount='0', manual_cash='150000', manual_qris='130000',
            manual_portions='32',
        )
        self.assertEqual(self.client.post(reverse('sale_create'), data).status_code, 302)
        sale = Sale.objects.get()
        self.assertEqual(sale.net_revenue, D('279000'))
        self.assertEqual(sale.manual_cash, D('150000'))
        self.assertEqual(sale.manual_qris, D('130000'))
        self.assertEqual(sale.manual_portions, 32)
        POSCostImport.objects.create(
            sale=sale, fingerprint='fixture', filename='pos.xlsx', previous_cost=sale.cost,
            total_cost=sale.cost, created_by=self.user,
            payments={'mixed': {'amount': '279000', 'orders': 25}},
            lines=[{'sales_kind': 'main', 'quantity': 30}],
        )
        stats = summary(self.today, self.today)
        self.assertEqual(stats['offline_payments']['cash']['amount'], D('150000'))
        self.assertEqual(stats['offline_payments']['qris']['amount'], D('130000'))
        self.assertEqual(stats['offline_payments']['mixed']['amount'], 0)
        self.assertEqual(stats['pos_portions'], 30)
        self.assertEqual(stats['portions'], 32)
        self.assertContains(self.client.get(reverse('dashboard')), '32 porsi tercatat')
        self.assertEqual(stats['revenue'], D('279000'))
        self.assertContains(self.client.get(reverse('sale_detail', args=[sale.pk])), 'QRIS Rp130.000')

    def test_recap_duplicate_channel_date_and_replacement(self):
        self.client.post(reverse('sale_create'),self.recap_data())
        self.assertEqual(self.client.post(reverse('sale_create'),self.recap_data()).status_code,200)
        self.assertEqual(Sale.objects.count(),1)
        s=Sale.objects.get();void_sale(s,user=self.user,reason='Koreksi POS')
        self.assertEqual(self.client.post(reverse('sale_create'),self.recap_data()).status_code,302)
        self.assertEqual(Sale.objects.filter(status='posted').count(),1)
        self.i.refresh_from_db();self.assertEqual(self.i.stock,D('1000'))

    def test_recap_fees_future_and_negative_validation(self):
        for overrides in [dict(voucher_amount='400000'),dict(cost='-1'),dict(order_count='0'),dict(date='2099-01-01')]:
            self.assertEqual(self.client.post(reverse('sale_create'),self.recap_data(**overrides)).status_code,200)
        self.assertFalse(Sale.objects.exists())

    def test_all_four_channels_report_order_counts_and_stock_no_double_count(self):
        for channel in Channel.objects.all():
            self.assertEqual(self.client.post(reverse('sale_create'),self.recap_data(channel=channel.pk)).status_code,302)
        count_stock(ingredient=self.i,counted=D('500'),user=self.user,date=self.today,notes='Pemakaian sudah di HPP POS')
        start,end=period(self.today.strftime('%Y-%m'))
        data=summary(start,end)
        self.assertEqual(data['orders'],100)
        self.assertEqual(data['profit'],D('436000'))
        self.assertEqual(data['other_fees'],D('4000'))
        self.assertEqual(data['inventory_adjustment'],0)
        self.assertEqual(len(data['channels']),4)
        self.assertContains(self.client.get(reverse('dashboard')),'100 pesanan')
        self.assertContains(self.client.get(reverse('sale_detail',args=[Sale.objects.first().pk])),'Rekap POS harian')

    def test_legacy_sale_blocks_duplicate_daily_recap(self):
        self.sale()
        self.assertEqual(self.client.post(reverse('sale_create'),self.recap_data()).status_code,200)
        self.assertEqual(Sale.objects.count(),1)

    def test_post_product_with_recipe(self):
        data={'name':'Seblak Rindu','price':'15000','manual_cost':'0','active':'on','recipes-TOTAL_FORMS':1,'recipes-INITIAL_FORMS':0,'recipes-MIN_NUM_FORMS':0,'recipes-MAX_NUM_FORMS':100,'recipes-0-ingredient':self.i.pk,'recipes-0-quantity':'50'}
        self.assertEqual(self.client.post(reverse('product_create'),data).status_code,302)
        self.assertEqual(Product.objects.get(name='Seblak Rindu').recipes.count(),1)

    def test_blank_sale_form_cannot_post(self):
        data={'token':uuid.uuid4(),'date':self.today.isoformat(),'channel':self.channel.pk,'payment_method':'cash','items-TOTAL_FORMS':0,'items-INITIAL_FORMS':0,'items-MIN_NUM_FORMS':0,'items-MAX_NUM_FORMS':100}
        self.assertEqual(self.client.post(reverse('sale_create'),data).status_code,200)
        self.assertFalse(Sale.objects.exists())

    def test_expense_duplicate_request_and_cancel(self):
        data=dict(token=uuid.uuid4(),date=self.today.isoformat(),category='rent',description='Sewa',amount='900000')
        for _ in range(2):self.assertEqual(self.client.post(reverse('expense_create'),data).status_code,302)
        self.assertEqual(Expense.objects.count(),1)
        expense=Expense.objects.get()
        self.assertEqual(self.client.post(reverse('expense_cancel',args=[expense.pk]),{'reason':'Salah catat'}).status_code,302)
        expense.refresh_from_db();self.assertTrue(expense.voided)

    def test_csv_handles_bad_period(self):
        response=self.client.get(reverse('reports')+'?month=bad&export=csv')
        self.assertEqual(response.status_code,200)

    def test_prices_and_costs_stay_historical(self):
        self.recipe();s=self.sale()
        self.purchase(D('1000'),D('50000'))
        self.p.name='Nama baru';self.p.price=99000;self.p.save()
        s.refresh_from_db();item=s.items.get()
        self.assertEqual(s.cost,D('2000'))
        self.assertEqual(item.product_name,'Seblak Sayank')
        self.assertEqual(item.unit_price,D('12000'))

    def test_purchase_and_count_web_forms(self):
        data=dict(token=uuid.uuid4(),date=self.today.isoformat(),ingredient=self.i.pk,quantity='100',total_cost='1000',notes='Belanja')
        for _ in range(2):self.assertEqual(self.client.post(reverse('purchase_create'),data).status_code,302)
        self.i.refresh_from_db();self.assertEqual(self.i.stock,D('1100'))
        data=dict(token=uuid.uuid4(),date=self.today.isoformat(),ingredient=self.i.pk,counted='1000',notes='Selisih opname')
        for _ in range(2):self.assertEqual(self.client.post(reverse('stock_count'),data).status_code,302)
        self.i.refresh_from_db();self.assertEqual(self.i.stock,D('1000'))

    def test_empty_void_reason_cannot_change_sale(self):
        s=self.sale()
        with self.assertRaises(ValidationError):void_sale(s,user=self.user,reason=' ')
        s.refresh_from_db();self.assertEqual(s.status,'posted')

    def test_cancel_get_is_read_only(self):
        self.recipe();s=self.sale()
        self.client.get(reverse('sale_cancel',args=[s.pk]))
        s.refresh_from_db();self.i.refresh_from_db()
        self.assertEqual(s.status,'posted');self.assertEqual(self.i.stock,D('900'))

    def test_mutations_require_csrf(self):
        from django.test import Client
        client=Client(enforce_csrf_checks=True);client.force_login(self.user)
        for name in ['expense_create','sale_create','purchase_create','stock_count','business_settings']:
            self.assertEqual(client.post(reverse(name),{}).status_code,403,name)

    def test_inactive_product_and_duplicate_recipe(self):
        self.p.active=False;self.p.save()
        with self.assertRaises(ValidationError):self.sale()
        self.assertFalse(Sale.objects.exists())
        data={'name':self.p.name,'price':'12000','manual_cost':'5000','active':'on','recipes-TOTAL_FORMS':2,'recipes-INITIAL_FORMS':0,'recipes-MIN_NUM_FORMS':0,'recipes-MAX_NUM_FORMS':100,'recipes-0-ingredient':self.i.pk,'recipes-0-quantity':'50','recipes-1-ingredient':self.i.pk,'recipes-1-quantity':'50'}
        response=self.client.post(reverse('product_edit',args=[self.p.pk]),data)
        self.assertEqual(response.status_code,200)
        self.assertFalse(self.p.recipes.exists())

    def test_future_sale_date_not_accepted(self):
        form=SaleForm(dict(token=uuid.uuid4(),date='2099-01-01',channel=self.channel.pk,payment_method='cash'))
        self.assertFalse(form.is_valid());self.assertIn('date',form.errors)

    def test_multiple_items_success(self):
        self.recipe()
        p2=Product.objects.create(name='Ceker',price=17000)
        Recipe.objects.create(product=p2,ingredient=self.i,quantity=75)
        s=post_sale(header=dict(token=uuid.uuid4(),date=self.today,channel=self.channel,payment_method='cash'),rows=[dict(product=self.p,quantity=2,unit_price=D('12000')),dict(product=p2,quantity=1,unit_price=D('17000'))],user=self.user)
        self.assertEqual(s.subtotal,D('41000'));self.assertEqual(s.cost,D('3500'))
        self.i.refresh_from_db();self.assertEqual(self.i.stock,D('825'))
