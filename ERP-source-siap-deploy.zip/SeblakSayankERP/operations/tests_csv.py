import csv
import io
from decimal import Decimal
from django.test import TestCase
from django.contrib.auth import get_user_model
from django.core.files.uploadedfile import SimpleUploadedFile
from django.core.exceptions import ValidationError
from django.urls import reverse
from django.utils import timezone
from .csv_import import parse_csv, commit_import
from .models import Sale, CSVImport, Ingredient

HEADER='tanggal,kanal,id_pesanan,omzet,voucher,komisi,biaya_lain,pendapatan_bersih,status\n'

class CSVTests(TestCase):
    def setUp(self):
        self.user=get_user_model().objects.create_user('importer',password='testing')
        self.client.force_login(self.user)
        self.day=timezone.localdate().isoformat()
        self.raw=(HEADER+f'{self.day},GrabFood,A1,100000,10000,20000,1000,69000,selesai\n').encode()

    def draft(self, raw=None):
        d=parse_csv(raw or self.raw);d['filename']='report.csv';return d

    def test_standard_and_duplicate_order(self):
        d=self.draft();self.assertEqual(d['rows'][0]['net_revenue'],'69000')
        with self.assertRaises(ValidationError):self.draft(self.raw+self.raw.splitlines(keepends=True)[1])

    def test_invalid_files_and_reconciliation(self):
        for raw in [b'',b'hello',self.raw.replace(b'69000',b'68000'),self.raw.replace(b'100000',b'NaN'),self.raw.replace(b'100000',b'-10'),self.raw.replace(b'selesai',b'pending'),self.raw.replace(self.day.encode(),b'2099-01-01'),b'\xff']:
            with self.assertRaises(ValidationError):parse_csv(raw)

    def test_atomic_duplicate_date_and_file(self):
        d=self.draft();commit_import(d,[Decimal('40000')],self.user)
        s=Sale.objects.get();self.assertEqual(s.net_revenue,Decimal('69000'));self.assertEqual(s.cost,40000)
        with self.assertRaises(ValidationError):commit_import(d,[Decimal(0)],self.user)
        changed=self.draft(self.raw.replace(b'A1',b'A2'))
        with self.assertRaises(ValidationError):commit_import(changed,[Decimal(0)],self.user)
        self.assertEqual(CSVImport.objects.count(),1);self.assertEqual(Sale.objects.count(),1)
        self.assertFalse(s.movements.exists())

    def test_batch_rollback_on_later_conflict(self):
        commit_import(self.draft(),[Decimal(1)],self.user)
        from datetime import timedelta
        earlier=(timezone.localdate()-timedelta(days=1)).isoformat()
        raw=self.raw+(f'{earlier},GoFood,B1,100000,10000,20000,1000,69000,selesai\n').encode()
        with self.assertRaises(ValidationError):commit_import(self.draft(raw),[Decimal(1),Decimal(1)],self.user)
        self.assertEqual(Sale.objects.count(),1);self.assertEqual(CSVImport.objects.count(),1)

    def test_preview_commit_required_hpp_and_repeat(self):
        url=reverse('sale_import')
        self.assertEqual(self.client.get(url).status_code,200)
        response=self.client.post(url,{'action':'preview','file':SimpleUploadedFile('sample.csv',self.raw)})
        self.assertContains(response,'Rp69.000')
        draft_id=self.client.session['csv_import_draft']['draft_id']
        self.assertFalse(Sale.objects.exists())
        self.assertEqual(self.client.post(url,{'action':'commit','draft_id':draft_id,'complete':'on'}).status_code,200)
        self.assertFalse(Sale.objects.exists())
        self.assertEqual(self.client.post(url,{'action':'commit','draft_id':draft_id,'complete':'on','cost_0':'40000'}).status_code,302)
        self.assertEqual(self.client.post(url,{'action':'commit','draft_id':draft_id,'complete':'on','cost_0':'40000'}).status_code,200)
        self.assertEqual(Sale.objects.count(),1)
        self.assertContains(self.client.get(reverse('sale_list')),'Impor CSV')
        self.client.logout();self.assertEqual(self.client.get(url).status_code,302)

    def test_gofood_total_cost_not_double_discount_and_date(self):
        text='Tipe Pembayaran,Waktu Transaksi,Nomor Pesanan,Gopay Source,Jumlah Refund,Penjualan,Total Biaya,Promo yang ditanggung Mitra Usaha,Merchant Contribution,Pendapatan Bersih,Refund\ngopay,"Oct 28 2026, 14:33",F-test,goresto_online,0.0,35500.0,8100.0,1000,1000,27400.0,false\n'
        d=self.draft(text.encode());r=d['rows'][0]
        self.assertEqual(r['date'],'2026-10-28');self.assertEqual(Decimal(r['other_fees']),8100)
        with self.assertRaises(ValidationError):self.draft(text.replace('false','true').encode())

    def test_shopee_mapping_canceled_and_mixed_store(self):
        headers=['Order ID','Order Create Time','Order Amount','Net Income','Commission','Order Status','Store ID','Transaction Type','PB1','Merchant Service Charge','Merchant Surcharge Fee','Merchant Shipping Fee Voucher Subsidy','Platform Flash Sale Subsidy','Food Direct Discount','Merchant Food Voucher Subsidy','Merchant Voucher Deals Subsidy']
        row=['id-1','27/10/2026 13:16:07','29000','14475','4825','Settled','store-1','Delivery order','0','0','0','0','0','0','0','9700']
        def raw(rows):
            stream=io.StringIO();w=csv.writer(stream);w.writerow(headers);w.writerows(rows);return stream.getvalue().encode('utf-8-sig')
        r=self.draft(raw([row]))['rows'][0]
        self.assertEqual(r['voucher_amount'],'9700');self.assertEqual(r['net_revenue'],'14475')
        other=row.copy();other[0]='id-2';other[6]='store-2'
        with self.assertRaises(ValidationError):self.draft(raw([row,other]))
        other[5]='Cancelled'
        self.assertEqual(self.draft(raw([row,other]))['skipped'],1)

    def test_template_download(self):
        response=self.client.get(reverse('sale_import')+'?template=1')
        self.assertEqual(response.status_code,200);self.assertIn('id_pesanan',response.content.decode())

    def gofood_transaction_csv(self):
        headers = ['Serial No', 'Waktu Transaksi', 'Nomor Pesanan', 'Tipe Pesanan', 'Mata Uang', 'Penjualan', 'Biaya Program', 'Nama Program', 'Biaya GoFood', 'Biaya Program Promo', 'Pengurangan biaya layanan GoFood', 'Promo yang ditanggung Mitra Usaha', 'Biaya pemberian voucher', 'Total Biaya', 'Pendapatan Bersih']
        row = ['1', '2026-10-28T14:33:12.000+07:00', 'F-1', 'GoFood Pesan Antar', 'IDR', '35500', '0', '', '8100', '0', '0', '', '', '8100', '27400']
        stream = io.StringIO()
        writer = csv.writer(stream)
        writer.writerow(headers)
        writer.writerow(row)
        return stream.getvalue().encode('utf-8-sig')

    def test_gofood_transaction_export_and_commit(self):
        raw = self.gofood_transaction_csv()
        draft = self.draft(raw)
        row = draft['rows'][0]
        self.assertEqual(row['date'], '2026-10-28')
        self.assertEqual(row['order_count'], 1)
        self.assertEqual(row['net_revenue'], '27400')
        self.assertEqual(row['other_fees'], '8100')
        commit_import(draft, [Decimal(0)], self.user)
        self.assertEqual(Sale.objects.get().net_revenue, Decimal('27400'))
        with self.assertRaises(ValidationError):
            commit_import(draft, [Decimal(0)], self.user)

    def test_gofood_transaction_checks(self):
        raw = self.gofood_transaction_csv()
        for old, new in [(b'IDR', b'USD'), (b'GoFood Pesan Antar', b'Refund'), (b'27400', b'27000'), (b'35500,0,,8100', b'35500,0,,8000'), (b'.000+07:00', b'.000'), (b'2026-10-28T', b'2099-10-28T')]:
            with self.subTest(old=old), self.assertRaises(ValidationError):
                parse_csv(raw.replace(old, new))
        # Reductions are already part of Total Biaya, never deducted twice.
        reduced = raw.replace(b'8100,0,0,,,8100,27400', b'8100,0,100,,,8000,27500')
        self.assertEqual(parse_csv(reduced)['rows'][0]['net_revenue'], '27500')
