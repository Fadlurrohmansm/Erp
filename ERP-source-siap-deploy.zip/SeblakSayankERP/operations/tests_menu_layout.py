from django.test import TestCase
from django.contrib.auth import get_user_model
from django.urls import reverse
from tenancy.models import Branch
from .models import Product,MenuCategory,MenuLayoutPreference

class MenuLayoutTests(TestCase):
    def setUp(self):
        self.user=get_user_model().objects.create_user('layout-menu',password='testing');self.client.force_login(self.user)
        self.a=MenuCategory.objects.create(name='Paket')
        self.b=MenuCategory.objects.create(name='Topping')
        self.c=MenuCategory.objects.create(name='Minuman')
        for cat in [self.a,self.b,self.c,None]:Product.objects.create(name='Menu '+str(cat),price=1,category=cat)
    def test_default_all_and_persistent_multiple_categories(self):
        self.assertEqual(self.client.get(reverse('product_list')).context['products'].paginator.count,4)
        self.client.post(reverse('menu_layout_save'),{'visible_categories':[self.a.pk,self.b.pk]})
        response=self.client.get(reverse('product_list'))
        self.assertEqual(response.context['products'].paginator.count,2)
        self.assertEqual({g['name'] for g in response.context['groups']},{'Paket','Topping'})
        self.assertEqual(MenuLayoutPreference.objects.get(user=self.user).category_ids,[self.a.pk,self.b.pk])
        self.client.logout();self.client.force_login(self.user)
        self.assertEqual(self.client.get(reverse('product_list')).context['products'].paginator.count,2)
    def test_all_includes_new_categories_and_uncategorized_option(self):
        self.client.post(reverse('menu_layout_save'),{'show_uncategorized':'on'})
        self.assertEqual(self.client.get(reverse('product_list')).context['products'].paginator.count,1)
        self.client.post(reverse('menu_layout_save'),{'show_all':'on'})
        new=MenuCategory.objects.create(name='Baru');Product.objects.create(name='Menu baru',price=1,category=new)
        self.assertEqual(self.client.get(reverse('product_list')).context['products'].paginator.count,5)
    def test_scope_by_user_branch_and_explicit_filter_override(self):
        self.client.post(reverse('menu_layout_save'),{'visible_categories':[self.a.pk]})
        self.assertEqual(self.client.get(reverse('product_list'),{'category':self.c.pk}).context['products'].paginator.count,1)
        self.assertEqual(self.client.get(reverse('product_list'),{'category':'all'}).context['products'].paginator.count,4)
        self.assertEqual(self.client.get(reverse('product_list')).context['products'].paginator.count,1)
        self.client.force_login(get_user_model().objects.create_user('other-layout',password='testing'))
        self.assertEqual(self.client.get(reverse('product_list')).context['products'].paginator.count,4)
        branch=Branch.objects.create(name='Lain');foreign=MenuCategory.objects.create(branch=branch,name='Asing')
        self.client.post(reverse('menu_layout_save'),{'visible_categories':[foreign.pk]})
        self.assertEqual(MenuLayoutPreference.objects.count(),1)
    def test_empty_rejected_and_post_auth_required(self):
        self.client.post(reverse('menu_layout_save'),{})
        self.assertFalse(MenuLayoutPreference.objects.exists())
        self.assertEqual(self.client.get(reverse('menu_layout_save')).status_code,405)
        self.client.logout();self.assertEqual(self.client.post(reverse('menu_layout_save'),{'show_all':'on'}).status_code,302)

    def test_show_all_does_not_truncate_later_category(self):
        for index in range(27):
            Product.objects.create(name=f'Topping {index:02}',price=1,category=self.b)
        for index in range(8):
            Product.objects.create(name=f'Paket {index:02}',price=1,category=self.a)
        for params in [{}, {'category':'all'}, {'category':'all','page':'99'}]:
            response=self.client.get(reverse('product_list'),params)
            self.assertEqual(len(response.context['products']),39)
            self.assertEqual(response.context['products'].paginator.num_pages,1)
            for group in response.context['groups']:
                self.assertEqual(len(group['products']),group['total'])
        self.client.post(reverse('menu_layout_save'),{'visible_categories':[self.c.pk]})
        self.assertEqual(len(self.client.get(reverse('product_list')).context['products']),1)
        self.assertEqual(len(self.client.get(reverse('product_list'),{'category':'all'}).context['products']),39)
        filtered=self.client.get(reverse('product_list'),{'category':'all','q':'Paket 0'})
        self.assertEqual(len(filtered.context['products']),8)
