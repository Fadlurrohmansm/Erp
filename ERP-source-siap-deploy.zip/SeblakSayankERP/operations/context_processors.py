from .models import BusinessSettings

def business_context(request):
    return {'business': BusinessSettings.objects.filter(pk=1).first(), 'section': request.resolver_match.url_name if request.resolver_match else ''}
