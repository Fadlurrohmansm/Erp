from django.db import migrations


def seed(apps, schema_editor):
    Channel=apps.get_model('operations','Channel')
    Business=apps.get_model('operations','BusinessSettings')
    for name in ['Offline','GoFood','ShopeeFood','GrabFood']:
        Channel.objects.get_or_create(name=name,defaults={'voucher_rate':0,'commission_rate':0})
    Business.objects.get_or_create(pk=1,defaults={'name':'Seblak Sayank','tagline':'Pedasnya penuh cinta.'})

class Migration(migrations.Migration):
    dependencies=[('operations','0001_initial')]
    operations=[migrations.RunPython(seed,migrations.RunPython.noop)]
