from django.core.management.base import BaseCommand
from django.core.management import call_command
from django.contrib.auth import get_user_model

class Command(BaseCommand):
    help='Minta pembuatan administrator jika belum ada akun aktif.'
    def handle(self,*args,**options):
        if not get_user_model().objects.filter(is_active=True,is_superuser=True).exists():
            self.stdout.write('Belum ada administrator. Buat akun untuk usaha ini; password tidak ditampilkan saat diketik.')
            call_command('createsuperuser',interactive=True)
