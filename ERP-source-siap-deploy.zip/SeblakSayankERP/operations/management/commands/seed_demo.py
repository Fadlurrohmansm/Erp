"""Data fiktif untuk database demo yang kosong."""
from datetime import timedelta
from decimal import Decimal
from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.utils import timezone
from core.models import Employee, Attendance, Payroll
from operations.models import Ingredient, Product, Recipe, Channel, Sale, Expense
from operations.services import receive_stock, post_sale
import uuid

class Command(BaseCommand):
    help = 'Menambah data fiktif; menolak database operasional yang sudah berisi data.'
    @transaction.atomic
    def handle(self,*args,**options):
        if Ingredient.objects.exists() or Product.objects.exists() or Sale.objects.exists() or Expense.objects.exists() or Employee.objects.exists():
            raise CommandError('Data sudah ada. Gunakan database demo terpisah yang kosong.')
        user=get_user_model().objects.filter(is_superuser=True).first()
        if not user:raise CommandError('Buat akun dengan createsuperuser terlebih dahulu.')
        today=timezone.localdate()
        first=today.replace(day=1)
        specs=[('Kerupuk','g',Decimal('20000'),Decimal('440000'),Decimal('3000')),('Bumbu racik','g',Decimal('25000'),Decimal('750000'),Decimal('3000')),('Telur','pcs',Decimal('500'),Decimal('850000'),Decimal('50')),('Sawi','g',Decimal('20000'),Decimal('100000'),Decimal('2000')),('Kemasan','pcs',Decimal('500'),Decimal('150000'),Decimal('30'))]
        ingredients=[]
        for name,unit,quantity,cost,minimum in specs:
            i=Ingredient.objects.create(name=name,unit=unit,minimum_stock=minimum)
            receive_stock(ingredient=i,quantity=quantity,total_cost=cost,date=first,user=user,notes='DATA DEMO — stok awal')
            ingredients.append(i)
        products=[]
        for name,price in [('Seblak Sayank',12000),('Seblak Baper',15000),('Seblak Rindu',14000),('Sayank Ceker',17000)]:
            p=Product.objects.create(name=name,price=price)
            for i,qty in zip(ingredients,[40,50,1,30,1]):Recipe.objects.create(product=p,ingredient=i,quantity=qty)
            products.append(p)
        channels=list(Channel.objects.all())
        for c in channels:
            if c.name=='ShopeeFood':c.voucher_rate=22;c.commission_rate=25;c.save()
            elif c.name!='Offline':c.voucher_rate=10;c.commission_rate=20;c.save()
        # Deterministic fictional examples, not claims about real merchant rates.
        for n in range(min(today.day,14)):
            day=first+timedelta(days=n)
            for j in range(3):
                p=products[(n+j)%len(products)]
                post_sale(header=dict(token=uuid.uuid4(),date=day,channel=channels[(n+j)%len(channels)],payment_method='qris' if j==0 else 'platform',notes='DATA DEMO'),rows=[dict(product=p,quantity=2+(n+j)%7,unit_price=p.price if j==0 else p.price+4000)],user=user)
        Expense.objects.create(date=first,category='rent',description='DATA DEMO — Sewa tempat',amount=900000,created_by=user)
        Expense.objects.create(date=first,category='utilities',description='DATA DEMO — Listrik & gas',amount=150000,created_by=user)
        employee=Employee.objects.create(employee_code='DEMO01',full_name='Karyawan Demo',position='Crew outlet',hire_date=first,base_salary=1200000,fuel_allowance=100000)
        for day in range(1,today.day+1):
            Attendance.objects.create(employee=employee,date=today.replace(day=day),status='off' if day in [7,21] else 'present',punctual=day%6!=0 and day not in [7,21],check_in=None)
        self.stdout.write(self.style.SUCCESS('Data fiktif berhasil dibuat. Semua transaksi contoh diberi catatan DATA DEMO.'))
