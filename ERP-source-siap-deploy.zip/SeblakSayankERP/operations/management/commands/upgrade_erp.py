"""Cadangkan database SQLite sebelum menerapkan migrasi ERP."""
from datetime import datetime
from pathlib import Path
import sqlite3
from django.conf import settings
from django.core.management import call_command
from django.core.management.base import BaseCommand, CommandError

class Command(BaseCommand):
    help='Membuat backup SQLite sebelum menjalankan migrasi.'
    def handle(self,*args,**options):
        cfg=settings.DATABASES['default']
        if cfg['ENGINE']!='django.db.backends.sqlite3':
            raise CommandError('Perintah ini khusus SQLite. Gunakan backup database sesuai server sebelum migrate.')
        database=Path(cfg['NAME'])
        if database.exists():
            backup_dir=database.parent/'backups';backup_dir.mkdir(exist_ok=True)
            backup=backup_dir/f'db_before_upgrade_{datetime.now():%Y%m%d_%H%M%S_%f}.sqlite3'
            with sqlite3.connect(str(database)) as source,sqlite3.connect(str(backup)) as target:
                source.backup(target)
            self.stdout.write(f'Backup tersimpan: {backup}')
        call_command('migrate',interactive=False)
        call_command('check')
        self.stdout.write(self.style.SUCCESS('Pembaruan database selesai.'))
