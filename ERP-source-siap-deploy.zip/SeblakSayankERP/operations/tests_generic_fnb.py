from datetime import date
from decimal import Decimal
from unittest.mock import patch
import uuid
from django.test import TestCase
from django.urls import reverse
from django.contrib.auth import get_user_model
from .models import BusinessSettings,Product,Channel,POSCostImport,Ingredient,Recipe
from .pos_import import parse_pos_xlsx,snapshot_lines
from .pos_quantities import pos_quantities
from .services import post_sale,void_sale,post_daily_recap
from .forms import ProductForm,BusinessForm
from .tests_pos import fixture,HEAD,ROWS

class GenericFNBTests(TestCase):
    def setUp(self):
        self.user=get_user_model().objects.create_user('cafeowner',password='testing');self.client.force_login(self.user)
        self.config=BusinessSettings.objects.get(pk=1)
        self.config.name='Kedai Kopi Pagi';self.config.pos_count_mode='product';self.config.pos_noncash_method='noncash';self.config.save()
    def test_cafe_types_and_immutable_snapshot(self):
        coffee=Product.objects.create(name='Kopi Susu',price=18000,sales_kind='main')
        shot=Product.objects.create(name='Extra Shot',price=4000,sales_kind='addon')
        bottle=Product.objects.create(name='Botol',price=3000,sales_kind='other')
        draft={'channel':'Offline','items':[{'name':'Latte POS','quantity':'2'},{'name':'Shot POS','quantity':'3'},{'name':'Botol POS','quantity':'1'}]}
        lines=snapshot_lines(draft,{'product_0':coffee,'product_1':shot,'product_2':bottle})
        self.assertEqual(pos_quantities(lines),{'portions':2,'toppings':3,'others':1})
        coffee.sales_kind='addon';coffee.save();self.config.pos_count_mode='keyword';self.config.pos_main_keywords='ayam';self.config.save()
        self.assertEqual(pos_quantities(lines)['portions'],2)
        self.assertEqual(pos_quantities([{'source_name':'Seblak Cinta','quantity':'2'},{'source_name':'Bakso','quantity':'1'}]),{'portions':2,'toppings':1})
    def test_custom_keywords_use_source_names(self):
        self.config.pos_count_mode='keyword';self.config.pos_main_keywords='kopi, teh';self.config.save()
        product=Product.objects.create(name='Nama ERP berbeda',price=1,sales_kind='other')
        lines=snapshot_lines({'items':[{'name':'Es TEH','quantity':'2'}]}, {'product_0':product})
        self.assertEqual(pos_quantities(lines)['portions'],2)
    def test_noncash_not_assumed_qris_and_explicit_methods(self):
        with patch('operations.tests_pos.HEAD',HEAD+['Metode Pembayaran']):
            for method,key in [('Non Tunai','noncash'),('QRIS','qris'),('Transfer','transfer')]:
                rows=[r.copy()+([method] if i==0 else [None]) for i,r in enumerate(ROWS)]
                draft=parse_pos_xlsx(fixture(rows));self.assertEqual(draft['payments'][key]['amount'],'10000')
                self.assertTrue(draft['classification_pending'])
            self.config.pos_noncash_method='transfer';self.config.save()
            rows=[r.copy()+(['Non Tunai'] if i==0 else [None]) for i,r in enumerate(ROWS)]
            self.assertEqual(parse_pos_xlsx(fixture(rows))['payments']['transfer']['amount'],'10000')
    def test_branding_rendered_on_login_and_workspace(self):
        for url in [reverse('dashboard'),reverse('product_list'),reverse('reports'),reverse('business_settings'),reverse('login')]:
            response=self.client.get(url);self.assertEqual(response.status_code,200);self.assertContains(response,'Kedai Kopi Pagi');self.assertNotContains(response,'Seblak Sayank')
    def test_keyword_configuration_requires_keywords(self):
        form=BusinessForm({'name':'Cafe','tagline':'Pagi','pos_count_mode':'keyword','pos_noncash_method':'noncash','pos_main_keywords':', ,'})
        self.assertFalse(form.is_valid());self.assertIn('pos_main_keywords',form.errors)
    def test_channel_cost_used_by_item_sale_and_stock_reversal_once(self):
        product=Product.objects.create(name='Ayam Geprek',price=15000,manual_cost=4000,hpp_grabfood=5500)
        ingredient=Ingredient.objects.create(name='Ayam',stock=100,average_cost=10)
        Recipe.objects.create(product=product,ingredient=ingredient,quantity=2)
        sale=post_sale(header={'token':uuid.uuid4(),'date':date(2026,10,28),'channel':Channel.objects.get(name='GrabFood'),'payment_method':'platform'},rows=[{'product':product,'quantity':2,'unit_price':Decimal(15000)}],user=self.user)
        self.assertEqual(sale.cost,11000);ingredient.refresh_from_db();self.assertEqual(ingredient.stock,96)
        void_sale(sale,user=self.user,reason='Tes pembatalan');void_sale(sale,user=self.user,reason='Ulang')
        ingredient.refresh_from_db();self.assertEqual(ingredient.stock,100)

    def test_admin_foreign_keys_keep_active_branch(self):
        from tenancy.models import Branch
        from core.models import JobRole
        from .models import MenuCategory
        other=Branch.objects.create(name='Other business branch')
        foreign=JobRole.objects.create(branch=other,name='Foreign role')
        category=MenuCategory.objects.create(branch=other,name='Foreign category')
        self.user.is_staff=True;self.user.is_superuser=True;self.user.save()
        employee_form=self.client.get('/admin/core/employee/add/').context['adminform'].form
        self.assertFalse(employee_form.fields['role'].queryset.filter(pk=foreign.pk).exists())
        product_form=self.client.get('/admin/operations/product/add/').context['adminform'].form
        self.assertFalse(product_form.fields['category'].queryset.filter(pk=category.pk).exists())
