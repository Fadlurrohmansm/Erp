import json
from django.test import TestCase
from django.contrib.auth import get_user_model
from django.urls import reverse
from tenancy.models import Branch
from .models import Product,MenuCategory

class CategoryWorkflowTests(TestCase):
    def setUp(self):
        self.client.force_login(get_user_model().objects.create_user('categories',password='testing'))
        self.a=MenuCategory.objects.create(name='Paket seblak')
        self.b=MenuCategory.objects.create(name='Add on topping')
        self.products=[Product.objects.create(name=f'Seblak {i:02}',price=12000,category=self.a) for i in range(25)]
        Product.objects.create(name='Bakso',price=2000,category=self.b)
    def test_filtered_category_heading_and_pagination_preserved(self):
        response=self.client.get(reverse('product_list'),{'category':self.a.pk})
        self.assertContains(response,'Paket seblak');self.assertNotContains(response,'data-product-name="Bakso"')
        self.assertContains(response,f'category={self.a.pk}');self.assertEqual(response.context['products'].paginator.count,25)
        self.assertEqual(len(response.context['groups']),1)
        self.assertEqual(response.context['selected_category'],self.a)
    def test_cross_page_ids_applied_and_selected_category_shown(self):
        ids=[str(self.products[0].pk),str(self.products[-1].pk)]
        response=self.client.post(reverse('product_list'),{'selected':[ids[1]],'selected_all':json.dumps(ids),'category_name':'Paket Favorit'})
        c=MenuCategory.objects.get(name='Paket Favorit')
        self.assertRedirects(response,reverse('product_list')+f'?category={c.pk}',fetch_redirect_response=False)
        self.assertEqual(Product.objects.filter(category=c).count(),2)
        response=self.client.get(response.url)
        self.assertTrue(response.context['clear_menu_selection'])
        self.assertEqual(response.context['selected_category'],c)
        self.assertEqual(response.context['products'].paginator.count,2)
    def test_groups_for_two_column_tables_and_storage_scope(self):
        response=self.client.get(reverse('product_list'))
        self.assertContains(response,'menu-category-grid');self.assertEqual(len(response.context['groups']),2)
        self.assertContains(response,'data-selection-key="erp-menu-selection:')
    def test_bad_selection_rejected_and_foreign_ids_cannot_move(self):
        branch=Branch.objects.create(name='Cabang asing');foreign=Product.objects.create(branch=branch,name='Menu asing',price=1)
        self.client.post(reverse('product_list'),{'selected_all':json.dumps([str(foreign.pk),str(self.products[0].pk)]),'category':self.b.pk})
        foreign.refresh_from_db();self.assertIsNone(foreign.category)
        self.products[0].refresh_from_db();self.assertEqual(self.products[0].category,self.b)
        before=Product.objects.filter(category=self.b).count()
        self.client.post(reverse('product_list'),{'selected_all':'{"invalid":1}','category':self.b.pk})
        self.assertEqual(Product.objects.filter(category=self.b).count(),before)
