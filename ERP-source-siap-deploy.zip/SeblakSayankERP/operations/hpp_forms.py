import uuid
from decimal import Decimal

from django import forms
from django.utils import timezone

from tenancy.forms import ScopedForm, ScopedModelForm
from .forms import DateForm
from .models import Channel, HPPChannelRule, HPPPolicy, Ingredient, MenuCategory, Product


class PolicyForm(ScopedModelForm):
    class Meta:
        model = HPPPolicy
        exclude = ['branch']

    def clean(self):
        data = super().clean()
        if 'critical' in data and 'warning' in data and data['critical'] < data['warning']:
            self.add_error('critical', 'Ambang kritis minimal sama dengan ambang peringatan.')
        return data


class RuleForm(ScopedModelForm):
    class Meta:
        model = HPPChannelRule
        exclude = ['branch', 'product', 'channel']


class PurchaseHeader(DateForm):
    token = forms.UUIDField(widget=forms.HiddenInput, initial=uuid.uuid4)
    supplier = forms.CharField(label='Supplier', max_length=100, required=False)
    notes = forms.CharField(label='Catatan / nomor nota', max_length=255, required=False)


class PurchaseRow(ScopedForm):
    ingredient = forms.ModelChoiceField(label='Bahan', queryset=Ingredient.objects.filter(active=True))
    quantity = forms.DecimalField(label='Jumlah beli', min_value=Decimal('.001'), max_digits=12, decimal_places=3)
    unit = forms.CharField(label='Satuan beli', max_length=20, help_text='Contoh kg, g, liter, ml, pcs, atau pack sesuai master bahan.')
    unit_price = forms.DecimalField(label='Harga per satuan beli (Rp)', min_value=Decimal('.01'), max_digits=14, decimal_places=2)
    discount = forms.DecimalField(label='Diskon baris (Rp)', min_value=0, max_digits=14, decimal_places=2, required=False)
    freight = forms.DecimalField(label='Alokasi ongkir (Rp)', min_value=0, max_digits=14, decimal_places=2, required=False)


class ProductionHeader(DateForm):
    token = forms.UUIDField(widget=forms.HiddenInput, initial=uuid.uuid4)
    output = forms.ModelChoiceField(label='Bahan hasil produksi', queryset=Ingredient.objects.filter(active=True))
    quantity = forms.DecimalField(label='Hasil bersih dalam satuan dasar', min_value=Decimal('.001'), max_digits=12, decimal_places=3)
    direct_cost = forms.DecimalField(label='Biaya langsung batch (Rp)', min_value=0, max_digits=14, decimal_places=2, required=False)
    notes = forms.CharField(label='Catatan batch', max_length=255, required=False)


class ProductionRow(ScopedForm):
    ingredient = forms.ModelChoiceField(label='Bahan yang dipakai', queryset=Ingredient.objects.filter(active=True))
    quantity = forms.DecimalField(label='Jumlah aktual dalam satuan dasar', min_value=Decimal('.001'), max_digits=12, decimal_places=3)


class QuoteForm(DateForm):
    product = forms.ModelChoiceField(label='Menu', queryset=Product.objects.all())
    method = forms.ChoiceField(label='Metode', choices=HPPPolicy.METHODS)
    window = forms.TypedChoiceField(label='Periode harga tertimbang', choices=[(7, '7 hari'), (30, '30 hari'), (90, '90 hari')], coerce=int)
    channel = forms.ModelChoiceField(label='Kanal simulasi', queryset=Channel.objects.all(), required=False)
    price = forms.DecimalField(label='Simulasi harga baru (Rp)', min_value=0, max_digits=14, decimal_places=2, required=False)
    food = forms.DecimalField(label='Target food cost (%)', min_value=Decimal('.01'), max_value=100, max_digits=5, decimal_places=2)
    margin = forms.DecimalField(label='Target margin kotor (%)', min_value=0, max_value=Decimal('99.99'), max_digits=5, decimal_places=2)
    token = forms.UUIDField(widget=forms.HiddenInput, initial=uuid.uuid4)
    reason = forms.CharField(label='Alasan simpan / hitung ulang snapshot', max_length=255, required=False)


class AnalyticsFilter(ScopedForm):
    days = forms.TypedChoiceField(label='Periode', choices=[(7, '7 hari'), (30, '30 hari'), (90, '90 hari')], coerce=int, initial=30)
    product = forms.ModelChoiceField(label='Menu', queryset=Product.objects.all(), required=False)
    category = forms.ModelChoiceField(label='Kategori menu', queryset=MenuCategory.objects.all(), required=False)
    channel = forms.ModelChoiceField(label='Kanal', queryset=Channel.objects.all(), required=False)
    variance = forms.BooleanField(label='Tampilkan estimasi selisih pemakaian stok', required=False)
