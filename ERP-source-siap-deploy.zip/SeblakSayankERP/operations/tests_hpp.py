import uuid
from datetime import timedelta
from decimal import Decimal as D

from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from tenancy.models import Branch
from .hpp import (
    CostBook, cancel_purchase, produce, profitability, purchase, purchase_factor,
    recommend, record_recipe, save_snapshot,
)
from .models import (
    Channel, HPPChannelRule, HPPPolicy, HPPSnapshot, Ingredient, Product, Recipe,
)
from .services import post_sale


class SmartHPPTests(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user('hpp')
        self.branch = Branch.objects.first()
        self.today = timezone.localdate()
        self.chili = Ingredient.objects.create(name='Cabai', unit='g', purchase_unit='pack', purchase_factor=D(250))
        self.menu = Product.objects.create(name='Seblak uji', price=20000)
        self.recipe = Recipe.objects.create(product=self.menu, ingredient=self.chili, quantity=100)
        self.channel = Channel.objects.get(name='Offline')

    def buy(self, quantity, price, *, ingredient=None, day=None, unit='kg', token=None):
        return purchase(user=self.user, ingredient=ingredient or self.chili, quantity=D(quantity),
                        unit=unit, unit_price=D(price), discount=D(0), freight=D(0),
                        supplier='Pasar', date=day or self.today, notes='Nota uji', token=token or uuid.uuid4())

    def book(self, method='latest', window=30):
        return CostBook(self.branch.pk, self.today, method, window)

    def test_unit_conversion_and_receipt_retries(self):
        self.assertEqual(purchase_factor(self.chili, 'Kilogram'), 1000)
        self.assertEqual(purchase_factor(self.chili, 'pack'), 250)
        oil = Ingredient.objects.create(name='Minyak', unit='ml')
        self.assertEqual(purchase_factor(oil, 'liter'), 1000)
        with self.assertRaises(ValidationError):
            purchase_factor(oil, 'kg')
        token = uuid.uuid4()
        one = self.buy(2, 35000, token=token)
        self.assertEqual(self.buy(2, 35000, token=token).pk, one.pk)
        self.chili.refresh_from_db()
        self.assertEqual(self.chili.stock, 2000)
        self.assertEqual(self.chili.average_cost, 35)

    def test_three_methods_diverge_after_stock_used_and_backdated_receipt(self):
        self.buy(2, 35000, day=self.today - timedelta(days=8))
        post_sale(header=dict(token=uuid.uuid4(), date=self.today, channel=self.channel, payment_method='cash'),
                  rows=[dict(product=self.menu, quantity=10, unit_price=D(20000))], user=self.user)
        self.buy(3, 42000, day=self.today - timedelta(days=4))
        self.buy(5, 50000)
        self.assertEqual(self.book().unit_cost(self.chili.pk), 50)
        self.assertEqual(self.book('weighted').unit_cost(self.chili.pk), D('44.6'))
        self.assertEqual(self.book('weighted', 7).unit_cost(self.chili.pk), 47)
        self.assertEqual(self.book('moving').unit_cost(self.chili.pk), D('45.666667'))

    def test_cancellation_appends_reversal_and_removes_price(self):
        first = self.buy(1, 35000)
        second = self.buy(1, 50000)
        with self.assertRaises(ValidationError):
            cancel_purchase(first, user=self.user, reason='Nota salah')
        cancel_purchase(second, user=self.user, reason='Nota salah')
        cancel_purchase(second, user=self.user, reason='Pengiriman ulang')
        self.chili.refresh_from_db()
        self.assertEqual(self.chili.stock, 1000)
        self.assertEqual(self.chili.average_cost, 35)
        self.assertEqual(self.book().unit_cost(self.chili.pk), 35)

    def test_versions_waste_and_historical_snapshot(self):
        self.assertIsNone(self.book().quote(self.menu)['total'])
        self.buy(2, 40000)
        first = save_snapshot(self.menu, self.book(), self.user, uuid.uuid4(), 'Harga awal')
        self.recipe.waste = D(20)
        self.recipe.save()
        second = record_recipe(self.menu, self.user)
        self.buy(2, 50000)
        self.assertEqual(self.book().quote(self.menu)['total'], D(6250))
        self.assertEqual(self.book().quote(self.menu)['waste'], D(1250))
        first.refresh_from_db()
        self.assertEqual(D(first.data['quote']['total']), D(4000))
        self.assertNotEqual(first.version_id, second.pk)
        self.assertEqual(HPPSnapshot.objects.count(), 1)

    def test_batch_uses_actual_yield_and_rejects_cycles(self):
        self.buy(2, 40000)
        paste = Ingredient.objects.create(name='Bumbu', unit='g')
        entry = produce(output=paste, quantity=D(1800), inputs={self.chili.pk: D(2000)},
                        direct_cost=D(0), day=self.today, user=self.user, token=uuid.uuid4(), notes='Batch')
        self.assertEqual(entry.output.value, 80000)
        self.assertEqual(self.book().unit_cost(paste.pk), D(80000) / 1800)
        self.chili.refresh_from_db()
        self.assertEqual(self.chili.stock, 0)
        with self.assertRaises(ValidationError):
            produce(output=self.chili, quantity=D(500), inputs={paste.pk: D(600)}, direct_cost=D(0),
                    day=self.today, user=self.user, token=uuid.uuid4(), notes='Siklus')
        paste.refresh_from_db()
        self.assertEqual(paste.stock, 1800)

    def test_channel_fees_use_separate_bases_and_keep_platform_funding(self):
        rule = HPPChannelRule(channel=self.channel, price=D(17500), merchant_rate=D(10),
                              platform_discount=D(1000), commission_rate=D(25), service_fee=D(400),
                              portions_per_order=2)
        data = profitability(D(7000), rule)
        self.assertEqual(data['net'], 15750)
        self.assertEqual(data['commission'], D('3687.50'))
        self.assertEqual(data['contribution'], D('4862.50'))
        rule.commission_basis = 'menu'
        self.assertEqual(profitability(D(7000), rule)['commission'], 4375)
        offline = HPPChannelRule(channel=self.channel, price=D(20000))
        self.assertEqual(recommend(D(8000), offline, D(40), D(0), 500), 20000)

    def test_branch_and_access_controls(self):
        branch = Branch.objects.create(name='Cabang lain')
        foreign = Product.objects.create(branch=branch, name='Menu privat', price=5000)
        with self.assertRaises(ValidationError):
            self.book().quote(foreign)
        pages = ['hpp_dashboard', 'hpp_prices', 'hpp_purchases', 'hpp_production',
                 'hpp_calculator', 'hpp_history', 'hpp_settings']
        for name in pages:
            self.assertEqual(self.client.get(reverse(name)).status_code, 302)
        self.client.force_login(self.user)
        self.buy(1, 40000)
        for name in pages:
            self.assertEqual(self.client.get(reverse(name)).status_code, 200)
        response = self.client.post(reverse('hpp_calculator'), {
            'date': self.today, 'product': foreign.pk, 'method': 'latest', 'window': 30,
            'food': 40, 'margin': 0, 'token': uuid.uuid4(),
        })
        self.assertNotContains(response, 'Menu privat')
        self.assertTrue(response.context['form'].errors)

    def test_calculator_and_dynamic_sales_keep_posted_cost(self):
        self.buy(3, 40000)
        self.client.force_login(self.user)
        data = dict(date=self.today, product=self.menu.pk, method='latest', window=30, food=40,
                    margin=0, token=uuid.uuid4(), channel=self.channel.pk, price=25000, reason='Audit')
        response = self.client.post(reverse('hpp_calculator'), data)
        self.assertContains(response, 'Harga simulasi')
        self.assertEqual(response.context['quote']['total'], 4000)
        self.assertEqual(self.client.post(reverse('hpp_calculator'), {**data, 'action': 'save'}).status_code, 302)
        snapshot = HPPSnapshot.objects.get()
        self.assertEqual(self.client.get(reverse('hpp_snapshot_detail', args=[snapshot.pk])).status_code, 200)
        HPPPolicy.objects.create(method='latest', apply_to_sales=True)
        sale = post_sale(header=dict(token=uuid.uuid4(), date=self.today, channel=self.channel, payment_method='cash'),
                         rows=[dict(product=self.menu, quantity=2, unit_price=D(20000))], user=self.user)
        self.buy(1, 55000)
        self.assertEqual(self.book().quote(self.menu)['total'], 5500)
        sale.refresh_from_db()
        self.assertEqual(sale.cost, 8000)
        self.assertEqual(sale.items.get().unit_cost, 4000)
