"""Cost quotations and immutable records for the existing ERP inventory."""
from collections import defaultdict
from datetime import timedelta
from decimal import Decimal, ROUND_CEILING

from django.core.exceptions import ValidationError
from django.db import transaction
from django.db.models import Q
from django.utils import timezone

from .models import (
    Channel, HPPChannelRule, HPPPolicy, HPPProduction, HPPPurchase,
    HPPRecipeVersion, HPPSnapshot, Ingredient, Product, StockMovement, ZERO,
)
from .services import lock_stock, money, movement, receive_stock

THOUSAND = Decimal(1000)
HUNDRED = Decimal(100)
UNIT_FACTORS = {('kg', 'g'): THOUSAND, ('l', 'ml'): THOUSAND}
UNIT_ALIASES = {'gram': 'g', 'kilogram': 'kg', 'liter': 'l', 'mililiter': 'ml',
                'piece': 'pcs', 'pieces': 'pcs', 'buah': 'pcs'}


def purchase_factor(ingredient, unit):
    unit = unit.strip().casefold()
    canonical = UNIT_ALIASES.get(unit, unit)
    if canonical == ingredient.unit:
        return Decimal(1)
    factor = UNIT_FACTORS.get((canonical, ingredient.unit))
    if factor is not None:
        return factor
    if unit and unit == ingredient.purchase_unit.strip().casefold() and ingredient.purchase_factor:
        return ingredient.purchase_factor
    raise ValidationError(f'Konversi {unit} ke {ingredient.unit} untuk {ingredient.name} belum ditentukan.')


@transaction.atomic
def purchase(*, user, ingredient, quantity, unit, unit_price, discount, freight, supplier, date, notes, token):
    ingredient = lock_stock(ingredient.pk)
    existing = HPPPurchase.objects.filter(movement__token=token, branch_id=ingredient.branch_id).first()
    if existing:
        return existing
    if not ingredient.active:
        raise ValidationError('Pilih bahan yang aktif.')
    factor = purchase_factor(ingredient, unit)
    base_quantity = quantity * factor
    total = money(quantity * unit_price - discount + freight)
    if min(quantity, unit_price, factor, total) <= 0 or discount > quantity * unit_price or freight < 0:
        raise ValidationError('Jumlah dan harga harus positif. Diskon tidak boleh melebihi harga pembelian.')
    if base_quantity < Decimal('.001') or base_quantity != base_quantity.quantize(Decimal('.001')):
        raise ValidationError('Jumlah dalam satuan dasar harus positif dan maksimal tiga angka desimal.')
    entry = receive_stock(ingredient=ingredient, quantity=base_quantity, total_cost=total,
                          user=user, date=date, notes=notes, token=token)
    if (entry.ingredient_id != ingredient.pk or entry.kind != 'purchase'
            or entry.quantity != base_quantity or entry.value != total):
        raise ValidationError('Token transaksi sudah terpakai.')
    detail = HPPPurchase(branch_id=ingredient.branch_id, movement=entry, supplier=supplier,
                         quantity=quantity, unit=unit, factor=factor, unit_price=unit_price,
                         discount=discount, freight=freight)
    detail.full_clean()
    detail.save()
    return detail


@transaction.atomic
def cancel_purchase(detail, *, user, reason):
    ingredient = lock_stock(detail.movement.ingredient_id)
    detail = HPPPurchase.objects.select_for_update().select_related('movement').get(
        pk=detail.pk, branch_id=ingredient.branch_id,
    )
    if detail.cancelled_at:
        return
    if not reason.strip():
        raise ValidationError('Isi alasan pembatalan.')
    last = StockMovement.objects.filter(ingredient=ingredient).order_by('-pk').first()
    if last.pk != detail.movement_id:
        raise ValidationError('Pembelian ini sudah diikuti mutasi stok. Koreksi jumlah dengan stok opname dan catat selisih biaya secara terpisah.')
    original = detail.movement
    movement(ingredient, -original.quantity, -original.value, kind='purchase_rb',
             user=user, date=timezone.localdate(), notes=reason)
    detail.cancelled_at = timezone.now()
    detail.cancelled_by = user
    detail.reason = reason
    detail.save(update_fields=['cancelled_at', 'cancelled_by', 'reason'])


def policy_for(branch_id):
    return HPPPolicy.objects.filter(branch_id=branch_id).first() or HPPPolicy(branch_id=branch_id)


def recipe_definition(product):
    return {
        'yield': format(Decimal(product.batch_yield).normalize(), 'f'),
        'direct_cost': format(Decimal(product.recipe_direct_cost).normalize(), 'f'),
        'items': [
            {'ingredient': row.ingredient_id, 'substitute': row.substitute_id, 'quantity': str(row.quantity),
             'waste': str(row.waste), 'role': row.role}
            for row in sorted(product.recipes.all(), key=lambda row: row.ingredient_id)
        ],
    }


def record_recipe(product, user):
    data = recipe_definition(product)
    last = product.hpp_versions.order_by('-pk').first()
    if last and last.recipe == data:
        return last
    return HPPRecipeVersion.objects.create(branch_id=product.branch_id, product=product, recipe=data, created_by=user)


def recipe_for(product, day):
    versions = getattr(product, 'cost_versions', None)
    version = (next((row for row in versions if row.effective_date <= day), None) if versions is not None
               else product.hpp_versions.filter(effective_date__lte=day).order_by('-effective_date', '-pk').first())
    if day == timezone.localdate():
        return recipe_definition(product), version
    return (version.recipe, version) if version else (None, None)


def net_quantity(quantity, waste, portions):
    return quantity / (Decimal(1) - waste / HUNDRED) / portions


class CostBook:
    """Load cost evidence once for a branch, then reuse it across menus."""

    def __init__(self, branch_id, day, method, window):
        self.branch_id, self.day, self.method, self.window = branch_id, day, method, window
        self.ingredients = Ingredient.objects.filter(branch_id=branch_id).in_bulk()
        ledger = StockMovement.objects.filter(branch_id=branch_id, ingredient_id__in=self.ingredients)
        self.purchases = defaultdict(list)
        eligible = ledger.filter(kind='purchase', date__lte=day, quantity__gt=0, value__gt=0).filter(
            Q(purchase_detail__cancelled_at__isnull=True) | Q(purchase_detail__cancelled_at__date__gt=day)
        ).select_related('purchase_detail').order_by('-date', '-pk')
        for row in eligible:
            self.purchases[row.ingredient_id].append(row)
        self.production = defaultdict(list)
        for row in ledger.filter(kind='produce_in', date__lte=day, value__gt=0, quantity__gt=0).order_by('-date', '-pk'):
            self.production[row.ingredient_id].append(row)
        self.inventory = {}
        if method == 'moving' and day != timezone.localdate():
            for row in ledger.filter(created_at__date__lte=day).order_by('-pk').iterator():
                self.inventory.setdefault(row.ingredient_id, row)

    def unit_cost(self, pk):
        ingredient = self.ingredients.get(pk)
        if ingredient is None:
            return None
        if self.method == 'moving':
            last = self.inventory.get(pk)
            if self.day == timezone.localdate():
                return ingredient.average_cost if ingredient.stock > 0 and ingredient.average_cost > 0 else None
            if last and last.average_after is not None and last.average_after > 0:
                return last.average_after
            return None
        rows = self.purchases[pk] or self.production[pk]
        if not rows:
            return None
        if self.method == 'latest':
            return rows[0].value / rows[0].quantity
        start = self.day - timedelta(days=self.window - 1)
        period = [row for row in rows if row.date >= start]
        quantity = sum((row.quantity for row in period), ZERO)
        return sum((row.value for row in period), ZERO) / quantity if quantity else None

    def ingredient_stats(self, ingredient):
        rows = self.purchases[ingredient.pk]
        prices = [row.value / row.quantity for row in rows]
        qty = sum((row.quantity for row in rows), ZERO)
        change = (prices[0] / prices[1] - 1) * HUNDRED if len(prices) > 1 else None
        return dict(ingredient=ingredient, latest=prices[0] if prices else None,
                    date=rows[0].date if rows else None, change=change,
                    low=min(prices, default=None), high=max(prices, default=None),
                    weighted=sum((row.value for row in rows), ZERO) / qty if qty else None,
                    cost=self.unit_cost(ingredient.pk), purchases=rows)

    def quote(self, product, *, version=None):
        if product.branch_id != self.branch_id:
            raise ValidationError('Menu tidak tersedia di cabang aktif.')
        recipe, selected_version = recipe_for(product, self.day) if version is None else (version.recipe, version)
        result = dict(total=None, ingredients=ZERO, packaging=ZERO, addon=ZERO, waste=ZERO,
                      direct=ZERO, missing=[], lines=[], version=selected_version)
        if not recipe or not recipe['items']:
            result['missing'].append('Resep belum tersedia untuk tanggal ini.')
            return result
        yield_count = Decimal(recipe['yield'])
        result['direct'] = Decimal(recipe['direct_cost']) / yield_count
        for row in recipe['items']:
            pk = row['ingredient']
            cost = self.unit_cost(pk)
            if cost is None and row['substitute'] and self.unit_cost(row['substitute']) is not None:
                pk = row['substitute']
                cost = self.unit_cost(pk)
            ingredient = self.ingredients.get(pk)
            if cost is None:
                result['missing'].append(ingredient.name if ingredient else 'Bahan tidak ditemukan di cabang ini')
                continue
            usable = Decimal(row['quantity']) / yield_count
            gross = net_quantity(Decimal(row['quantity']), Decimal(row['waste']), yield_count)
            category = {'ingredient': 'ingredients', 'packaging': 'packaging', 'addon': 'addon'}[row['role']]
            result[category] += usable * cost
            result['waste'] += (gross - usable) * cost
            result['lines'].append(dict(ingredient_id=pk, name=ingredient.name, unit=ingredient.unit,
                                        quantity=gross, price=cost, cost=gross * cost,
                                        substituted=pk != row['ingredient']))
        if not result['missing']:
            result['total'] = money(sum((result[key] for key in ('ingredients', 'packaging', 'addon', 'waste', 'direct')), ZERO))
        return result


def channel_rules(product, *, channels=None, configured=None):
    if configured is None:
        configured = {(product.pk, rule.channel_id): rule for rule in HPPChannelRule.objects.filter(product=product)}
    if channels is None:
        channels = Channel.objects.filter(branch_id=product.branch_id)
    for channel in channels:
        yield configured.get((product.pk, channel.pk)) or HPPChannelRule(
            channel=channel, price=product.price, merchant_rate=channel.voucher_rate,
            commission_rate=channel.commission_rate,
        )


def profitability(hpp, rule, price=None):
    price = rule.price if price is None else price
    merchant = min(price, money(price * rule.merchant_rate / HUNDRED + rule.merchant_fixed))
    merchant_net = price - merchant
    platform = min(merchant_net, money(price * rule.platform_rate / HUNDRED + rule.platform_discount))
    customer_net = merchant_net - platform
    if rule.commission_basis == 'fixed':
        commission = rule.commission_fixed
    else:
        basis = price if rule.commission_basis == 'menu' else customer_net
        commission = money(basis * rule.commission_rate / HUNDRED)
    fee = money((rule.service_fee + rule.payment_fee) / rule.portions_per_order)
    cost = None if hpp is None else hpp + rule.packaging
    gross = None if cost is None else merchant_net - cost
    return dict(channel=rule.channel.name, channel_id=rule.channel_id, price=price, hpp=cost,
                merchant=merchant, platform=platform, net=merchant_net, commission=commission, fees=fee,
                total_fees=commission + fee,
                gross=gross, contribution=None if gross is None else gross - commission - fee,
                margin=None if gross is None or not merchant_net else gross / merchant_net * HUNDRED,
                food=None if cost is None or not merchant_net else cost / merchant_net * HUNDRED)


def recommend(hpp, rule, food, margin, rounding):
    if hpp is None:
        return None
    def meets(units):
        row = profitability(hpp, rule, Decimal(units * rounding))
        return (row['net'] > 0 and row['food'] <= food and row['margin'] >= margin
                and row['contribution'] >= 0)
    lo, hi = 0, 1
    maximum = 10**12 // rounding
    if not maximum:
        return None
    while hi < maximum and not meets(hi):
        hi = min(hi * 2, maximum)
    if not meets(hi):
        return None
    while lo + 1 < hi:
        mid = (lo + hi) // 2
        if meets(mid):
            hi = mid
        else:
            lo = mid
    return Decimal(hi * rounding)


def serializable(data):
    if isinstance(data, Decimal):
        return str(data)
    if isinstance(data, dict):
        return {key: serializable(value) for key, value in data.items() if key != 'version'}
    if isinstance(data, list):
        return [serializable(value) for value in data]
    return data


@transaction.atomic
def save_snapshot(product, book, user, token, reason):
    existing = HPPSnapshot.objects.filter(token=token, branch_id=product.branch_id).first()
    if existing:
        return existing
    quote = book.quote(product)
    if quote['total'] is None:
        raise ValidationError('Harga belum lengkap. Lengkapi resep dan biaya bahan sebelum menyimpan snapshot.')
    version = quote['version']
    if book.day == timezone.localdate():
        version = record_recipe(product, user)
    return HPPSnapshot.objects.create(
        branch_id=product.branch_id, product=product, version=version, reference_date=book.day,
        method=book.method, window=book.window, token=token, reason=reason, created_by=user,
        data=serializable({'menu': product.name, 'quote': quote, 'channels': [
            profitability(quote['total'], rule) for rule in channel_rules(product)
        ]}),
    )


@transaction.atomic
def produce(*, output, quantity, inputs, direct_cost, day, user, token, notes):
    locked = {pk: lock_stock(pk) for pk in sorted({output.pk, *inputs})}
    previous = HPPProduction.objects.filter(output__token=token, branch_id=output.branch_id).first()
    if previous:
        return previous
    if quantity <= 0 or not inputs or direct_cost < 0 or any(qty <= 0 for qty in inputs.values()):
        raise ValidationError('Isi hasil bersih dan jumlah bahan yang positif.')
    if any(item.branch_id != output.branch_id or not item.active for item in locked.values()):
        raise ValidationError('Semua bahan produksi harus aktif dan berasal dari cabang yang sama.')
    # A new output cannot depend on an ingredient that already depends on it.
    graph = defaultdict(set)
    for batch in HPPProduction.objects.filter(branch_id=output.branch_id).select_related('output'):
        graph[batch.output.ingredient_id].update(item['ingredient_id'] for item in batch.inputs)
    pending, seen = list(inputs), set()
    while pending:
        pk = pending.pop()
        if pk == output.pk:
            raise ValidationError('Produksi akan membentuk siklus bahan setengah jadi.')
        if pk not in seen:
            seen.add(pk)
            pending.extend(graph[pk])
    total, lines = direct_cost, []
    for pk, qty in inputs.items():
        ingredient = locked[pk]
        if ingredient.branch_id != output.branch_id or ingredient.average_cost <= 0:
            raise ValidationError(f'Harga persediaan {ingredient.name} belum lengkap.')
        entry = movement(ingredient, -qty, -qty * ingredient.average_cost, kind='produce_out',
                         user=user, date=day, notes=notes)
        total -= entry.value
        lines.append(dict(ingredient_id=pk, name=ingredient.name, quantity=str(qty), cost=str(-entry.value)))
    entry = movement(locked[output.pk], quantity, total, kind='produce_in', user=user, date=day, notes=notes, token=token)
    return HPPProduction.objects.create(branch_id=output.branch_id, output=entry, inputs=lines, direct_cost=direct_cost)


def sale_quote(product, channel_name, book):
    """Price rules are for simulations; only production and packaging cost enters a sale."""
    quote = book.quote(product)
    if quote['total'] is None:
        raise ValidationError(f'Harga belum lengkap untuk {product.name}: ' + ', '.join(quote['missing']))
    rule = HPPChannelRule.objects.filter(product=product, channel__name__iexact=channel_name).first()
    return money(quote['total'] + (rule.packaging if rule else ZERO)), quote
