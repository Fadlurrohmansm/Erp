from datetime import date
from decimal import Decimal
from io import BytesIO
from unittest.mock import patch
from django.test import TestCase
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.core.files.uploadedfile import SimpleUploadedFile
from django.urls import reverse
from .models import Sale, BusinessSettings
from .csv_import import parse_grab_text, parse_grab_pdf
from .forms import ImportCostsForm
from .reporting import summary

TEXT='''Laporan Bisnis Harian
28 Oktober 2026, Rabu
Seblak Sayank - Sumbersari
Ringkasan
Total Pendapatan Sisa Tagihan Penjual Total Pesanan
IDR 160,00 IDR 0,00
1 pesanan
Pendapatan
Total pembayaran akan ditransfer besok.
Nilai Pesanan PB1 Biaya layanan restoran Promosi yang Dibiayai Merchant Biaya Jasa Diskon Ongkos Kirim yang Dibiayai Total Pendapatan Sisa Tagihan Penjual
300,00
0,00
0,00
-100,00
-
40,00
0,00
160,00
0,00
Pesanan Aplikasi & Web
Pesanan yang Diantar
7:13 PM
GF-123
300,00
0,00
-
-100,00
-
40,00
0,00
160,00
Harga Total IDR 160,00
Cara Membaca Laporan Ini
'''

def fixture_pdf(text=TEXT):
    from reportlab.pdfgen import canvas
    stream=BytesIO();c=canvas.Canvas(stream)
    y=800
    for line in text.splitlines():
        c.drawString(30,y,line);y-=13
        if y<30:c.showPage();y=800
    c.save();return stream.getvalue()

class GrabImportTests(TestCase):
    def setUp(self):
        self.user=get_user_model().objects.create_user('grabtester',password='testing')
        self.client.force_login(self.user)

    def test_summary_and_details_reconcile(self):
        result=parse_grab_text(TEXT,b'fake')
        self.assertEqual(result['outlet'],'Seblak Sayank - Sumbersari')
        self.assertEqual(result['rows'][0]['order_count'],1)
        self.assertEqual(result['rows'][0]['net_revenue'],'160.00')

    def test_invalid_count_total_and_missing_rows(self):
        for text in [TEXT.replace('1 pesanan','2 pesanan'),TEXT.replace('IDR 160,00 IDR','IDR 159,00 IDR'),TEXT.replace('GF-123','unknown'),TEXT.replace('-100,00','-99,00'),TEXT.replace('28 Oktober 2026','28 Oktober 2099')]:
            with self.assertRaises(ValidationError):parse_grab_text(text,b'bad')

    def test_broken_pdf_rejected(self):
        with self.assertRaises(ValidationError):parse_grab_pdf(b'%PDF-broken')

    def test_short_order_code_can_be_reused(self):
        second = '8:01 PM\nGF-123\n200,00\n0,00\n-\n-20,00\n-\n10,00\n0,00\n170,00\n'
        header, detail = TEXT.split('Pesanan Aplikasi & Web', 1)
        header = (header.replace('1 pesanan', '2 pesanan').replace('300,00', '500,00')
                  .replace('-100,00', '-120,00').replace('40,00', '50,00').replace('160,00', '330,00'))
        report = header + 'Pesanan Aplikasi & Web' + detail.replace('Harga Total', second + 'Harga Total')
        parsed = parse_grab_text(report, b'reused-code')
        self.assertEqual(parsed['rows'][0]['order_count'], 2)
        self.assertEqual(parsed['rows'][0]['net_revenue'], '330.00')

    def test_real_pdf_pipeline_auto_hpp_and_reporting(self):
        BusinessSettings.objects.update_or_create(pk=1,defaults={'import_hpp_rate':Decimal('40')})
        url=reverse('sale_import')
        response=self.client.post(url,{'action':'preview','file':SimpleUploadedFile('grab.pdf',fixture_pdf(),content_type='application/pdf')})
        self.assertContains(response,'Sumbersari')
        draft=self.client.session['csv_import_draft']
        self.assertEqual(draft['hpp_rate'],'40.00')
        # No manual HPP field is submitted: server computes it from the approved setting.
        response=self.client.post(url,{'action':'commit','draft_id':draft['draft_id'],'auto_hpp':'on','complete':'on'})
        self.assertEqual(response.status_code,302)
        sale=Sale.objects.get();self.assertEqual(sale.cost,120);self.assertTrue(sale.cost_estimated)
        self.assertEqual(sale.net_revenue,160);self.assertEqual(sale.gross_profit,40)
        self.assertTrue(summary(date(2026,10,1),date(2026,10,31))['estimated_hpp'])
        self.assertContains(self.client.get(reverse('reports')+'?month=2026-10&export=csv'),'estimasi HPP otomatis')
        self.assertEqual(self.client.post(url,{'action':'preview','file':SimpleUploadedFile('copy.pdf',fixture_pdf())}).status_code,200)
        self.assertEqual(Sale.objects.count(),1)

    def test_cost_modes_no_default_and_manual_override(self):
        rows=parse_grab_text(TEXT,b'x')['rows']
        f=ImportCostsForm({'complete':'on'},rows=rows)
        self.assertFalse(f.is_valid())
        f=ImportCostsForm({'complete':'on','auto_hpp':'on'},rows=rows,rate='40')
        self.assertTrue(f.is_valid());self.assertEqual(f.cleaned_data['cost_0'],120)
        f=ImportCostsForm({'complete':'on','cost_0':'125'},rows=rows,rate='40')
        self.assertTrue(f.is_valid());self.assertEqual(f.cleaned_data['cost_0'],125)

    def test_settings_rate_bounds(self):
        from .forms import BusinessForm
        for value in ['-1','101']:
            f=BusinessForm({'name':'Tes','tagline':'Tes','import_hpp_rate':value})
            self.assertFalse(f.is_valid());self.assertIn('import_hpp_rate',f.errors)

    def test_cancelled_order_is_skipped_but_count_reconciles(self):
        cancelled = 'Pesanan dibatalkan\nGF-422\n' + '-\n' * 7
        text = TEXT.replace('1 pesanan', '2 pesanan').replace('7:13 PM', cancelled + '7:13 PM')
        result = parse_grab_text(text, b'cancelled')
        self.assertEqual(result['skipped'], 1)
        self.assertEqual(result['rows'][0]['order_count'], 1)
        self.assertEqual(result['rows'][0]['net_revenue'], '160.00')
        for broken in [text.replace('Pesanan dibatalkan', 'Unknown'), text.replace(cancelled, cancelled.replace('-\n', '1,00\n', 1)), text.replace('2 pesanan', '3 pesanan')]:
            with self.assertRaises(ValidationError):
                parse_grab_text(broken, b'broken')
