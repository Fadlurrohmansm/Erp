from django.contrib import admin
from .models import Ingredient, Product, Recipe, Channel, Sale, SaleItem, StockMovement, Expense, BusinessSettings

from .forms import ProductForm,RecipeForm,IngredientForm

class RecipeInline(admin.TabularInline):
    form=RecipeForm
    model=Recipe
    extra=0

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    form=ProductForm
    list_display=['name','price','active']
    inlines=[RecipeInline]
    search_fields=['name']

class ReadOnlyAdmin(admin.ModelAdmin):
    def has_add_permission(self,request):return False
    def has_change_permission(self,request,obj=None):return False
    def has_delete_permission(self,request,obj=None):return False

@admin.register(Ingredient)
class IngredientAdmin(admin.ModelAdmin):
    form=IngredientForm
    list_display=['name','unit','stock','average_cost','active']
    readonly_fields=['stock','average_cost']
    def has_delete_permission(self,request,obj=None):return False

@admin.register(Sale)
class SaleAdmin(ReadOnlyAdmin):
    list_display=['id','date','channel_name','net_revenue','status']
    list_filter=['status','date']

@admin.register(StockMovement)
class MovementAdmin(ReadOnlyAdmin):
    list_display=['date','ingredient','kind','quantity','stock_after']
    list_filter=['kind']

@admin.register(Expense)
class ExpenseAdmin(ReadOnlyAdmin):
    list_display=['date','description','amount','voided']

admin.site.register(Channel)
admin.site.site_header='ERP F&B · Administrasi'
admin.site.site_title='ERP F&B'
admin.site.index_title='Administrasi data'
