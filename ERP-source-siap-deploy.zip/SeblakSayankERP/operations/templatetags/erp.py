from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from django import template
register = template.Library()

@register.filter
def rupiah(value):
    try:
        amount = Decimal(value)
        if not amount.is_finite():return 'Rp0'
        amount = amount.quantize(Decimal('.01'), rounding=ROUND_HALF_UP)
        places = 0 if amount == amount.to_integral_value() else 2
        number = format(abs(amount), f',.{places}f').replace(',', '_').replace('.', ',').replace('_', '.')
        return ('-Rp' if amount < 0 else 'Rp') + number
    except (InvalidOperation, TypeError, ValueError):
        return 'Rp0'

@register.filter
def is_money_field(field):
    names = {'base_salary','daily_rate','daily_amount','manual_deduction','fuel_allowance','punctual_bonus_per_day','amount','price','manual_cost','unit_price','total_cost','subtotal','manual_cash','manual_qris','voucher_amount','commission_amount','other_fees','cost'}
    return field.name in names or field.name.startswith(('hpp_', 'cost_'))

@register.filter
def qty(value):
    try:
        return format(Decimal(value), '.3f').rstrip('0').rstrip('.').replace('.', ',')
    except (InvalidOperation, TypeError, ValueError):
        return '0'
