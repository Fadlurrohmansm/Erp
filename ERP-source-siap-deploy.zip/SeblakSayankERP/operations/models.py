from tenancy.models import BranchScopedModel
import uuid
from decimal import Decimal
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from django.utils import timezone

ZERO = Decimal('0')
MONEY = dict(max_digits=16, decimal_places=2, default=0, validators=[MinValueValidator(0)])

class Ingredient(BranchScopedModel):
    UNIT_CHOICES = [('g', 'Gram'), ('ml', 'Mililiter'), ('pcs', 'Pcs')]
    name = models.CharField('Nama bahan', max_length=100)
    unit = models.CharField('Satuan dasar', max_length=5, choices=UNIT_CHOICES, default='g')
    category_name = models.CharField('Kategori bahan', max_length=80, blank=True)
    purchase_unit = models.CharField('Satuan pembelian khusus', max_length=20, blank=True)
    purchase_factor = models.DecimalField('Isi satuan khusus dalam satuan dasar', max_digits=16, decimal_places=6, null=True, blank=True,
                                          validators=[MinValueValidator(Decimal('.000001'))])
    supplier = models.CharField('Supplier utama', max_length=100, blank=True)
    stock = models.DecimalField(max_digits=16, decimal_places=3, default=0)
    average_cost = models.DecimalField(max_digits=18, decimal_places=6, default=0)
    minimum_stock = models.DecimalField('Batas stok minimum', max_digits=16, decimal_places=3, default=0, validators=[MinValueValidator(0)])
    active = models.BooleanField('Aktif', default=True)
    class Meta:
        ordering = ['name']
        constraints = [
            models.UniqueConstraint(fields=['branch','name'],name='branch_ingredient_name'),
            models.CheckConstraint(condition=models.Q(stock__gte=0), name='ingredient_nonnegative_stock'),
            models.CheckConstraint(condition=models.Q(average_cost__gte=0), name='ingredient_nonnegative_cost'),
        ]
    def __str__(self):
        return f'{self.name} ({self.unit})'
    @property
    def stock_value(self):
        return self.stock * self.average_cost
    @property
    def low_stock(self):
        return self.stock <= self.minimum_stock

class MenuCategory(BranchScopedModel):
    name=models.CharField('Nama kategori',max_length=100)
    class Meta:
        ordering=['name']
        constraints=[models.UniqueConstraint(fields=['branch','name'],name='branch_category_name')]
    def __str__(self):return self.name

class Product(BranchScopedModel):
    sales_kind=models.CharField('Jenis item terjual',max_length=10,choices=[('main','Produk utama / porsi'),('addon','Tambahan / add-on'),('other','Lainnya')],default='main',help_text='Produk utama dihitung sebagai porsi/unit terjual; tambahan tidak menambah porsi.')
    category=models.ForeignKey(MenuCategory,null=True,blank=True,on_delete=models.SET_NULL,verbose_name='Kategori')
    name = models.CharField('Nama menu', max_length=100)
    price = models.DecimalField('Harga jual', **MONEY)
    manual_cost = models.DecimalField('HPP manual per porsi', help_text='Digunakan hanya jika menu belum memiliki resep. Isi seluruh biaya bahan dan kemasan.', **MONEY)
    hpp_shopeefood = models.DecimalField('HPP ShopeeFood per porsi (Rp)', null=True, blank=True, help_text='Biaya bahan dan kemasan per porsi, tidak termasuk komisi/voucher. Kosongkan untuk memakai HPP resep atau HPP dasar.', **{**MONEY, 'default': None})
    hpp_grabfood = models.DecimalField('HPP GrabFood per porsi (Rp)', null=True, blank=True, help_text='Biaya bahan dan kemasan per porsi, tidak termasuk komisi/voucher. Kosongkan untuk memakai HPP resep atau HPP dasar.', **{**MONEY, 'default': None})
    hpp_gofood = models.DecimalField('HPP GoFood per porsi (Rp)', null=True, blank=True, help_text='Biaya bahan dan kemasan per porsi, tidak termasuk komisi/voucher. Kosongkan untuk memakai HPP resep atau HPP dasar.', **{**MONEY, 'default': None})
    variant_of = models.ForeignKey('self', null=True, blank=True, on_delete=models.SET_NULL,
                                   related_name='variants', verbose_name='Menu induk varian')
    batch_yield = models.DecimalField('Hasil bersih resep (porsi)', max_digits=12, decimal_places=3, default=1, validators=[MinValueValidator(Decimal('.001'))])
    recipe_direct_cost = models.DecimalField('Biaya langsung per batch (Rp)', **MONEY)
    active = models.BooleanField('Aktif dijual', default=True)
    class Meta:
        ordering = ['name']
        constraints=[models.UniqueConstraint(fields=['branch','name'],name='branch_product_name')]
    def __str__(self):
        return self.name
    @property
    def estimated_cost(self):
        recipes = list(self.recipes.all())
        if not recipes:
            return self.manual_cost
        from .hpp import net_quantity
        return sum((net_quantity(r.quantity, r.waste, self.batch_yield) * r.ingredient.average_cost
                    for r in recipes), ZERO) + Decimal(self.recipe_direct_cost) / self.batch_yield

    def manual_channel_cost(self, channel):
        field = {'shopeefood': 'hpp_shopeefood', 'grabfood': 'hpp_grabfood', 'gofood': 'hpp_gofood'}.get(str(channel).strip().casefold())
        return getattr(self, field) if field else None

    def cost_for_channel(self, channel):
        override = self.manual_channel_cost(channel)
        return override if override is not None else self.estimated_cost


class Recipe(BranchScopedModel):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='recipes')
    ingredient = models.ForeignKey(Ingredient, on_delete=models.PROTECT, verbose_name='Bahan')
    quantity = models.DecimalField('Jumlah per porsi', max_digits=12, decimal_places=3, validators=[MinValueValidator(Decimal('.001'))])
    waste = models.DecimalField('Waste (%)', max_digits=5, decimal_places=2, default=0, validators=[MinValueValidator(0), MaxValueValidator(Decimal('99.99'))])
    role = models.CharField('Jenis biaya', max_length=10, choices=[('ingredient','Bahan'),('packaging','Kemasan'),('addon','Tambahan')], default='ingredient')
    substitute = models.ForeignKey(Ingredient, on_delete=models.PROTECT, null=True, blank=True, related_name='+', verbose_name='Bahan pengganti')
    class Meta:
        constraints = [models.UniqueConstraint(fields=['product', 'ingredient'], name='unique_recipe_ingredient')]
    def __str__(self):
        return f'{self.product}: {self.ingredient}'

class Channel(BranchScopedModel):
    name = models.CharField('Nama kanal', max_length=50)
    voucher_rate = models.DecimalField('Subsidi voucher (%)', max_digits=5, decimal_places=2, default=0, validators=[MinValueValidator(0), MaxValueValidator(100)])
    commission_rate = models.DecimalField('Komisi (%) setelah voucher', max_digits=5, decimal_places=2, default=0, validators=[MinValueValidator(0), MaxValueValidator(100)])
    def __str__(self):
        return self.name
    class Meta:
        ordering = ['id']
        constraints=[models.UniqueConstraint(fields=['branch','name'],name='branch_channel_name')]

class Sale(BranchScopedModel):
    cost_estimated = models.BooleanField(default=False)
    is_recap = models.BooleanField(default=False)
    order_count = models.PositiveIntegerField('Jumlah pesanan', default=1)
    other_fees = models.DecimalField(**MONEY)
    PAYMENT_CHOICES = [('cash', 'Tunai'), ('qris', 'QRIS'), ('platform', 'Saldo platform'), ('transfer', 'Transfer')]
    token = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)
    date = models.DateField('Tanggal', default=timezone.localdate, db_index=True)
    channel = models.ForeignKey(Channel, on_delete=models.PROTECT, verbose_name='Kanal penjualan')
    channel_name = models.CharField(max_length=50)
    payment_method = models.CharField('Pembayaran', max_length=12, choices=PAYMENT_CHOICES, default='cash')
    manual_cash = models.DecimalField(**{**MONEY, 'default': None}, null=True, blank=True)
    manual_qris = models.DecimalField(**{**MONEY, 'default': None}, null=True, blank=True)
    manual_portions = models.PositiveIntegerField(null=True, blank=True)
    voucher_rate = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    commission_rate = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    subtotal = models.DecimalField(**MONEY)
    voucher_amount = models.DecimalField(**MONEY)
    commission_amount = models.DecimalField(**MONEY)
    net_revenue = models.DecimalField(**MONEY)
    cost = models.DecimalField(**MONEY)
    status = models.CharField(max_length=10, choices=[('posted', 'Tercatat'), ('void', 'Dibatalkan')], default='posted')
    notes = models.CharField('Catatan', max_length=255, blank=True)
    void_reason = models.CharField(max_length=255, blank=True)
    created_by = models.ForeignKey('auth.User', on_delete=models.PROTECT)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering = ['-date', '-id']
        constraints = [models.UniqueConstraint(fields=['date', 'channel'], condition=models.Q(is_recap=True, status='posted'), name='unique_active_daily_channel_recap')]
    @property
    def has_manual_payments(self):
        return self.manual_cash is not None or self.manual_qris is not None

    @property
    def number(self):
        return f'SS-{self.date:%y%m%d}-{self.pk:05d}'
    @property
    def platform_fees(self):
        return self.voucher_amount + self.commission_amount + self.other_fees

    @property
    def gross_profit(self):
        return self.net_revenue - self.cost

class SaleItem(BranchScopedModel):
    sale = models.ForeignKey(Sale, on_delete=models.PROTECT, related_name='items')
    product = models.ForeignKey(Product, on_delete=models.PROTECT)
    product_name = models.CharField(max_length=100)
    quantity = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    unit_price = models.DecimalField(**MONEY)
    unit_cost = models.DecimalField(**MONEY)
    @property
    def total(self):
        return self.quantity * self.unit_price

class StockMovement(BranchScopedModel):
    token = models.UUIDField(null=True, blank=True, unique=True, editable=False)
    KINDS = [('purchase', 'Pembelian'), ('count', 'Stok opname'), ('sale', 'Penjualan'), ('reversal', 'Pembatalan penjualan'), ('purchase_rb', 'Koreksi pembelian'), ('produce_in', 'Hasil produksi'), ('produce_out', 'Pemakaian produksi')]
    ingredient = models.ForeignKey(Ingredient, on_delete=models.PROTECT, related_name='movements')
    date = models.DateField(default=timezone.localdate, db_index=True)
    kind = models.CharField(max_length=12, choices=KINDS)
    quantity = models.DecimalField(max_digits=16, decimal_places=3)
    value = models.DecimalField(max_digits=18, decimal_places=6)
    stock_after = models.DecimalField(max_digits=16, decimal_places=3)
    average_after = models.DecimalField(max_digits=18, decimal_places=6, null=True, blank=True)
    sale = models.ForeignKey(Sale, null=True, blank=True, on_delete=models.PROTECT, related_name='movements')
    notes = models.CharField(max_length=255, blank=True)
    created_by = models.ForeignKey('auth.User', on_delete=models.PROTECT)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering = ['-created_at', '-id']

class Expense(BranchScopedModel):
    token = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)
    CATEGORIES = [('rent', 'Sewa tempat'), ('utilities', 'Listrik, air & gas'), ('transport', 'Transportasi'), ('marketing', 'Promosi'), ('equipment', 'Peralatan kecil'), ('other', 'Lainnya')]
    date = models.DateField('Tanggal', default=timezone.localdate, db_index=True)
    category = models.CharField('Kategori', max_length=15, choices=CATEGORIES)
    description = models.CharField('Keterangan', max_length=200)
    amount = models.DecimalField('Jumlah', **{**MONEY, 'validators': [MinValueValidator(Decimal('.01'))]})
    voided = models.BooleanField(default=False)
    void_reason = models.CharField(max_length=255, blank=True)
    created_by = models.ForeignKey('auth.User', on_delete=models.PROTECT)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering = ['-date', '-id']

class BusinessSettings(models.Model):
    pos_count_mode=models.CharField('Aturan hitung unit POS',max_length=10,choices=[('product','Jenis item pada menu ERP'),('keyword','Kata kunci nama asli POS')],default='product')
    pos_main_keywords=models.CharField('Kata kunci produk utama POS',max_length=255,blank=True,default='',help_text='Untuk mode kata kunci: pisahkan dengan koma, misalnya nasi, ayam, kopi. Nama lain menjadi tambahan. Mode jenis item cocok untuk usaha dengan berbagai produk.')
    pos_noncash_method=models.CharField('Arti Non Tunai di ekspor POS',max_length=10,choices=[('noncash','Non-tunai umum (belum tentu QRIS)'),('qris','QRIS'),('transfer','Transfer')],default='noncash')

    import_hpp_rate = models.DecimalField('Estimasi HPP impor (% dari omzet bruto)', max_digits=5, decimal_places=2, null=True, blank=True, validators=[MinValueValidator(0), MaxValueValidator(100)], help_text='Isi sekali agar impor menghitung HPP otomatis. Gunakan rasio biaya bahan dan kemasan terhadap omzet bruto berdasarkan usahamu. Kosongkan untuk HPP manual; 40 berarti 40%, bukan tarif platform.')
    name = models.CharField('Nama usaha', max_length=100, default='Usaha F&B')
    tagline = models.CharField('Tagline', max_length=150, default='Kelola usaha dalam satu tempat.')
    address = models.CharField('Alamat', max_length=255, blank=True)
    phone = models.CharField('Telepon', max_length=30, blank=True)
    def save(self, *args, **kwargs):
        self.pk = 1
        return super().save(*args, **kwargs)


class CSVImport(BranchScopedModel):
    class Meta:
        constraints=[models.UniqueConstraint(fields=['branch','fingerprint'],name='branch_csv_fingerprint')]
    fingerprint = models.CharField(max_length=64)
    filename = models.CharField(max_length=255)
    channel = models.CharField(max_length=50)
    created_by = models.ForeignKey('auth.User', on_delete=models.PROTECT)
    created_at = models.DateTimeField(auto_now_add=True)
    sales = models.ManyToManyField(Sale, related_name='csv_imports')


class POSProductAlias(BranchScopedModel):
    class Meta:
        constraints=[models.UniqueConstraint(fields=['branch','name'],name='branch_pos_alias')]
    name = models.CharField(max_length=255)
    product = models.ForeignKey(Product, on_delete=models.PROTECT)

class POSCostImport(BranchScopedModel):
    payments=models.JSONField(default=dict,blank=True)
    @property
    def quantities(self):
        from .pos_quantities import pos_quantities
        return pos_quantities(self.lines)

    class Meta:
        constraints=[models.UniqueConstraint(fields=['branch','fingerprint'],name='branch_pos_fingerprint')]
    fingerprint = models.CharField(max_length=64)
    sale = models.OneToOneField(Sale, on_delete=models.PROTECT, related_name='pos_cost_import')
    filename = models.CharField(max_length=255)
    lines = models.JSONField(default=list)
    previous_cost = models.DecimalField(max_digits=16, decimal_places=2)
    total_cost = models.DecimalField(max_digits=16, decimal_places=2)
    created_by = models.ForeignKey('auth.User', on_delete=models.PROTECT)
    created_at = models.DateTimeField(auto_now_add=True)


class MenuLayoutPreference(BranchScopedModel):
    user=models.ForeignKey('auth.User',on_delete=models.CASCADE)
    show_all=models.BooleanField(default=True)
    category_ids=models.JSONField(default=list,blank=True)
    show_uncategorized=models.BooleanField(default=True)
    class Meta:
        constraints=[models.UniqueConstraint(fields=['branch','user'],name='branch_user_menu_layout')]


class HPPPolicy(BranchScopedModel):
    METHODS = [('latest', 'Harga beli terakhir'), ('weighted', 'Rata-rata pembelian tertimbang'),
               ('moving', 'Rata-rata persediaan berjalan')]
    method = models.CharField('Metode default', max_length=10, choices=METHODS, default='moving')
    window = models.PositiveSmallIntegerField('Periode pembelian (hari)', choices=[(7, '7'), (30, '30'), (90, '90')], default=30)
    target_food = models.DecimalField('Target food cost (%)', max_digits=5, decimal_places=2, default=40,
                                    validators=[MinValueValidator(Decimal('.01')), MaxValueValidator(100)])
    target_margin = models.DecimalField('Target margin kotor (%)', max_digits=5, decimal_places=2, default=0,
                                      validators=[MinValueValidator(0), MaxValueValidator(Decimal('99.99'))])
    warning = models.DecimalField('Ambang peringatan (%)', max_digits=6, decimal_places=2, default=10, validators=[MinValueValidator(Decimal('.01'))])
    critical = models.DecimalField('Ambang kritis (%)', max_digits=6, decimal_places=2, default=20, validators=[MinValueValidator(Decimal('.01'))])
    rounding = models.PositiveIntegerField('Kelipatan pembulatan harga (Rp)', default=500, validators=[MinValueValidator(1)])
    apply_to_sales = models.BooleanField('Gunakan HPP dinamis untuk penjualan dan rekonsiliasi POS baru', default=False)

    class Meta:
        constraints = [models.UniqueConstraint(fields=['branch'], name='hpp_policy_per_branch')]


class HPPPurchase(BranchScopedModel):
    movement = models.OneToOneField(StockMovement, on_delete=models.PROTECT, related_name='purchase_detail')
    supplier = models.CharField(max_length=100, blank=True)
    unit = models.CharField(max_length=20)
    quantity = models.DecimalField(max_digits=16, decimal_places=3)
    factor = models.DecimalField(max_digits=16, decimal_places=6)
    unit_price = models.DecimalField(**MONEY)
    discount = models.DecimalField(**MONEY)
    freight = models.DecimalField(**MONEY)
    cancelled_at = models.DateTimeField(null=True, blank=True)
    cancelled_by = models.ForeignKey('auth.User', on_delete=models.PROTECT, null=True, blank=True)
    reason = models.CharField(max_length=255, blank=True)


class HPPRecipeVersion(BranchScopedModel):
    product = models.ForeignKey(Product, on_delete=models.PROTECT, related_name='hpp_versions')
    effective_date = models.DateField(default=timezone.localdate)
    recipe = models.JSONField()
    created_by = models.ForeignKey('auth.User', on_delete=models.PROTECT)
    created_at = models.DateTimeField(auto_now_add=True)


class HPPChannelRule(BranchScopedModel):
    BASIS = [('menu', 'Persen dari harga menu'), ('discounted', 'Persen setelah diskon pelanggan'), ('fixed', 'Nominal tetap per porsi')]
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    channel = models.ForeignKey(Channel, on_delete=models.CASCADE)
    price = models.DecimalField('Harga jual kanal (Rp)', **MONEY)
    merchant_rate = models.DecimalField('Diskon merchant (%)', max_digits=5, decimal_places=2, default=0, validators=[MinValueValidator(0), MaxValueValidator(100)])
    merchant_fixed = models.DecimalField('Diskon merchant tetap (Rp)', **MONEY)
    platform_rate = models.DecimalField('Diskon ditanggung platform (%)', max_digits=5, decimal_places=2, default=0,
                                        validators=[MinValueValidator(0), MaxValueValidator(100)])
    platform_discount = models.DecimalField('Voucher ditanggung platform (Rp)', **MONEY)
    commission_basis = models.CharField('Dasar komisi', max_length=12, choices=BASIS, default='discounted')
    commission_rate = models.DecimalField('Komisi (%)', max_digits=5, decimal_places=2, default=0, validators=[MinValueValidator(0), MaxValueValidator(100)])
    commission_fixed = models.DecimalField('Komisi tetap (Rp)', **MONEY)
    service_fee = models.DecimalField('Biaya layanan per transaksi (Rp)', **MONEY)
    payment_fee = models.DecimalField('Biaya pembayaran per transaksi (Rp)', **MONEY)
    portions_per_order = models.PositiveIntegerField('Porsi per transaksi untuk simulasi', default=1, validators=[MinValueValidator(1)])
    packaging = models.DecimalField('Tambahan biaya kemasan per porsi (Rp)', **MONEY)

    class Meta:
        constraints = [models.UniqueConstraint(fields=['product', 'channel'], name='hpp_rule_product_channel')]


class HPPSnapshot(BranchScopedModel):
    product = models.ForeignKey(Product, on_delete=models.PROTECT)
    version = models.ForeignKey(HPPRecipeVersion, on_delete=models.PROTECT)
    reference_date = models.DateField()
    method = models.CharField(max_length=10, choices=HPPPolicy.METHODS)
    window = models.PositiveSmallIntegerField()
    data = models.JSONField()
    reason = models.CharField(max_length=255)
    token = models.UUIDField(unique=True, default=uuid.uuid4)
    created_by = models.ForeignKey('auth.User', on_delete=models.PROTECT)
    created_at = models.DateTimeField(auto_now_add=True)


class HPPProduction(BranchScopedModel):
    output = models.OneToOneField(StockMovement, on_delete=models.PROTECT)
    inputs = models.JSONField()
    direct_cost = models.DecimalField(**MONEY)
    created_at = models.DateTimeField(auto_now_add=True)
