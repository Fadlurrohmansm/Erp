import io
from zipfile import ZipFile, ZIP_DEFLATED
from xml.sax.saxutils import escape
from decimal import Decimal
from datetime import date
from django.test import TestCase
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.core.files.uploadedfile import SimpleUploadedFile
from django.urls import reverse
from .models import Product, Channel, Sale, POSCostImport, POSProductAlias, Recipe, Ingredient
from .pos_import import parse_pos_xlsx, snapshot_lines
from .services import post_daily_recap
from .reporting import summary
import uuid

# Minimal OOXML test fixture, no customer data.
HEAD=['No. Struk','Tanggal','Nama Outlet','Nama Produk','Jumlah Produk','Status','Total','Produk Ekstra','Harga Produk Ekstra']
ROWS=[['R1','28-10-2026','Test','Menu A',2,'LUNAS',10000,None,None],[None,None,None,'Menu B',1,None,None,None,None],[None,None,None,'Total',3,None,10000,'-',0]]
def fixture(rows=None):
    buf=io.BytesIO()
    values=[HEAD]+(rows if rows is not None else ROWS)
    sheet='<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>'
    for i,row in enumerate(values,1):
        sheet+=f'<row r="{i}">'
        for j,v in enumerate(row):
            if v is None:continue
            col=chr(65+j);cell=f'{col}{i}'
            if isinstance(v,int):sheet+=f'<c r="{cell}"><v>{v}</v></c>'
            else:sheet+=f'<c r="{cell}" t="inlineStr"><is><t>{escape(str(v))}</t></is></c>'
        sheet+='</row>'
    sheet+='</sheetData></worksheet>'
    with ZipFile(buf,'w',ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml','<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>')
        z.writestr('_rels/.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr('xl/workbook.xml','<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Riwayat Penjualan" sheetId="1" r:id="rId1"/></sheets></workbook>')
        z.writestr('xl/_rels/workbook.xml.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>')
        z.writestr('xl/worksheets/sheet1.xml',sheet)
    return buf.getvalue()

class POSImportTests(TestCase):
    def setUp(self):
        from .models import BusinessSettings
        BusinessSettings.objects.update_or_create(pk=1,defaults={'pos_count_mode':'keyword','pos_main_keywords':'seblak','pos_noncash_method':'qris'})
        self.user=get_user_model().objects.create_user('postester',password='testing');self.client.force_login(self.user)
        self.a=Product.objects.create(name='Menu A',manual_cost=1000,price=5000)
        self.b=Product.objects.create(name='Menu B',manual_cost=2000,price=5000)
        self.sale=post_daily_recap(data=dict(token=uuid.uuid4(),date=date(2026,10,28),channel=Channel.objects.get(name='Offline'),order_count=1,subtotal=Decimal('10000'),voucher_amount=Decimal(0),commission_amount=Decimal(0),other_fees=Decimal(0),cost=Decimal('3000')),user=self.user)
    def upload(self):
        return self.client.post(reverse('pos_import'),{'action':'upload','channel':self.sale.channel_id,'complete':'on','file':SimpleUploadedFile('pos.xlsx',fixture())})
    def test_parse_inherits_receipt_and_skips_total(self):
        d=parse_pos_xlsx(fixture());self.assertEqual(d['orders'],1);self.assertEqual(len(d['items']),2);self.assertEqual(d['items'][0]['quantity'],'2');self.assertEqual(d['pos_revenue'],'10000')
    def test_full_flow_updates_only_cost_and_stores_snapshot(self):
        self.assertEqual(self.upload().status_code,200);d=self.client.session['pos_cost_draft']
        response=self.client.post(reverse('pos_import'),{'action':'map','draft_id':d['id'],'product_0':self.a.pk,'product_1':self.b.pk})
        self.assertContains(response,'Rp4.000');self.sale.refresh_from_db();self.assertEqual(self.sale.cost,3000)
        self.assertEqual(self.client.post(reverse('pos_import'),{'action':'commit','draft_id':d['id'],'confirm':'on'}).status_code,302)
        self.sale.refresh_from_db();self.assertEqual(self.sale.cost,4000);self.assertEqual(self.sale.net_revenue,10000);self.assertEqual(Sale.objects.count(),1)
        self.assertEqual(POSProductAlias.objects.count(),2);self.assertEqual(POSCostImport.objects.count(),1)
        self.assertFalse(self.sale.movements.exists());self.assertEqual(POSCostImport.objects.get().lines[0]['unit_cost'],'1000.00')
        self.a.manual_cost=9999;self.a.save();self.sale.refresh_from_db();self.assertEqual(self.sale.cost,4000)
        self.assertEqual(summary(date(2026,10,1),date(2026,10,31))['cost'],4000)
        self.upload();self.assertEqual(POSCostImport.objects.count(),1)
        self.assertContains(self.client.get(reverse('sale_detail',args=[self.sale.pk])),'resep POS')
    def test_unknown_menu_rejected_and_zero_recipe_allowed(self):
        self.upload();d=self.client.session['pos_cost_draft']
        self.assertEqual(self.client.post(reverse('pos_import'),{'action':'map','draft_id':d['id'],'product_0':'9999','product_1':self.b.pk}).status_code,200)
        self.a.manual_cost=0;self.a.save()
        self.assertEqual(snapshot_lines(d,{'product_0':self.a,'product_1':self.b})[0]['unit_cost'],'0.00')
        i=Ingredient.objects.create(name='Test ingredient');Recipe.objects.create(product=self.a,ingredient=i,quantity=50)
        self.assertEqual(snapshot_lines(d,{'product_0':self.a,'product_1':self.b})[0]['unit_cost'],'0.00')
    def test_invalid_status_quantity_footer_and_extra(self):
        for idx,col,value in [(0,5,'BATAL'),(0,4,-1),(2,4,99),(0,7,'Keju'),(0,1,'29-10-2099')]:
            rows=[x.copy() for x in ROWS];rows[idx][col]=value
            with self.assertRaises(ValidationError):parse_pos_xlsx(fixture(rows))
        with self.assertRaises(ValidationError):parse_pos_xlsx(b'broken')
    def test_requires_recap_same_day_channel_and_confirmation(self):
        self.sale.status='void';self.sale.save()
        self.upload();self.assertTrue(self.client.session['pos_cost_draft']['create_offline'])
        self.sale.status='posted';self.sale.save();self.upload();d=self.client.session['pos_cost_draft']
        self.client.post(reverse('pos_import'),{'action':'map','draft_id':d['id'],'product_0':self.a.pk,'product_1':self.b.pk})
        self.client.post(reverse('pos_import'),{'action':'commit','draft_id':d['id']})
        self.assertFalse(POSCostImport.objects.exists())
        self.sale.status='void';self.sale.save()
        self.client.post(reverse('pos_import'),{'action':'commit','draft_id':d['id'],'confirm':'on'})
        self.assertFalse(POSCostImport.objects.exists())
    def test_login(self):
        self.client.logout();self.assertEqual(self.client.get(reverse('pos_import')).status_code,302)

    def test_offline_creates_revenue_and_recipe_cost_once(self):
        self.sale.delete()
        self.upload();d=self.client.session['pos_cost_draft'];self.assertTrue(d['create_offline'])
        self.client.post(reverse('pos_import'),{'action':'map','draft_id':d['id'],'product_0':self.a.pk,'product_1':self.b.pk})
        response=self.client.post(reverse('pos_import'),{'action':'commit','draft_id':d['id'],'confirm':'on'})
        self.assertEqual(response.status_code,302)
        sale=Sale.objects.get();self.assertEqual(sale.subtotal,10000);self.assertEqual(sale.net_revenue,10000);self.assertEqual(sale.cost,4000)
        self.assertEqual(sale.order_count,1);self.assertFalse(sale.cost_estimated)
        self.upload();self.assertEqual(Sale.objects.count(),1)

    def test_offline_revenue_mismatch_rejected(self):
        self.sale.net_revenue=9999;self.sale.save()
        self.upload();self.assertNotIn('pos_cost_draft',self.client.session)
        self.assertFalse(POSCostImport.objects.exists())

    def test_zero_hpp_can_create_and_update_recap(self):
        self.a.manual_cost=0;self.a.save()
        self.b.manual_cost=0;self.b.save()
        for create in (False,True):
            with self.subTest(create=create):
                if create:
                    POSCostImport.objects.all().delete()
                    self.sale.delete()
                self.upload();d=self.client.session['pos_cost_draft']
                response=self.client.post(reverse('pos_import'),{'action':'map','draft_id':d['id'],'product_0':self.a.pk,'product_1':self.b.pk})
                self.assertContains(response,'HPP Rp0 tetap diterima')
                response=self.client.post(reverse('pos_import'),{'action':'commit','draft_id':d['id'],'confirm':'on'})
                self.assertEqual(response.status_code,302)
                sale=Sale.objects.get();self.assertEqual(sale.cost,0);self.assertEqual(sale.net_revenue,10000)
                self.assertEqual(POSCostImport.objects.get().total_cost,0)

    def test_portion_summary_from_saved_original_pos_names(self):
        from .pos_quantities import pos_quantities
        self.upload();d=self.client.session['pos_cost_draft']
        self.client.post(reverse('pos_import'),{'action':'map','draft_id':d['id'],'product_0':self.a.pk,'product_1':self.b.pk})
        self.client.post(reverse('pos_import'),{'action':'commit','draft_id':d['id'],'confirm':'on'})
        record=POSCostImport.objects.get()
        lines=record.lines
        lines[0]['source_name']='SEBLAK Sayank'
        lines[1]['source_name']='Bakso'
        for line in lines:line.pop('sales_kind',None)
        record.lines=lines;record.save()
        self.assertEqual(record.quantities,{'portions':2,'toppings':1})
        stats=summary(date(2026,10,1),date(2026,10,31))
        self.assertEqual(stats['pos_portions'],2);self.assertEqual(stats['pos_toppings'],1)
        self.assertEqual(stats['orders'],1);self.assertEqual(stats['revenue'],10000);self.assertEqual(stats['cost'],4000)
        self.assertContains(self.client.get(reverse('sale_detail',args=[self.sale.pk])),'2 unit produk utama')
        self.sale.status='void';self.sale.save()
        self.assertEqual(summary(date(2026,10,1),date(2026,10,31))['pos_portions'],0)

    def test_payments_saved_and_old_import_can_be_completed_without_revenue_change(self):
        from unittest.mock import patch
        with patch('operations.tests_pos.HEAD',HEAD+['Metode Pembayaran']):
            rows=[r.copy()+(['Non Tunai'] if i==0 else [None]) for i,r in enumerate(ROWS)]
            raw=fixture(rows)
        def upload_payment():
            return self.client.post(reverse('pos_import'),{'action':'upload','channel':self.sale.channel_id,'complete':'on','file':SimpleUploadedFile('payments.xlsx',raw)})
        upload_payment();d=self.client.session['pos_cost_draft']
        self.assertEqual(d['payments']['qris'],{'orders':1,'amount':'10000'})
        self.client.post(reverse('pos_import'),{'action':'map','draft_id':d['id'],'product_0':self.a.pk,'product_1':self.b.pk})
        self.client.post(reverse('pos_import'),{'action':'commit','draft_id':d['id'],'confirm':'on'})
        record=POSCostImport.objects.get();self.assertEqual(record.payments['qris']['orders'],1)
        self.assertEqual(summary(date(2026,10,1),date(2026,10,31))['pos_payments']['qris']['amount'],10000)
        record.payments={};record.save()
        upload_payment();d=self.client.session['pos_cost_draft'];self.assertEqual(d['stage'],'payment_preview')
        self.assertEqual(self.client.post(reverse('pos_import'),{'action':'payments','draft_id':d['id'],'confirm':'on'}).status_code,302)
        record.refresh_from_db();self.assertEqual(record.payments['qris']['amount'],'10000')
        self.sale.refresh_from_db();self.assertEqual(self.sale.net_revenue,10000);self.assertEqual(self.sale.cost,4000)
        self.assertEqual(Sale.objects.count(),1)

    def test_payment_totals_once_per_receipt_and_reject_unknown_method(self):
        from unittest.mock import patch
        with patch('operations.tests_pos.HEAD',HEAD+['Metode Pembayaran']):
            rows=[['R1','28-10-2026','Test','Seblak A',2,'LUNAS',10000,None,None,'Tunai'],[None,None,None,'Bakso',1,None,None,None,None,None],['R2','28-10-2026','Test','Seblak B',1,'LUNAS',12000,None,None,'Non Tunai']]
            d=parse_pos_xlsx(fixture(rows))
            self.assertEqual(d['payments']['cash'],{'orders':1,'amount':'10000'})
            self.assertEqual(d['payments']['qris'],{'orders':1,'amount':'12000'})
            self.assertEqual(d['orders'],2);self.assertEqual(d['pos_revenue'],'22000')
            rows[0][-1]='Dompet lain'
            with self.assertRaises(ValidationError):parse_pos_xlsx(fixture(rows))

class MixedPOSPaymentTests(TestCase):
    def workbook(self, method):
        from openpyxl import Workbook
        workbook=Workbook();sheet=workbook.active;sheet.title='Riwayat Penjualan'
        sheet.append(HEAD+['Metode Pembayaran'])
        sheet.append(['MIX1','30-10-2026','Test','Menu A',1,'LUNAS',24000,None,None,method])
        stream=io.BytesIO();workbook.save(stream);workbook.close()
        return stream.getvalue()

    def test_mixed_receipt_is_counted_once_without_guessing_split(self):
        draft=parse_pos_xlsx(self.workbook('Tunai, Non Tunai'))
        self.assertEqual(draft['orders'],1)
        self.assertEqual(draft['payments']['mixed'],{'orders':1,'amount':'24000'})
        self.assertEqual(sum(p['orders'] for p in draft['payments'].values()),1)
        self.assertEqual(sum(Decimal(p['amount']) for p in draft['payments'].values()),Decimal('24000'))
        self.assertEqual(draft['payments']['cash']['amount'],'0')

    def test_unknown_payment_still_rejected_and_single_unchanged(self):
        for method in ['Tunai, Tidak dikenal','Tunai,']:
            with self.assertRaises(ValidationError):parse_pos_xlsx(self.workbook(method))
        self.assertEqual(parse_pos_xlsx(self.workbook('Tunai'))['payments']['cash']['amount'],'24000')
