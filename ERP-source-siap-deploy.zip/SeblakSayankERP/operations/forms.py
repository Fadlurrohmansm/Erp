from tenancy.forms import ScopedForm,ScopedModelForm
import uuid
from decimal import Decimal
from django import forms
from django.forms import BaseInlineFormSet, inlineformset_factory, formset_factory, BaseFormSet
from django.utils import timezone
from .models import Ingredient, Product, Recipe, Channel, Expense, BusinessSettings, Sale

class DateForm(ScopedForm):
    date = forms.DateField(label='Tanggal', initial=timezone.localdate, widget=forms.DateInput(attrs={'type': 'date'}, format='%Y-%m-%d'))
    def clean_date(self):
        value = self.cleaned_data['date']
        if value > timezone.localdate():
            raise forms.ValidationError('Tanggal tidak boleh di masa depan.')
        return value

class IngredientForm(ScopedModelForm):
    class Meta:
        model = Ingredient
        fields = ['name', 'category_name', 'unit', 'purchase_unit', 'purchase_factor', 'supplier', 'minimum_stock', 'active']
    def clean_unit(self):
        value = self.cleaned_data['unit']
        if self.instance.pk and (self.instance.movements.exists() or self.instance.recipe_set.exists() or Recipe.objects.filter(substitute=self.instance).exists()) and value != self.instance.unit:
            raise forms.ValidationError('Satuan bahan dengan riwayat tidak dapat diubah. Buat bahan baru untuk satuan berbeda.')
        return value

    def clean(self):
        data = super().clean()
        if bool(data.get('purchase_unit')) != bool(data.get('purchase_factor')):
            raise forms.ValidationError('Isi nama dan konversi satuan pembelian khusus bersama-sama.')
        return data

class ProductForm(ScopedModelForm):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.fields['sales_kind'].required=False
        self.fields['batch_yield'].required = False
        self.fields['recipe_direct_cost'].required = False
    def clean_sales_kind(self):
        return self.cleaned_data.get('sales_kind') or self.instance.sales_kind or 'main'

    def clean_variant_of(self):
        if self.is_bound and self.add_prefix('variant_of') not in self.data:
            return self.instance.variant_of
        parent = self.cleaned_data.get('variant_of')
        if parent and (parent.pk == self.instance.pk or parent.variant_of_id
                       or self.instance.pk and self.instance.variants.exists()):
            raise forms.ValidationError('Pilih menu induk yang bukan varian. Menu yang memiliki varian tetap menjadi induk.')
        return parent

    def clean_batch_yield(self):
        value = self.cleaned_data.get('batch_yield')
        return value if value is not None else self.instance.batch_yield

    def clean_recipe_direct_cost(self):
        value = self.cleaned_data.get('recipe_direct_cost')
        return value if value is not None else self.instance.recipe_direct_cost

    class Meta:
        model = Product
        fields = ['name', 'category', 'sales_kind', 'price', 'manual_cost', 'hpp_shopeefood',
                  'hpp_grabfood', 'hpp_gofood', 'variant_of', 'batch_yield', 'recipe_direct_cost', 'active']

class RecipeForm(ScopedModelForm):
    class Meta:
        model = Recipe
        fields = ['ingredient', 'quantity', 'role', 'waste', 'substitute']
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['ingredient'].help_text = 'Jumlah memakai satuan dasar bahan: gram, ml, atau pcs.'
        self.fields['quantity'].label = 'Takaran bersih per batch'

        self.fields['role'].required = False
        self.fields['waste'].required = False

    def clean_role(self):
        return self.cleaned_data.get('role') or self.instance.role

    def clean_waste(self):
        value = self.cleaned_data.get('waste')
        return value if value is not None else self.instance.waste

    def clean(self):
        data = super().clean()
        ingredient, substitute = data.get('ingredient'), data.get('substitute')
        if ingredient and substitute and (ingredient == substitute or ingredient.unit != substitute.unit):
            self.add_error('substitute', 'Pilih bahan berbeda dengan satuan dasar yang sama.')
        return data

RecipeFormSet = inlineformset_factory(Product, Recipe, form=RecipeForm, extra=1, can_delete=True, max_num=100, validate_max=True)

class PurchaseForm(DateForm):
    token = forms.UUIDField(widget=forms.HiddenInput, initial=uuid.uuid4)
    ingredient = forms.ModelChoiceField(label='Bahan', queryset=Ingredient.objects.all())
    quantity = forms.DecimalField(label='Jumlah masuk (satuan dasar)', min_value=Decimal('.001'), max_digits=12, decimal_places=3)
    total_cost = forms.DecimalField(label='Total biaya pembelian', min_value=Decimal('0'), max_digits=14, decimal_places=2, help_text='Termasuk ongkir terkait bahan. Pembelian dicatat sebagai persediaan, bukan biaya operasional.')
    notes = forms.CharField(label='Pemasok / catatan', max_length=255, required=False)

class CountForm(DateForm):
    token = forms.UUIDField(widget=forms.HiddenInput, initial=uuid.uuid4)
    ingredient = forms.ModelChoiceField(label='Bahan', queryset=Ingredient.objects.all())
    counted = forms.DecimalField(label='Jumlah fisik aktual (satuan dasar)', min_value=0, max_digits=12, decimal_places=3)
    notes = forms.CharField(label='Alasan penyesuaian', max_length=255)

class SaleForm(DateForm):
    token = forms.UUIDField(widget=forms.HiddenInput, initial=uuid.uuid4)
    channel = forms.ModelChoiceField(label='Kanal penjualan', queryset=Channel.objects.all(), empty_label=None)
    payment_method = forms.ChoiceField(label='Metode pembayaran', choices=Sale.PAYMENT_CHOICES)
    notes = forms.CharField(label='Catatan pesanan', max_length=255, required=False)

class SaleRowForm(ScopedForm):
    product = forms.ModelChoiceField(label='Menu', queryset=Product.objects.filter(active=True))
    quantity = forms.IntegerField(label='Porsi', min_value=1, max_value=10000, initial=1)
    unit_price = forms.DecimalField(label='Harga per porsi', min_value=0, max_digits=12, decimal_places=2)

class SaleRows(BaseFormSet):
    def clean(self):
        super().clean()
        if any(self.errors):
            return
        if not any(f.cleaned_data and not f.cleaned_data.get('DELETE') for f in self.forms):
            raise forms.ValidationError('Tambahkan minimal satu menu.')

SaleFormSet = formset_factory(SaleRowForm, formset=SaleRows, extra=1, can_delete=True, max_num=100, validate_max=True)

class ExpenseForm(ScopedModelForm):
    token = forms.UUIDField(widget=forms.HiddenInput, initial=uuid.uuid4)
    class Meta:
        model = Expense
        fields = ['date', 'category', 'description', 'amount']
        widgets = {'date': forms.DateInput(attrs={'type': 'date'}, format='%Y-%m-%d')}
    def clean_date(self):
        value = self.cleaned_data['date']
        if value > timezone.localdate():
            raise forms.ValidationError('Tanggal tidak boleh di masa depan.')
        return value

class BusinessForm(ScopedModelForm):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        for field in ['pos_count_mode','pos_noncash_method']:self.fields[field].required=False

    class Meta:
        model = BusinessSettings
        fields = ['name', 'tagline', 'address', 'phone', 'import_hpp_rate','pos_count_mode','pos_main_keywords','pos_noncash_method']

    def clean(self):
        data=super().clean()
        for field in ['pos_count_mode','pos_noncash_method']:
            data[field]=data.get(field) or getattr(self.instance,field)
        if data.get('pos_count_mode')=='keyword' and not any(x.strip() for x in data.get('pos_main_keywords','').split(',')):
            self.add_error('pos_main_keywords','Isi minimal satu kata kunci atau pilih mode jenis item menu.')
        return data

ChannelFormSet = forms.modelformset_factory(Channel, form=ScopedModelForm, fields=['name', 'voucher_rate', 'commission_rate'], extra=0)

class ReasonForm(ScopedForm):
    reason = forms.CharField(label='Alasan pembatalan', max_length=255, widget=forms.Textarea(attrs={'rows': 3}))


class DailyRecapForm(DateForm):
    token = forms.UUIDField(widget=forms.HiddenInput, initial=uuid.uuid4)
    channel = forms.ModelChoiceField(label='Kanal penjualan', queryset=Channel.objects.all(), empty_label=None)
    order_count = forms.IntegerField(label='Jumlah pesanan', min_value=0)
    manual_portions = forms.IntegerField(
        label='Porsi terjual', min_value=0, max_value=2147483647, required=False,
        help_text='Isi jumlah porsi menu utama pada tanggal rekap. Kosongkan jika belum diketahui.',
    )
    subtotal = forms.DecimalField(label='Omzet bruto (Rp)', min_value=0, max_digits=14, decimal_places=2)
    voucher_amount = forms.DecimalField(label='Subsidi voucher ditanggung usaha (Rp)', min_value=0, max_digits=14, decimal_places=2, initial=0)
    commission_amount = forms.DecimalField(label='Komisi platform (Rp)', min_value=0, max_digits=14, decimal_places=2, initial=0)
    other_fees = forms.DecimalField(label='Biaya lain / admin / QRIS (Rp)', min_value=0, max_digits=14, decimal_places=2, initial=0)
    manual_cash = forms.DecimalField(label='Pembayaran tunai (Rp)', min_value=0, max_digits=14, decimal_places=2, required=False,
                                     help_text='Opsional, khusus kanal Offline POS.')
    manual_qris = forms.DecimalField(label='Pembayaran QRIS (Rp)', min_value=0, max_digits=14, decimal_places=2, required=False,
                                     help_text='Opsional, khusus Offline POS. Total tunai dan QRIS harus sama dengan omzet setelah voucher, sebelum biaya admin.')
    cost = forms.DecimalField(label='Total HPP penjualan (Rp)', min_value=0, max_digits=14, decimal_places=2, help_text='Total biaya bahan dan kemasan terjual, bukan pembelian bahan. Wajib diisi agar laba benar.')
    notes = forms.CharField(label='Referensi / catatan', max_length=255, required=False)

    def clean(self):
        data = super().clean()
        keys = ['subtotal', 'voucher_amount', 'commission_amount', 'other_fees']
        if all(k in data for k in keys):
            if sum(data[k] for k in keys[1:]) > data['subtotal']:
                raise forms.ValidationError('Total potongan tidak boleh melebihi omzet bruto.')
        if data.get('subtotal', 0) > 0 and data.get('order_count') == 0:
            self.add_error('order_count', 'Isi jumlah pesanan untuk omzet yang tercatat.')
        cash, qris = data.get('manual_cash'), data.get('manual_qris')
        channel = data.get('channel')
        if (cash is not None or qris is not None) and channel:
            if channel.name.casefold() != 'offline':
                raise forms.ValidationError('Rincian tunai dan QRIS hanya untuk kanal Offline.')
            if all(key in data for key in ['subtotal', 'voucher_amount', 'manual_cash', 'manual_qris']):
                collected = data['subtotal'] - data['voucher_amount']
                if (cash or 0) + (qris or 0) != collected:
                    raise forms.ValidationError('Total tunai dan QRIS harus sama dengan omzet bruto dikurangi voucher, sebelum biaya admin.')
                data['manual_cash'] = cash or Decimal(0)
                data['manual_qris'] = qris or Decimal(0)
        return data


class CSVUploadForm(ScopedForm):
    file = forms.FileField(label='File CSV atau PDF settlement Grab', widget=forms.ClearableFileInput(attrs={'accept': '.csv,.pdf'}))
    def clean_file(self):
        value = self.cleaned_data['file']
        if not value.name.lower().endswith(('.csv', '.pdf')) or value.size > 2 * 1024 * 1024:
            raise forms.ValidationError('Pilih file .csv atau .pdf maksimal 2 MB.')
        return value

class ImportCostsForm(ScopedForm):
    def __init__(self, *args, rows, rate=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.rows, self.rate = rows, Decimal(rate) if rate is not None else None
        if self.rate is not None:
            self.fields['auto_hpp'] = forms.BooleanField(label=f'Hitung estimasi HPP otomatis: {self.rate}% dari omzet bruto', initial=True, required=False)
        for i, row in enumerate(rows):
            self.fields[f'cost_{i}'] = forms.DecimalField(label=f"HPP manual {row['date']} · {row['channel']} (Rp)", required=False, min_value=0, max_digits=14, decimal_places=2, help_text='Boleh kosong jika estimasi otomatis dicentang.' if rate is not None else 'Wajib diisi, atau atur persentase HPP impor sekali di Pengaturan usaha.')
        self.fields['complete'] = forms.BooleanField(label='Saya sudah memeriksa total dan kelengkapan laporan serta memahami HPP otomatis adalah estimasi.')

    def clean(self):
        data = super().clean()
        for i, row in enumerate(self.rows):
            key = f'cost_{i}'
            if data.get('auto_hpp') and self.rate is not None:
                from .services import money
                data[key] = money(Decimal(row['subtotal']) * self.rate / 100)
            elif data.get(key) is None and key not in self.errors:
                self.add_error(key, 'Isi HPP atau aktifkan estimasi otomatis setelah mengatur persentasenya.')
        return data


class POSUploadForm(ScopedForm):
    file = forms.FileField(label='XLSX ekspor Riwayat Penjualan POS',widget=forms.ClearableFileInput(attrs={'accept':'.xlsx'}))
    channel = forms.ModelChoiceField(label='Kanal yang dicakup seluruh isi file ini',queryset=Channel.objects.all(),help_text='Tunai/Non Tunai bukan penanda platform. Ekspor satu kanal saja; jangan gabungkan Offline dan aplikasi dalam satu file.')
    complete = forms.BooleanField(label='File ini mencakup seluruh menu terjual untuk satu hari dan satu kanal yang dipilih, bukan campuran beberapa kanal.')
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.fields['channel'].initial=Channel.objects.filter(name='Offline').values_list('pk',flat=True).first()
    def clean_file(self):
        value=self.cleaned_data['file']
        if not value.name.lower().endswith('.xlsx') or value.size>5*1024*1024:raise forms.ValidationError('Pilih XLSX maksimal 5 MB.')
        return value

class POSMappingForm(ScopedForm):
    def __init__(self,*args,items,**kwargs):
        from .models import POSProductAlias
        super().__init__(*args,**kwargs)
        aliases={x.name:x.product_id for x in POSProductAlias.objects.all()}
        products=list(Product.objects.filter(active=True))
        for i,item in enumerate(items):
            exact=next((p.pk for p in products if p.name.casefold()==item['name'].casefold()),None)
            self.fields[f'product_{i}']=forms.ModelChoiceField(label=f"{item['name']} · {item['quantity']} terjual",queryset=Product.objects.filter(active=True),initial=aliases.get(item['name'].casefold(),exact),empty_label='Pilih menu/resep ERP')


class BulkProductRows(BaseFormSet):
    def clean(self):
        super().clean()
        if any(self.errors):return
        names=set()
        existing={n.strip().casefold() for n in Product.objects.values_list('name',flat=True)}
        for form in self.forms:
            if not form.cleaned_data or form.cleaned_data.get('DELETE'):continue
            name=form.cleaned_data['name'].strip().casefold()
            if name in names:raise forms.ValidationError('Ada nama menu berulang dalam daftar. Gunakan nama yang berbeda.')
            if name in existing:raise forms.ValidationError('Nama menu sudah terdaftar. Gunakan Edit menu untuk mengubahnya; daftar belum disimpan.')
            names.add(name)

BulkProductFormSet=formset_factory(ProductForm,formset=BulkProductRows,extra=4,min_num=1,validate_min=True,max_num=100,validate_max=True,can_delete=True)
