from decimal import Decimal


def pos_quantities(lines):
    # Old snapshots without item kind retain their original Seblak counting rule.
    portions=toppings=others=0
    for line in lines:
        name=str(line.get('source_name',line.get('name','')))
        kind=line.get('sales_kind') or ('main' if 'seblak' in name.casefold() else 'addon')
        quantity=int(Decimal(str(line['quantity'])))
        if kind=='main':portions+=quantity
        elif kind=='addon':toppings+=quantity
        else:others+=quantity
    result={'portions':portions,'toppings':toppings}
    if others:result['others']=others
    return result


def classify(name,product,config):
    if config is None:
        return 'main' if 'seblak' in name.casefold() else 'addon'
    if config.pos_count_mode=='keyword':
        words=[w.strip().casefold() for w in config.pos_main_keywords.split(',') if w.strip()]
        return 'main' if any(w in name.casefold() for w in words) else 'addon'
    return product.sales_kind if product else 'other'
