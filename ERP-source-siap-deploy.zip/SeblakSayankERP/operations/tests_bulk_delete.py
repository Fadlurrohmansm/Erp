import json
from django.test import TestCase
from django.contrib.auth import get_user_model
from django.urls import reverse
from tenancy.models import Branch
from .models import Product,POSProductAlias,Recipe,Ingredient

class BulkDeleteTests(TestCase):
    def setUp(self):
        self.client.force_login(get_user_model().objects.create_user('bulkdelete',password='testing'))
        self.a=Product.objects.create(name='Unused',price=1000)
        self.b=Product.objects.create(name='Used POS',price=2000)
        POSProductAlias.objects.create(name='used',product=self.b)
        self.ingredient=Ingredient.objects.create(name='Bahan bulk',stock=25)
        Recipe.objects.create(product=self.a,ingredient=self.ingredient,quantity=1)
    def test_preview_never_deletes_then_confirm_deletes_unused_archives_used(self):
        payload=json.dumps([str(self.a.pk),str(self.b.pk)])
        response=self.client.post(reverse('product_bulk_delete'),{'selected_all':payload,'preview':'on'})
        self.assertContains(response,'Hapus 2 menu');self.assertTrue(Product.objects.filter(pk=self.a.pk).exists())
        self.assertContains(response,'name="selected_all"')
        response=self.client.post(reverse('product_bulk_delete'),{'selected_all':payload,'confirm':'on'})
        self.assertEqual(response.status_code,302);self.assertFalse(Product.objects.filter(pk=self.a.pk).exists())
        self.b.refresh_from_db();self.assertFalse(self.b.active);self.assertEqual(POSProductAlias.objects.count(),1)
        self.ingredient.refresh_from_db();self.assertEqual(self.ingredient.stock,25)
    def test_missing_confirmation_and_foreign_ids_cannot_delete(self):
        self.client.post(reverse('product_bulk_delete'),{'selected_all':json.dumps([str(self.a.pk)])})
        self.assertTrue(Product.objects.filter(pk=self.a.pk).exists())
        other=Product.objects.create(branch=Branch.objects.create(name='Other'),name='Foreign',price=1)
        response=self.client.post(reverse('product_bulk_delete'),{'selected_all':json.dumps([str(other.pk)]),'confirm':'on'})
        self.assertEqual(response.status_code,403);self.assertTrue(Product.objects.filter(pk=other.pk).exists())
    def test_bad_payload_and_post_only(self):
        for value in ['[]','{}','bad']:
            response=self.client.post(reverse('product_bulk_delete'),{'selected_all':value,'confirm':'on'})
            self.assertEqual(response.status_code,302)
        self.assertTrue(Product.objects.filter(pk=self.a.pk).exists())
        self.assertEqual(self.client.get(reverse('product_bulk_delete')).status_code,405)
