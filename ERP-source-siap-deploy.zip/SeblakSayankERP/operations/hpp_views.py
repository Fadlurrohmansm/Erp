import uuid
from collections import Counter
from datetime import timedelta
from decimal import Decimal

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.db import IntegrityError, OperationalError, transaction
from django.db.models import Prefetch, Sum
from django.forms import formset_factory
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from .forms import ReasonForm
from .hpp import (
    CostBook, cancel_purchase, channel_rules, policy_for, produce,
    profitability, purchase, recommend, save_snapshot,
)
from .hpp_forms import (
    AnalyticsFilter, PolicyForm, ProductionHeader, ProductionRow,
    PurchaseHeader, PurchaseRow, QuoteForm, RuleForm,
)
from .models import (
    Channel, HPPChannelRule, HPPProduction, HPPPurchase, HPPRecipeVersion,
    HPPSnapshot, Product, StockMovement, ZERO,
)

PurchaseRows = formset_factory(PurchaseRow, extra=1, min_num=1, validate_min=True, max_num=30, validate_max=True)
ProductionRows = formset_factory(ProductionRow, extra=1, min_num=1, validate_min=True, max_num=30, validate_max=True)


def error(request, exc):
    detail = ' '.join(exc.messages) if isinstance(exc, ValidationError) else 'Data berubah atau sedang dipakai. Muat ulang halaman dan coba lagi.'
    messages.error(request, detail)


@login_required
def dashboard(request):
    today = timezone.localdate()
    policy = policy_for(request.branch.pk)
    filters = AnalyticsFilter(request.GET or None)
    data = filters.cleaned_data if filters.is_valid() else {}
    start = today - timedelta(days=data.get('days', 30) - 1)
    menus = Product.objects.filter(active=True).prefetch_related('recipes', Prefetch(
        'hpp_versions', queryset=HPPRecipeVersion.objects.order_by('-effective_date', '-pk'), to_attr='cost_versions',
    ))
    if data.get('product'):
        menus = menus.filter(pk=data['product'].pk)
    if data.get('category'):
        menus = menus.filter(category=data['category'])
    book = CostBook(request.branch.pk, today, policy.method, policy.window)
    snapshots = HPPSnapshot.objects.filter(product__in=menus, reference_date__range=(start, today))
    last_by_menu = {}
    for item in snapshots.order_by('-reference_date', '-pk').iterator():
        last_by_menu.setdefault(item.product_id, item)
    rules = HPPChannelRule.objects.filter(product__in=menus).select_related('channel')
    rule_map = {(rule.product_id, rule.channel_id): rule for rule in rules}
    channels = list(Channel.objects.all())
    rows, alerts, contributions = [], [], Counter()
    measurements = {}
    for menu in menus:
        quote = book.quote(menu)
        if quote['total'] is None:
            rows.append({'menu': menu, 'missing': quote['missing']})
            continue
        measurements[menu.pk] = quote
        previous = last_by_menu.get(menu.pk)
        alerts_for_menu = set()
        for rule in channel_rules(menu, channels=channels, configured=rule_map):
            if data.get('channel') and rule.channel_id != data['channel'].pk:
                continue
            row = profitability(quote['total'], rule)
            ceiling = max(row['price'], row['hpp'])
            row.update(menu=menu, cost_bar=round(row['hpp'] / ceiling * 100) if ceiling else 0,
                       price_bar=round(row['price'] / ceiling * 100) if ceiling else 0)
            rows.append(row)
            if row['food'] is not None and row['food'] > policy.target_food:
                alerts_for_menu.add(f"{row['channel']}: food cost melewati target")
            if row['contribution'] < 0:
                alerts_for_menu.add(f"{row['channel']}: kontribusi negatif")
            if previous and row['margin'] is not None:
                old = next((saved for saved in previous.data['channels'] if saved['channel_id'] == rule.channel_id), None)
                if old and old['margin'] is not None and row['margin'] < Decimal(old['margin']):
                    alerts_for_menu.add(f"{row['channel']}: margin turun")
        if previous and quote['total'] > Decimal(previous.data['quote']['total']):
            alerts_for_menu.add('HPP meningkat dibanding snapshot terakhir')
        if alerts_for_menu:
            alerts.append((menu.name, sorted(alerts_for_menu)))
        for line in quote['lines']:
            contributions[line['name']] += line['cost']
    measured = [row for row in rows if row.get('margin') is not None]
    top = contributions.most_common(10)
    cost_peak = top[0][1] if top else ZERO
    history_rows = list(snapshots.order_by('-reference_date', '-pk')[:30])
    history_peak = max((Decimal(row.data['quote']['total']) for row in history_rows), default=ZERO)
    price_rows = [book.ingredient_stats(item) for item in book.ingredients.values() if item.active]
    return render(request, 'operations/hpp/dashboard.html', {
        'filters': filters, 'rows': rows, 'policy': policy, 'alerts': alerts,
        'avg_cost': sum((q['total'] for q in measurements.values()), ZERO) / len(measurements) if measurements else None,
        'avg_food': sum((r['food'] for r in measured), ZERO) / len(measured) if measured else None,
        'material_total': sum((q['ingredients'] for q in measurements.values()), ZERO),
        'significant': sum(r['change'] is not None and r['change'] >= policy.warning for r in price_rows),
        'price_alerts': [row for row in price_rows if row['change'] is not None and row['change'] >= policy.warning],
        'best': max(measured, key=lambda r: r['margin'], default=None),
        'worst': min(measured, key=lambda r: r['margin'], default=None),
        'top': [{'name': name, 'value': value, 'percent': round(value / cost_peak * 100) if cost_peak else 0}
                for name, value in top],
        'high_food': sorted(measured, key=lambda r: r['food'], reverse=True)[:10],
        'history': [{'snapshot': row, 'percent': round(Decimal(row.data['quote']['total']) / history_peak * 100) if history_peak else 0}
                    for row in reversed(history_rows)],
        'variance': usage_variance(start, today) if data.get('variance') else None,
    })


def usage_variance(start, end):
    ledger = StockMovement.objects.filter(date__range=(start, end), kind__in=['sale', 'reversal', 'count'])
    ledger = ledger.values('ingredient__name', 'ingredient__unit', 'kind').annotate(total=Sum('quantity'))
    rows = {}
    for item in ledger:
        key = (item['ingredient__name'], item['ingredient__unit'])
        row = rows.setdefault(key, {'name': key[0], 'unit': key[1], 'theory': ZERO, 'delta': ZERO, 'counted': False})
        if item['kind'] == 'count':
            row['delta'] -= item['total']
            row['counted'] = True
        else:
            row['theory'] -= item['total']
    for row in rows.values():
        row['actual'] = row['theory'] + row['delta'] if row['counted'] else None
    return sorted(rows.values(), key=lambda r: r['name'])


@login_required
def prices(request):
    today = timezone.localdate()
    policy = policy_for(request.branch.pk)
    filters = AnalyticsFilter(request.GET or None)
    data = filters.cleaned_data if filters.is_valid() else {}
    start = today - timedelta(days=data.get('days', 30) - 1)
    book = CostBook(request.branch.pk, today, 'weighted', policy.window)
    query = request.GET.get('q', '').strip().casefold()
    rows = [book.ingredient_stats(item) for item in book.ingredients.values() if query in item.name.casefold()]
    for row in rows:
        change = row['change']
        row['status'] = 'Belum cukup data'
        if change is not None:
            if change >= policy.critical:
                row['status'] = 'Kritis'
            elif change >= policy.warning:
                row['status'] = 'Kenaikan signifikan'
            else:
                row['status'] = 'Naik' if change > 0 else ('Turun' if change < 0 else 'Stabil')
        row['period_purchases'] = [item for item in row['purchases'] if item.date >= start][:30]
        row['series'] = [
            {'date': entry.date, 'price': entry.value / entry.quantity,
             'scale': round(entry.value / entry.quantity / row['high'] * 100)}
            for entry in reversed(row['period_purchases'])
        ]
    return render(request, 'operations/hpp/prices.html', {'rows': rows, 'q': query, 'days': data.get('days', 30), 'policy': policy})


@login_required
def purchases(request):
    form = PurchaseHeader(request.POST or None)
    rows = PurchaseRows(request.POST or None, prefix='hpp-purchase')
    if request.method == 'POST' and form.is_valid() and rows.is_valid():
        try:
            with transaction.atomic():
                header = form.cleaned_data.copy()
                token = header.pop('token')
                entries = [row for row in rows.cleaned_data if row]
                # Stable lock order and deterministic tokens make retries safe.
                for i, row in sorted(enumerate(entries), key=lambda pair: pair[1]['ingredient'].pk):
                    row = {**row, 'discount': row['discount'] or ZERO, 'freight': row['freight'] or ZERO}
                    purchase(user=request.user, token=uuid.uuid5(token, str(i)), **header, **row)
            messages.success(request, 'Pembelian, harga dan stok tersimpan.')
            return redirect('hpp_purchases')
        except (ValidationError, IntegrityError, OperationalError) as exc:
            error(request, exc)
    ledger = StockMovement.objects.filter(kind='purchase').select_related('ingredient', 'purchase_detail').order_by('-date', '-pk')
    return render(request, 'operations/hpp/purchases.html', {'form': form, 'rows': rows, 'ledger': ledger[:80]})


@login_required
@require_POST
def purchase_cancel(request, pk):
    detail = get_object_or_404(HPPPurchase.objects.select_related('movement'), pk=pk)
    form = ReasonForm(request.POST)
    if form.is_valid():
        try:
            cancel_purchase(detail, user=request.user, reason=form.cleaned_data['reason'])
            messages.success(request, 'Pembelian dibatalkan melalui mutasi koreksi.')
        except (ValidationError, IntegrityError, OperationalError) as exc:
            error(request, exc)
    else:
        messages.error(request, 'Isi alasan pembatalan, maksimal 255 karakter.')
    return redirect('hpp_purchases')


@login_required
def production(request):
    form = ProductionHeader(request.POST or None)
    rows = ProductionRows(request.POST or None, prefix='hpp-production')
    if request.method == 'POST' and form.is_valid() and rows.is_valid():
        inputs = Counter()
        for row in rows.cleaned_data:
            if row:
                inputs[row['ingredient'].pk] += row['quantity']
        data = form.cleaned_data
        try:
            produce(output=data['output'], quantity=data['quantity'], inputs=inputs,
                    direct_cost=data['direct_cost'] or ZERO, day=data['date'], user=request.user,
                    token=data['token'], notes=data['notes'])
            messages.success(request, 'Batch dicatat. Stok bahan dipakai dan hasil bersih masuk persediaan.')
            return redirect('hpp_production')
        except (ValidationError, IntegrityError, OperationalError) as exc:
            error(request, exc)
    batches = HPPProduction.objects.select_related('output__ingredient').order_by('-pk')[:50]
    return render(request, 'operations/hpp/production.html', {'form': form, 'rows': rows, 'batches': batches})


@login_required
def calculator(request):
    policy = policy_for(request.branch.pk)
    form = QuoteForm(request.POST or None, initial={
        'date': timezone.localdate(), 'method': policy.method, 'window': policy.window,
        'food': policy.target_food, 'margin': policy.target_margin,
    })
    quote, comparisons, simulation, product = None, [], None, None
    if request.method == 'POST' and form.is_valid():
        data = form.cleaned_data
        product = data['product']
        book = CostBook(request.branch.pk, data['date'], data['method'], data['window'])
        quote = book.quote(product)
        for rule in channel_rules(product):
            row = profitability(quote['total'], rule)
            row['recommended'] = recommend(quote['total'], rule, data['food'], data['margin'], policy.rounding)
            comparisons.append(row)
            if rule.channel_id == getattr(data['channel'], 'pk', None) and data['price'] is not None:
                simulation = profitability(quote['total'], rule, data['price'])
        if request.POST.get('action') == 'save':
            if not data['reason']:
                form.add_error('reason', 'Isi alasan agar perubahan historis dapat diaudit.')
            else:
                try:
                    save_snapshot(product, book, request.user, data['token'], data['reason'])
                    messages.success(request, 'Snapshot baru tersimpan di Riwayat HPP.')
                    return redirect('hpp_history')
                except (ValidationError, IntegrityError, OperationalError) as exc:
                    error(request, exc)
    return render(request, 'operations/hpp/calculator.html', {
        'form': form, 'quote': quote, 'product': product, 'rows': comparisons,
        'simulation': simulation, 'simulation_rows': [simulation] if simulation else [],
    })


@login_required
def history(request):
    from django.core.paginator import Paginator
    rows = HPPSnapshot.objects.select_related('product', 'version', 'created_by').order_by('-reference_date', '-pk')
    return render(request, 'operations/hpp/history.html', {'page': Paginator(rows, 25).get_page(request.GET.get('page'))})


@login_required
def snapshot_detail(request, pk):
    snapshot = get_object_or_404(HPPSnapshot.objects.select_related('version', 'created_by'), pk=pk)
    return render(request, 'operations/hpp/snapshot.html', {'snapshot': snapshot})


@login_required
def settings(request):
    form = PolicyForm(request.POST or None, instance=policy_for(request.branch.pk))
    if request.method == 'POST' and form.is_valid():
        try:
            form.save()
            messages.success(request, 'Pengaturan HPP cabang disimpan.')
            return redirect('hpp_settings')
        except IntegrityError as exc:
            error(request, exc)
    return render(request, 'operations/hpp/settings.html', {'form': form})


@login_required
def channel_rule(request, product_id, channel_id):
    product, channel = get_object_or_404(Product, pk=product_id), get_object_or_404(Channel, pk=channel_id)
    rule = HPPChannelRule.objects.filter(product=product, channel=channel).first() or HPPChannelRule(
        branch_id=request.branch.pk, product=product, channel=channel, price=product.price,
        merchant_rate=channel.voucher_rate, commission_rate=channel.commission_rate,
    )
    form = RuleForm(request.POST or None, instance=rule)
    if request.method == 'POST' and form.is_valid():
        try:
            form.save()
            messages.success(request, 'Aturan simulasi kanal disimpan.')
            return redirect('hpp_calculator')
        except IntegrityError as exc:
            error(request, exc)
    return render(request, 'operations/hpp/settings.html', {'form': form, 'product': product, 'channel': channel})
