from .tests_pos import fixture
from .pos_import import parse_pos_xlsx
from .pos_quantities import pos_quantities
from django.test import TestCase

class POSQuantityTests(TestCase):
    def setUp(self):
        from .models import BusinessSettings
        BusinessSettings.objects.update_or_create(pk=1,defaults={'pos_count_mode':'keyword','pos_main_keywords':'seblak'})

    def test_case_insensitive_and_toppings(self):
        self.assertEqual(pos_quantities([{'name':'SEBLAK Sayank','quantity':'2'},{'name':'Bakso','quantity':'3'},{'name':'Paket seblak','quantity':'1'}]),{'portions':3,'toppings':3})
    def test_parse_separates_receipts_and_portions(self):
        rows=[['R1','28-10-2026','Test','Seblak Sayank',2,'LUNAS',10000,None,None],[None,None,None,'Bakso',3,None,None,None,None],[None,None,None,'Total',5,None,10000,'-',0]]
        draft=parse_pos_xlsx(fixture(rows))
        self.assertEqual(draft['orders'],1);self.assertEqual(draft['portions'],2);self.assertEqual(draft['toppings'],3)
        self.assertEqual(draft['pos_revenue'],'10000')
