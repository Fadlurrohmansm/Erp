"""Posting transaksi atomik; riwayat dibatalkan dengan reversal, bukan dihapus."""
from collections import defaultdict
from decimal import Decimal, ROUND_HALF_UP
from django.core.exceptions import ValidationError
from django.db import transaction
from django.db.models import F
from .models import Ingredient, Product, Sale, SaleItem, StockMovement, ZERO


def money(value):
    return Decimal(value).quantize(Decimal('.01'), rounding=ROUND_HALF_UP)


def lock_stock(pk):
    # UPDATE memperoleh write lock juga pada SQLite (select_for_update diabaikan SQLite).
    Ingredient.objects.filter(pk=pk).update(stock=F('stock'))
    return Ingredient.objects.select_for_update().get(pk=pk)


def movement(ingredient, quantity, value, *, kind, user, date, notes='', sale=None, token=None):
    quantity = Decimal(quantity).quantize(Decimal(".001"), rounding=ROUND_HALF_UP)
    value = Decimal(value).quantize(Decimal(".000001"), rounding=ROUND_HALF_UP)
    stock = ingredient.stock + quantity
    if stock < 0:
        raise ValidationError(f'Stok {ingredient.name} tidak cukup. Tersedia {ingredient.stock} {ingredient.unit}.')
    valuation = ingredient.stock * ingredient.average_cost + value
    if stock == 0:
        average = ZERO
    else:
        average = max(ZERO, valuation / stock).quantize(Decimal('.000001'), rounding=ROUND_HALF_UP)
    ingredient.stock = stock
    ingredient.average_cost = average
    ingredient.full_clean()
    ingredient.save(update_fields=['stock', 'average_cost'])
    entry = StockMovement(ingredient=ingredient, quantity=quantity, value=value, stock_after=stock, average_after=average, kind=kind, created_by=user, date=date, notes=notes, sale=sale, token=token)
    entry.full_clean()
    entry.save()
    return entry


@transaction.atomic
def receive_stock(*, ingredient, quantity, total_cost, user, date, notes='', token=None):
    if token and StockMovement.objects.filter(token=token).exists():
        return StockMovement.objects.get(token=token)
    if quantity <= 0 or total_cost < 0:
        raise ValidationError('Jumlah harus positif dan biaya tidak boleh negatif.')
    ingredient = lock_stock(ingredient.pk)
    return movement(ingredient, quantity, total_cost, kind='purchase', user=user, date=date, notes=notes, token=token)


@transaction.atomic
def count_stock(*, ingredient, counted, user, date, notes='', token=None):
    if token and StockMovement.objects.filter(token=token).exists():
        return StockMovement.objects.get(token=token)
    if counted < 0:
        raise ValidationError('Stok fisik tidak boleh negatif.')
    ingredient = lock_stock(ingredient.pk)
    delta = counted - ingredient.stock
    if not delta:
        raise ValidationError('Stok fisik sama dengan stok sistem; tidak ada penyesuaian.')
    return movement(ingredient, delta, delta * ingredient.average_cost, kind='count', user=user, date=date, notes=notes, token=token)


@transaction.atomic
def post_sale(*, header, rows, user):
    existing = Sale.objects.filter(token=header['token']).first()
    if existing:
        return existing
    if not rows:
        raise ValidationError('Tambahkan minimal satu menu.')
    channel = header['channel']
    sale = Sale.objects.create(token=header['token'], date=header['date'], channel=channel, channel_name=channel.name, payment_method=header['payment_method'], voucher_rate=channel.voucher_rate, commission_rate=channel.commission_rate, notes=header.get('notes', ''), created_by=user)
    from .hpp import CostBook, net_quantity, policy_for, sale_quote
    policy = policy_for(channel.branch_id)
    book = CostBook(channel.branch_id, header['date'], policy.method, policy.window) if policy.apply_to_sales else None
    needs = defaultdict(lambda: ZERO)
    prepared = []
    subtotal = ZERO
    for row in rows:
        product = Product.objects.filter(pk=row['product'].pk, active=True).first()
        if product is None:
            raise ValidationError('Menu sudah tidak aktif. Muat ulang halaman penjualan.')
        qty, price = row['quantity'], row['unit_price']
        if qty <= 0 or price < 0:
            raise ValidationError('Jumlah/harga menu tidak valid.')
        recipes = list(product.recipes.select_related('ingredient'))
        override = product.manual_channel_cost(channel.name)
        usage = [(recipe.ingredient_id, net_quantity(recipe.quantity, recipe.waste, product.batch_yield))
                 for recipe in recipes]
        if book is not None and override is None:
            override, quote = sale_quote(product, channel.name, book)
            usage = [(line['ingredient_id'], line['quantity']) for line in quote['lines']]
        for ingredient_id, quantity in usage:
            needs[ingredient_id] += quantity * qty
        prepared.append((product, qty, price, usage, override))
        subtotal += qty * price
    locked = {pk: lock_stock(pk) for pk in sorted(needs)}
    cost = ZERO
    for product, qty, price, usage, override in prepared:
        if override is not None:
            unit_cost = money(override)
        elif usage:
            unit_cost = money(sum((quantity * locked[pk].average_cost for pk, quantity in usage), ZERO)
                              + Decimal(product.recipe_direct_cost) / product.batch_yield)
        else:
            unit_cost = product.manual_cost
        cost += unit_cost * qty
        SaleItem.objects.create(sale=sale, product=product, product_name=product.name, quantity=qty, unit_price=price, unit_cost=unit_cost)
    for pk, qty in needs.items():
        ingredient = locked[pk]
        movement(ingredient, -qty, -qty * ingredient.average_cost, kind='sale', user=user, date=sale.date, sale=sale)
    sale.subtotal = money(subtotal)
    sale.voucher_amount = money(subtotal * sale.voucher_rate / 100)
    sale.commission_amount = money((subtotal - sale.voucher_amount) * sale.commission_rate / 100)
    sale.net_revenue = sale.subtotal - sale.voucher_amount - sale.commission_amount
    sale.cost = money(cost)
    sale.full_clean()
    sale.save()
    return sale


@transaction.atomic
def void_sale(sale, *, user, reason):
    if not reason.strip():
        raise ValidationError('Isi alasan pembatalan.')
    # Conditional update mencegah dua reversal pada pengiriman ganda.
    if not Sale.objects.filter(pk=sale.pk, status='posted').update(status='void', void_reason=reason):
        return
    for original in sale.movements.filter(kind='sale').order_by('ingredient_id'):
        ingredient = lock_stock(original.ingredient_id)
        movement(ingredient, -original.quantity, -original.value, kind='reversal', user=user, date=sale.date, sale=sale, notes=reason)


@transaction.atomic
def post_daily_recap(*, data, user):
    existing = Sale.objects.filter(token=data['token']).first()
    if existing:
        return existing
    channel = data['channel']
    if Sale.objects.filter(date=data['date'], channel=channel, status='posted').exists():
        raise ValidationError('Tanggal dan kanal ini sudah memiliki penjualan. Batalkan catatan yang salah sebelum memasukkan rekap pengganti; jangan menghitung penjualan POS dua kali.')
    fees = sum((data[k] for k in ['voucher_amount', 'commission_amount', 'other_fees']), ZERO)
    if fees > data['subtotal']:
        raise ValidationError('Total potongan melebihi omzet bruto.')
    sale = Sale(
        **{k: data[k] for k in ['token', 'date', 'order_count', 'subtotal', 'voucher_amount', 'commission_amount', 'other_fees', 'cost']},
        channel=channel, channel_name=channel.name, is_recap=True,
        payment_method='cash' if channel.name.lower() == 'offline' else 'platform',
        net_revenue=money(data['subtotal'] - fees), notes=data.get('notes', ''), created_by=user,
        manual_cash=data.get('manual_cash'), manual_qris=data.get('manual_qris'),
        manual_portions=data.get('manual_portions'),
    )
    sale.full_clean()
    sale.save()
    return sale
