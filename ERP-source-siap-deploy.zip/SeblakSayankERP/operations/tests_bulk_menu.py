from decimal import Decimal
from datetime import date
from django.test import TestCase
from django.contrib.auth import get_user_model
from django.urls import reverse
from .models import Product,Channel,Sale
class BulkMenuTests(TestCase):
    def setUp(self):
        self.u=get_user_model().objects.create_user('bulktester',password='testing');self.client.force_login(self.u)
    def data(self):
        d={'menus-TOTAL_FORMS':2,'menus-INITIAL_FORMS':0}
        for i,name in enumerate(['Seblak Baru','Ceker Baru']):
            d.update({f'menus-{i}-name':name,f'menus-{i}-price':'12000',f'menus-{i}-manual_cost':'5000',f'menus-{i}-hpp_shopeefood':'5500',f'menus-{i}-hpp_grabfood':'6000',f'menus-{i}-hpp_gofood':'5200',f'menus-{i}-active':'on'})
        return d
    def test_add_multiple_and_values(self):
        self.assertEqual(self.client.post(reverse('product_bulk_create'),self.data()).status_code,302)
        self.assertEqual(Product.objects.count(),2);self.assertEqual(Product.objects.get(name='Seblak Baru').hpp_grabfood,6000)
        self.assertContains(self.client.get(reverse('product_list')),'Tambah banyak menu')
    def test_invalid_row_rolls_back_all_and_duplicates(self):
        for override in [{'menus-1-price':'-1'},{'menus-1-name':'seblak baru'},{'menus-0-name':''}]:
            self.assertEqual(self.client.post(reverse('product_bulk_create'),{**self.data(),**override}).status_code,200)
            self.assertEqual(Product.objects.count(),0)
        Product.objects.create(name='Seblak Baru')
        self.client.post(reverse('product_bulk_create'),self.data());self.assertEqual(Product.objects.count(),1)
    def test_deleted_row_and_auth(self):
        d=self.data();d['menus-1-DELETE']='on'
        self.assertEqual(self.client.post(reverse('product_bulk_create'),d).status_code,302);self.assertEqual(Product.objects.count(),1)
        self.client.logout();self.assertEqual(self.client.get(reverse('product_bulk_create')).status_code,302)
    def test_net_revenue_above_gross_summary(self):
        Sale.objects.create(channel=Channel.objects.get(name='Offline'),channel_name='Offline',date=date(2026,10,28),created_by=self.u,subtotal=100000,net_revenue=Decimal('75432.60'))
        response=self.client.get(reverse('dashboard')+'?day=2026-10-28')
        self.assertContains(response,'Rp75.432,60')
        html=response.content.decode();self.assertLess(html.index('Total pendapatan bersih tanggal terpilih'),html.index('Total omzet tanggal terpilih'))
