from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST
from django.db import transaction
from django.shortcuts import get_object_or_404,redirect,render
from django.contrib import messages
from .models import Branch
from .forms import BranchForm

def select_branch(request,branch):
    request.session['branch_id']=branch.pk
    for key in ['csv_import_draft','pos_cost_draft']:request.session.pop(key,None)

@login_required
@require_POST
def branch_switch(request):
    selected=request.POST.get('branch_id','')
    if not selected.isdigit():
        messages.error(request,'Pilih cabang yang valid.');return redirect('dashboard')
    branch=get_object_or_404(Branch,pk=int(selected))
    select_branch(request,branch)
    return redirect('dashboard')

@login_required
def branch_create(request):
    form=BranchForm(request.POST or None)
    if request.method=='POST' and form.is_valid():
        from operations.models import Channel
        with transaction.atomic():
            branch=form.save()
            for name in ['Offline','ShopeeFood','GrabFood','GoFood']:Channel.objects.create(branch=branch,name=name)
        select_branch(request,branch)
        messages.success(request,'Cabang ditambahkan dan dipilih. Lengkapi menu, bahan dan karyawan cabang ini.')
        return redirect('dashboard')
    return render(request,'core/generic_form.html',{'form':form,'page_title':'Tambah cabang','back_url':'/','description':'Masukkan nama cabang. Data operasional cabang baru dimulai kosong. Identitas usaha dan layout slip tetap digunakan bersama.'})

@login_required
def branch_edit(request,branch_id):
    branch=get_object_or_404(Branch,pk=branch_id)
    form=BranchForm(request.POST or None,instance=branch)
    if request.method=='POST' and form.is_valid():
        form.save()
        messages.success(request,'Nama cabang berhasil diperbarui.')
        return redirect('dashboard')
    return render(request,'core/generic_form.html',{'form':form,'page_title':'Edit nama cabang','back_url':'/'})
