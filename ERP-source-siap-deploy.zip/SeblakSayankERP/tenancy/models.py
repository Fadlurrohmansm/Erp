from django.db import models
from .scope import current_branch,default_branch

class Branch(models.Model):
    name=models.CharField('Nama cabang',max_length=100,unique=True)
    class Meta:ordering=['name']
    def __str__(self):return self.name

class BranchManager(models.Manager):
    def get_queryset(self):
        qs=super().get_queryset()
        selected=current_branch.get()
        return qs.filter(branch_id=selected) if selected is not None else qs

class BranchScopedModel(models.Model):
    branch=models.ForeignKey(Branch,on_delete=models.PROTECT,default=default_branch,editable=False)
    objects=BranchManager()
    class Meta:abstract=True
