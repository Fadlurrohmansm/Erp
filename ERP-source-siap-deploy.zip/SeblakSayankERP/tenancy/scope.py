from contextvars import ContextVar
current_branch = ContextVar('current_branch', default=None)

def default_branch():
    selected=current_branch.get()
    if selected is not None:return selected
    from .models import Branch
    branch=Branch.objects.order_by('pk').first()
    return branch.pk if branch else Branch.objects.create(name='Cabang Utama').pk
