from datetime import date
from decimal import Decimal
from django.test import TestCase,Client
from django.contrib.auth import get_user_model
from django.urls import reverse
from django.core.files.uploadedfile import SimpleUploadedFile
from tenancy.models import Branch
from tenancy.scope import current_branch
from core.models import Employee,Payroll,Attendance
from core.forms import PayrollForm
from operations.models import Product,Channel,Sale,Ingredient,Expense
from operations.forms import SaleRowForm
class BranchTests(TestCase):
    def setUp(self):
        self.user=get_user_model().objects.create_user('branchowner',password='testing');self.client.force_login(self.user)
        self.a=Branch.objects.order_by('pk').first()
        self.b=Branch.objects.create(name='Kepanjen')
        self.pa=Product.objects.create(branch=self.a,name='Seblak',manual_cost=5000)
        self.pb=Product.objects.create(branch=self.b,name='Seblak',manual_cost=7000)
        self.ea=Employee.objects.create(branch=self.a,employee_code='01',full_name='Tim A',position='Crew',hire_date=date(2026,1,1))
        self.eb=Employee.objects.create(branch=self.b,employee_code='01',full_name='Tim B',position='Crew',hire_date=date(2026,1,1))
        for branch in [self.a,self.b]:Channel.objects.get_or_create(branch=branch,name='Offline')
        self.sa=Sale.objects.create(branch=self.a,date=date(2026,10,28),channel=Channel.objects.get(branch=self.a,name='Offline'),channel_name='Offline',subtotal=111111,net_revenue=111111,created_by=self.user)
        self.sb=Sale.objects.create(branch=self.b,date=date(2026,10,28),channel=Channel.objects.get(branch=self.b,name='Offline'),channel_name='Offline',subtotal=222222,net_revenue=222222,created_by=self.user)
    def switch(self,branch):
        self.assertEqual(self.client.post(reverse('branch_switch'),{'branch_id':branch.pk}).status_code,302)
    def test_switch_scopes_dashboard_people_and_direct_urls(self):
        self.switch(self.a)
        r=self.client.get(reverse('dashboard')+'?day=2026-10-28&month=2026-10')
        self.assertContains(r,'Rp111.111');self.assertNotContains(r,'Rp222.222')
        self.assertEqual(self.client.get(reverse('sale_detail',args=[self.sb.pk])).status_code,404)
        self.assertContains(self.client.get(reverse('employee_list')),'Tim A');self.assertNotContains(self.client.get(reverse('employee_list')),'Tim B')
        self.switch(self.b)
        r=self.client.get(reverse('dashboard')+'?day=2026-10-28&month=2026-10')
        self.assertEqual(r.context['stats']['revenue'],222222);self.assertEqual(r.context['delivery']['gross'],222222)
        self.assertEqual(self.client.get(reverse('product_edit',args=[self.pa.pk])).status_code,404)
    def test_new_menu_auto_branch_and_cross_branch_form_blocked(self):
        self.switch(self.b)
        data={'name':'Menu Kepanjen','price':12000,'manual_cost':5000,'active':'on','recipes-TOTAL_FORMS':0,'recipes-INITIAL_FORMS':0}
        self.assertEqual(self.client.post(reverse('product_create'),data).status_code,302)
        self.assertEqual(Product.objects.get(name='Menu Kepanjen').branch_id,self.b.pk)
        self.assertEqual(self.client.post(reverse('payroll_create'),{'employee':self.ea.pk,'period_type':'monthly','month':10,'year':2026,'manual_deduction':0}).status_code,200)
        self.assertFalse(Payroll.objects.exists())
    def test_reused_class_queryset_does_not_leak_or_stay_old_branch(self):
        original=SaleRowForm.base_fields['product'].queryset
        SaleRowForm.base_fields['product'].queryset=Product.objects.filter(branch=self.a,active=True)
        token=current_branch.set(self.b.pk)
        try:
            f=SaleRowForm()
            self.assertEqual(list(f.fields['product'].queryset.values_list('pk',flat=True)),[self.pb.pk])
            self.assertFalse(SaleRowForm({'product':self.pa.pk,'quantity':1,'unit_price':12000}).is_valid())
        finally:
            current_branch.reset(token)
            SaleRowForm.base_fields['product'].queryset=original
        self.assertIsNone(current_branch.get())
    def test_create_branch_seeds_channels_and_clears_import_drafts(self):
        session=self.client.session;session['csv_import_draft']={'fake':1};session['pos_cost_draft']={'fake':1};session.save()
        self.assertEqual(self.client.post(reverse('branch_create'),{'name':'Dau'}).status_code,302)
        branch=Branch.objects.get(name='Dau');self.assertEqual(self.client.session['branch_id'],branch.pk)
        self.assertEqual(Channel.objects.filter(branch=branch).count(),4);self.assertEqual(Product.objects.filter(branch=branch).count(),0)
        self.assertNotIn('csv_import_draft',self.client.session);self.assertNotIn('pos_cost_draft',self.client.session)
        self.assertContains(self.client.get(reverse('dashboard')),'Cabang aktif')
    def test_monthly_rounding_ceils_thousands(self):
        for value,expected in [('338709',339000),('338709.68',339000),('339000',339000),('339000.01',340000)]:
            p=Payroll(employee=self.ea,month=10,year=2026,base_salary=Decimal(value))
            self.assertEqual(p.payable_base_salary,expected)
    def test_branch_switch_requires_post_and_auth(self):
        self.assertEqual(self.client.get(reverse('branch_switch')).status_code,405)
        self.client.logout();self.assertEqual(self.client.post(reverse('branch_create'),{'name':'X'}).status_code,302)

    def test_old_tab_branch_stamp_blocks_wrong_branch_write(self):
        self.switch(self.b)
        data={'_branch_id':self.a.pk,'name':'Wrong tab menu','price':12000,'manual_cost':5000,'active':'on','recipes-TOTAL_FORMS':0,'recipes-INITIAL_FORMS':0}
        self.assertEqual(self.client.post(reverse('product_create'),data).status_code,409)
        self.assertFalse(Product.objects.filter(name='Wrong tab menu').exists())
