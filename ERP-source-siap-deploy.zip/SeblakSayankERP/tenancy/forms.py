from django import forms
from .scope import current_branch
from .models import Branch

class ScopedFields:
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        selected=current_branch.get()
        if selected is not None:
            for field in self.fields.values():
                if isinstance(field,forms.ModelChoiceField) and any(f.name=='branch' for f in field.queryset.model._meta.fields):
                    if field.queryset.model.__name__=='Employee':
                        from core.employee_scope import fresh_employee_queryset
                        field.queryset=fresh_employee_queryset(field.queryset,selected)
                        continue
                    qs=field.queryset.all()
                    # A class-level field may have been constructed in an earlier request.
                    # Replace its old direct branch predicate, preserving active/menu filters.
                    qs.query.where.children=[c for c in qs.query.where.children if getattr(getattr(getattr(c,'lhs',None),'target',None),'name',None)!='branch']
                    field.queryset=qs.filter(branch_id=selected)

class ScopedForm(ScopedFields,forms.Form):pass
class ScopedModelForm(ScopedFields,forms.ModelForm):
    def clean(self):
        data=super().clean()
        model=self._meta.model
        unique_field={'Ingredient':'name','Product':'name','Channel':'name','JobRole':'name','Employee':'employee_code'}.get(model.__name__)
        if unique_field and data.get(unique_field):
            if model.objects.filter(**{unique_field+'__iexact':data[unique_field].strip()}).exclude(pk=self.instance.pk).exists():
                self.add_error(unique_field,'Nama/kode ini sudah dipakai pada cabang yang dipilih.')
        return data

class BranchForm(forms.ModelForm):
    class Meta:model=Branch;fields=['name']
    def clean_name(self):
        value=self.cleaned_data['name'].strip()
        if Branch.objects.filter(name__iexact=value).exclude(pk=self.instance.pk).exists():raise forms.ValidationError('Nama cabang sudah digunakan.')
        return value
