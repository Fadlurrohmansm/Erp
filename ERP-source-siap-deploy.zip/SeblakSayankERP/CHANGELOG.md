# Versi 2.52 — Impor GrabFood

- Terima kode pendek pesanan yang berulang jika jumlah dan seluruh total cocok dengan ringkasan PDF.

# Versi 2.51 — Smart HPP

- Manajemen HPP terintegrasi dengan resep, persediaan, pembelian, dan penjualan ERP.
- Costing per cabang, produksi batch, simulasi kanal, peringatan harga dan riwayat snapshot.
- Migrasi 0017 dan 0018. Petunjuk lengkap ada di PANDUAN_HPP.md.

# Versi 2.50 — Porsi terjual dan pembayaran Offline POS

- Menambahkan input porsi per rekap dan total porsi tercatat di dashboard serta laporan CSV.
- Menempatkan tunai dan QRIS berdampingan dalam bagian Pembayaran Offline POS.

# Versi 2.49 — Pembayaran tunai dan QRIS manual

- Rekap Offline menerima rincian nominal tunai dan QRIS, dengan validasi total.
- Dashboard menggabungkan rekap manual dan POS, memakai rincian manual untuk rekap yang sama.

# Versi 2.48 — Keseragaman petunjuk seluruh tab

- Menyeragamkan kotak informasi, peringatan, notifikasi tindakan dan bantuan isian.
- Merapikan kalimat petunjuk absensi, pengeluaran dan rekap manual.

# Versi 2.47 — Drag seleksi tanggal absensi

- Tahan klik dan drag untuk memilih/membatalkan rentang tanggal pada komputer.
- Kotak centang diperkecil; klik tanggal biasa dan centang sebulan tetap tersedia.

# Versi 2.46 — Input Rekap Manual

- Nama tombol, halaman dan label form disesuaikan untuk pencatatan manual tanpa file POS.

# Versi 2.45 — Dashboard simetris dan satu tema

- Menyeragamkan kartu, jarak, tabel, warna dan kontrol filter dashboard.
- Ringkasan empat kartu dan panel analisis berukuran seimbang serta responsif.

# Versi 2.44 — Analisis lima hari penjualan tertinggi

- Peringkat omzet harian bulanan di dashboard, seluruh kanal cabang aktif, beserta pesanan dan pendapatan bersih.

# Versi 2.43 — Filter dashboard tanpa kembali ke atas

- Memulihkan posisi scroll setelah submit filter tanggal/bulan dan tombol Sejak awal.

# Versi 2.42 — Pilih absensi sebulan penuh

- Centang semua tanggal dan indikator pilihan sebagian.
- Navigasi bulan kalender tanpa scroll ke atas dan sinkronisasi filter bulan.

# Versi 2.41 — Rapikan UI absensi

- Geometri kalender, checkbox, filter, ringkasan dan tombol simpan konsisten serta responsif.

# Versi 2.40 — Impor POS pembayaran campuran

- Mendukung beberapa metode pembayaran dalam satu struk tanpa menebak pembagian nominal atau menggandakan omzet.
- Ringkasan pembayaran dashboard dan pratinjau menampilkan kategori Campuran.

# Versi 2.39 — Absensi beberapa tanggal sekaligus

- Checkbox kalender, penghitung tanggal, hapus pilihan dan simpan bersama.
- Validasi per tanggal dan transaksi atomik, mendukung absensi bersama antarcabang.

# Versi 2.38 — Rapikan laporan keuangan

- Menghapus blok notifikasi di atas judul laporan keuangan tanpa mengubah data/perhitungan.

# Versi 2.37 — Perbaikan tampilkan semua menu

- Menghapus batas 20 menu pada mode semua kategori/layout tampilkan semua agar kategori terakhir tidak terpotong. Pencarian tetap berlaku.

# Versi 2.36 — Dukungan CSV transaksi GoFood

- Mengenali format Laporan Transaksi GoFood bertanggal ISO tanpa kolom Refund/Gopay Source.
- Memvalidasi jenis transaksi, mata uang, zona waktu, rincian biaya, total bersih dan duplikasi.

# Versi 2.35 — Rapikan kategori dan tombol

- Kartu kategori mengalir pada kolom mandiri, mengisi ruang kosong tanpa menunggu kategori panjang.
- Ukuran tombol utama, filter dan aksi formulir diseragamkan; tombol tabel tetap ringkas.
- Cache CSS diperbarui agar desain langsung dimuat.

# Versi 2.34 — Perbaikan impor PDF Grab

- Mengenali baris pesanan dibatalkan dengan nominal tanda minus; tetap memvalidasi jumlah seluruh pesanan dan total keuangan.
- PDF 29 Oktober 2026 terverifikasi: 43 selesai, 1 batal, bersih Rp642.152.

# Versi 2.33 — Unduh slip gaji PNG

- Tombol PNG pada daftar dan preview payroll, desain PDF yang sama, seluruh halaman digabung dalam satu gambar 144 dpi.

# Versi 2.32 — Nama file slip gaji

- Unduhan dan preview PDF memakai slipgaji_nama_tanggal_bulan.pdf berdasarkan nama karyawan dan akhir periode gaji.

# Versi 2.31 — Karyawan dan absensi bersama antarcabang

- Impor menghubungkan cabang ke satu identitas karyawan, tanpa salinan absensi.
- Absensi lama terlihat dan perubahan tersinkron dua arah.
- Perlindungan konflik kode, pembatas data utama/payroll di cabang asal, dan pencegahan hitungan absensi ganda.

# Versi 2.30 — Pembayaran gaji bulanan

- Catat pelunasan payroll dengan tanggal pembayaran dan nominal snapshot.
- Total bulan ini/bulan pilihan pada Payroll dan Dashboard, mengikuti tanggal pembayaran aktual.
- Cegah pembayaran ganda, lindungi slip dibayar dan riwayat, koreksi dengan alasan tanpa menghapus catatan.

# Versi 2.29 — Kontrol dashboard simetris

- Samakan ukuran dan jarak tombol/filter dashboard dengan label yang jelas.
- Susunan responsif dan filter absensi dipertahankan saat mengganti periode lain.

# Versi 2.28 — Pengaturan jatah gabungan

- Mode Gabungan: Libur Jatah/Izin/Sakit menggunakan kuota bulanan bersama; hanya hari kelebihan dipotong.
- Mode Terpisah tetap tersedia untuk kebijakan usaha lain.
- Statistik kalender mengikuti mode gabungan, snapshot payroll lama dipertahankan.

# Versi 2.27 — Menu, laporan dan akun

- Hapus menu dicentang lintas halaman via pop-up; menu dengan riwayat dinonaktifkan.
- Toolbar laporan simetris/responsif, input periode mengikuti mode harian/bulanan.
- Pembuatan akun operasional oleh administrator dan penggantian password sendiri dengan validasi/sesi tetap aktif.

# Versi 2.26 — Konfirmasi pop-up dan potongan payroll

- Dialog konfirmasi hapus karyawan/jabatan/payroll dan pembatalan transaksi.
- Slip menampilkan nama/jumlah hari cabang kerja dalam periode payroll.
- Pengaturan potongan absensi per cabang, tarif tetap atau prorata kalender, quota libur bulanan untuk payroll mingguan.
- Snapshot aturan/rincian, pilihan terapkan aturan terbaru saat refresh, perlindungan gaji negatif dan gaji harian tanpa potongan ganda.

# Versi 2.25 — Layout kategori yang dapat dipilih

- Centang Tampilkan semua atau beberapa kategori untuk tampilan Menu & resep.
- Pilihan Tanpa kategori dan penyimpanan per akun/cabang.
- Filter sementara tidak mengubah layout tersimpan.

# Versi 2.24 — Kategori menu dengan pilihan lintas halaman

- Pilihan centang disimpan per akun/cabang/tab saat pindah halaman atau filter.
- Daftar seluruh pilihan dapat ditinjau dan dibatalkan sebelum penerapan.
- Setelah kategori disimpan, tampilkan kategori hasil beserta menunya.
- Daftar menu menjadi tabel per kategori dalam dua kolom responsif.
- Pagination mempertahankan kategori dan pencarian.

# Versi 2.23 — Rapikan ringkasan dashboard

- Hilangkan banner data POS/HPP yang menumpuk di atas judul.
- Pindahkan ke panel rincian yang bisa dibuka/tutup, tertutup secara default.
- Pertahankan indikator HPP nol dan seluruh rincian pembayaran/unit.

# Versi 2.22 — ERP F&B umum dan evaluasi

- Identitas dinamis untuk usaha lain; instalasi baru netral tanpa database bawaan.
- Jenis item utama/tambahan/lainnya, mode kata kunci opsional, klasifikasi snapshot.
- Non-tunai umum/QRIS/transfer dapat diatur dan dilaporkan.
- Koreksi override HPP kanal pada penjualan item, peringatan HPP nol.
- Form admin memakai pembatas cabang; kunci sesi lokal unik.
- Migrasi menjaga identitas/aturan legacy dan data operasional lama.
- Tambah panduan instalasi dan AUDIT_ERP_FNB.md dengan batas penggunaan.

# Versi 2.21 — Pembayaran POS Tunai dan QRIS

- Simpan nominal dan jumlah struk per metode pembayaran, satu kali per struk.
- Tampilkan rincian pada pratinjau, penjualan, dashboard dan laporan/CSV.
- Lengkapi pembayaran impor Offline lama melalui file identik tanpa menggandakan omzet.

# Versi 2.20 — Porsi seblak dari POS

- Pisahkan jumlah struk, porsi nama mengandung seblak dan tambahan topping.
- Omzet/HPP tetap mencakup seluruh item; riwayat POS lama mengikuti aturan otomatis.

# Versi 2.19 — Kategori menu dan laporan harian

- Centang menu untuk memberi kategori sekaligus dan filter kategori.
- Impor seluruh menu/resep dari cabang lain tanpa memindahkan stok.
- Laporan harian dan CSV dengan pembukuan payroll tanggal akhir periode.
- Rekap absensi dashboard sejak mulai bekerja atau per bulan.
- Desain PDF slip gaji modern dengan pengaturan visibilitas yang dipertahankan.

# Versi 2.18 — Pengelolaan cabang dan penempatan harian

- Edit nama cabang dengan validasi nama unik.
- Masa kerja karyawan berdasarkan tanggal mulai bekerja.
- Cabang bertugas per tanggal absensi; riwayat lama memakai cabang asal.

# Versi 2.17 — HPP nol pada impor POS

- Terima HPP Rp0 dan resep dengan biaya bahan yang belum terisi.
- Pertahankan validasi menu, total POS dan pencegahan impor ganda.
- Uji penyimpanan rekap baru dan pembaruan rekap dengan seluruh HPP nol.

# Versi 2.16 — Cabang dan pembulatan gaji ribuan

- Dropdown cabang di kiri atas serta tambah cabang dengan nama.
- Data operasional, laporan, staf, stok, menu dan impor dipisahkan per cabang.
- Data lama dimigrasi ke Sigura-gura tanpa dihapus.
- Pengaman tab lama dan pembatasan pilihan form lintas cabang.
- Gaji pokok bulanan dibulatkan ke atas per Rp1.000.
- 110 pengujian lulus, migrasi salinan database dan PDF diperiksa.

# Versi 2.15 — Edit layout slip gaji

- Pengaturan global bagian slip tampil/sembunyi dari Payroll/Preview.
- Judul dan catatan penutup dapat diedit; nama, periode dan total tetap tampil.
- Preview HTML dan PDF mengikuti pengaturan tanpa mengubah perhitungan.
- Migrasi tabel layout; 103 tes lulus dan PDF ringkas diperiksa.

# Versi 2.14 — Catatan potongan dan pembulatan gaji

- Catatan khusus potongan pada form payroll, tampil sebagai nama baris pada preview/PDF.
- Gaji pokok bulanan/prorata dibulatkan ke Rupiah utuh; total mengikuti dasar bulat.
- Snapshot absensi dan nominal komponen lain dipertahankan.
- Migrasi kolom catatan; 100 tes lulus dan visual PDF diperiksa.

# Versi 2.13 — Form karyawan dan scroll absensi

- Hapus input uang bensin bulanan dari formulir karyawan, pertahankan nilai lama.
- Pergantian tanggal absensi secara parsial, pertahankan posisi scroll.
- Pulihkan posisi setelah simpan dan tangani klik cepat dengan pembatalan request.
- 97 tes Django, pemeriksaan sintaks dan simulasi JavaScript lulus.

# Versi 2.12 — Pendapatan bersih harian dan menu massal

- Kartu pendapatan bersih tanggal terpilih di atas ringkasan omzet.
- Tambah hingga 100 menu beserta HPP dasar/per platform sekaligus.
- Validasi nama duplikat dan penyimpanan atomik seluruh daftar.
- 95 pengujian lulus; tidak perlu migrasi tambahan.

# Versi 2.11 — Analisis delivery harian

- Pilih tanggal, lihat diagram donat/batang omzet per ShopeeFood/GrabFood/GoFood/Offline.
- Persentase kontribusi serta subtotal Online tanpa penghitungan ganda.
- Omzet bruto, pendapatan bersih dan pesanan ditampilkan terpisah.
- 91 pengujian lulus; tidak perlu migrasi tambahan.

# Versi 2.10 — Preview slip gaji

- Preview HTML responsif dari payroll tersimpan, tautan dari daftar dan Edit.
- PDF inline pada tab baru, unduh PDF dan cetak preview.
- Ringkasan bonus manual dan absensi tanpa menghitung ulang.
- 88 pengujian lulus; tidak perlu migrasi tambahan.

# Versi 2.9 — Pemeriksaan bonus mingguan

- Tabel per hari membandingkan bonus tersimpan dengan absensi terbaru.
- Hitung ulang absensi atas konfirmasi, mempertahankan tarif dan bonus manual.
- Uji tanggal 24–30 inklusif dan kasus snapshot 5 menjadi 7.
- Penolakan hitung ulang bila potongan melebihi penghasilan baru.
- 85 pengujian lulus; tidak perlu migrasi database tambahan.

# Versi 2.8 — Desain pastel dan Rupiah

- Sidebar abu-abu, navigasi lime, panel membulat dan kartu pastel sesuai arah referensi.
- Dashboard baru dengan grafik data nyata dan komposisi kanal.
- Format Rupiah konsisten, mempertahankan sen/desimal settlement.
- Prefix Rp pada formulir uang, tanpa mengubah input angka.
- 82 pengujian lulus; browser screenshot belum terverifikasi.

# Versi 2.7 — Payroll rentang tanggal dan jabatan

- Tambah/edit/hapus jabatan dengan gaji bulanan atau harian.
- Payroll mingguan/rentang, tanggal inklusif, snapshot tarif dan absensi.
- Gaji harian hanya hari Masuk/Masuk terlambat; bonus manual tetap terhubung.
- Bulanan parsial diprorata kalender, laporan memakai bulan akhir periode.
- Validasi periode bertumpuk dan pemeliharaan payroll lama.
- 80 pengujian lulus dan slip mingguan diperiksa.

# Versi 2.6 — HPP manual per platform

- Kolom HPP ShopeeFood, GrabFood, GoFood pada tambah/edit dan daftar menu.
- Kolom kosong memakai resep/HPP dasar; biaya platform terpisah.
- Pencocokan menu POS memilih HPP sesuai kanal dan menyimpan snapshot.
- 72 pengujian lulus; migrasi menambah kolom tanpa mengubah data lama.

# Versi 2.5 — Workflow empat sumber dan POS Offline XLSX

- Impor XLSX Riwayat Penjualan sesuai contoh asli pemilik.
- Rekap omzet Offline beserta HPP resep, tanpa input omzet manual.
- Menu lanjutan, topping, diskon transaksi dan footer Total ditangani.
- Pemetaan nama menu diingat dan HPP disimpan sebagai snapshot.
- Pencegahan file/rekap ganda, validasi HPP nol dan total struk.
- 69 tes lulus; contoh XLSX asli diuji pada database salinan.

# Versi 2.4 — Impor PDF Grab dan HPP otomatis opsional

- Membaca settlement PDF Laporan Bisnis Harian Grab tanpa konversi.
- Validasi seluruh pesanan terhadap ringkasan, tanggal dan potongan.
- Persentase HPP sekali di Pengaturan, estimasi otomatis pada impor seluruh kanal.
- Penanda HPP/laba estimasi pada detail, dashboard, laporan dan CSV.
- 61 tes lulus; contoh PDF asli berhasil direkonsiliasi.

# Versi 2.3 — Perbaikan payroll dan bonus manual

- Hapus payroll melalui konfirmasi; absensi tetap tersimpan.
- Hapus karyawan beserta seluruh absensi/payroll/bonus setelah konfirmasi.
- Beberapa bonus/tunjangan manual dengan catatan, total gaji, laporan dan slip PDF.
- Snapshot gaji/absensi dipertahankan ketika bonus diedit.
- 55 tes lulus; migrasi pada salinan database dan visual slip PDF diperiksa.

# Versi 2.2 — Impor CSV delivery

- Pratinjau ShopeeFood dan GoFood berdasarkan file unggahan aktual; template standar GrabFood.
- Rekap per tanggal/kanal dengan HPP wajib, rekonsiliasi pendapatan dan transaksi atomik.
- Penolakan file identik, tanggal/kanal ganda, ID duplikat, refund dan format ambigu.
- Migrasi CSVImport; 47 pengujian lulus.

# Versi 2.1 — Rekap POS

- Input rekap harian empat kanal menggantikan kasir per menu.
- Nominal biaya aktual, HPP POS, jumlah pesanan, biaya lain dan pencegahan rekap ganda.
- Dashboard, laporan dan CSV diperbarui; stok rekap tidak berubah.
- Migrasi menambah kolom tanpa mengubah transaksi lama.
- 39 pengujian lulus.

# Perubahan versi 2.0

- Menambahkan aplikasi `operations`: penjualan, menu dan resep, persediaan, pembelian, opname, biaya operasional, laporan dan pengaturan.
- Menyatukan halaman lama dengan layout responsif, sidebar, warna pink, kartu indikator, grafik harian dan keadaan kosong yang jelas.
- Memisahkan pembelian persediaan dari beban HPP agar laba tidak mengurangi biaya bahan dua kali.
- Menyimpan snapshot harga, HPP dan tarif platform pada transaksi.
- Menambahkan transaksi atomik, validasi stok, reversal pembatalan dan token pencegah kirim ganda.
- Menambahkan ekspor laporan CSV, cetak struk dan backup database untuk pemilik.
- Mempertahankan data serta perhitungan absensi/payroll versi sebelumnya.
- Menambahkan perintah `upgrade_erp` untuk backup sebelum migrasi, `seed_demo` untuk database contoh terpisah, dan `MULAI_WINDOWS.bat`.

Database dalam paket adalah salinan asli unggahan. Jalankan migrasi sebelum menggunakan aplikasi versi ini.
