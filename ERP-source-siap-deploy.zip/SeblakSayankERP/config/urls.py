
from django.contrib import admin
from django.urls import path, include
from django.http import JsonResponse
from django.db import connection
from tenancy import views as branch_views


def health_check(request):
    try:
        with connection.cursor() as cursor:
            cursor.execute('SELECT 1')
    except Exception:
        return JsonResponse({'status': 'unavailable'}, status=503)
    return JsonResponse({'status': 'ok'})

urlpatterns = [
    path('health/', health_check, name='health_check'),
    path('branches/<int:branch_id>/edit/',branch_views.branch_edit,name='branch_edit'),
    path('branches/add/',branch_views.branch_create,name='branch_create'),
    path('branches/switch/',branch_views.branch_switch,name='branch_switch'),
    path("admin/", admin.site.urls),
    path("accounts/", include("django.contrib.auth.urls")),
    path("", include("core.urls")),
    path("", include("operations.urls")),
]
