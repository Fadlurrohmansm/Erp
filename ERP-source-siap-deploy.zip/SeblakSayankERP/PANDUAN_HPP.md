# Smart HPP Seblak Sayank ERP

## Memasang pembaruan

1. Tutup aplikasi ERP dan buat cadangan `db.sqlite3` serta `.erp_secret_key` jika ada.
2. Ekstrak ZIP dan salin kode ke folder ERP yang biasa dipakai. Letakkan database dan kunci lama di lokasi yang sama seperti sebelumnya. Paket ini berisi kode dan migrasi.
3. Jalankan `MULAI_WINDOWS.bat`. Skrip memeriksa dependensi dan menjalankan migrasi. Untuk instalasi yang memakai terminal, gunakan `python manage.py migrate`, lalu `python manage.py runserver`.
4. Masuk ke ERP, pilih cabang lewat pemilih cabang di bagian atas, kemudian buka **Manajemen HPP**.

## Menghitung HPP sehari-hari

1. **Bahan Baku**. Pakai satuan dasar g, ml, atau pcs untuk resep dan stok. Kilogram ke gram dan liter ke mililiter dikonversi otomatis. Untuk pack atau satuan khusus, isi nama dan isi pack di master bahan, misalnya satu pack berisi 20 pcs.
2. **Pembelian Bahan**. Catat nota, supplier, tanggal dan baris bahan. Harga bersih pembelian adalah jumlah beli dikali harga satuan, dikurangi diskon, ditambah alokasi ongkir. Total masuk ke nilai persediaan. Buku mutasi pembelian lama juga dibaca sebagai riwayat harga jika memiliki biaya dan kuantitas valid.
3. **Resep Menu**. Edit menu yang sudah ada. Untuk satu porsi, isi hasil bersih 1. Untuk batch, isi takaran bersih seluruh batch dan hasil bersih dalam porsi. Waste 20% pada takaran bersih 100 g berarti pemakaian bruto 125 g. Tandai kemasan dan tambahan untuk memisahkan kelompok biaya. Bahan pengganti harus bersatuan sama dan dipakai jika harga bahan utama belum lengkap dalam metode yang dipilih. Buat topping atau varian sebagai menu tersendiri. Varian dapat menunjuk menu induk.
4. **Produksi Batch**. Buat master bahan hasil, lalu catat bahan aktual yang dipakai dan hasil bersih. Misalnya biaya batch Rp80.000 dengan hasil bersih 1.800 g menghasilkan biaya sekitar Rp44,44/g. Gunakan bahan hasil di resep. Bahan mentah yang sudah masuk nilai batch jangan dimasukkan lagi dalam resep yang sama.
5. **Kalkulator HPP**. Pilih menu, tanggal, dan metode. Periksa perincian bahan dan bandingkan kanal. Klik **Atur** pada kanal untuk mengatur harga, kemasan, komisi, promo dan biaya transaksi. Masukkan harga baru serta kanal simulasi untuk melihat dampaknya. Rekomendasi mengikuti kelipatan pembulatan cabang dan target yang dipilih. Harga aktif diubah melalui form menu atau aturan kanal.
6. **Riwayat HPP**. Isi alasan dan simpan snapshot. Hitung ulang dengan alasan baru menghasilkan catatan terpisah. Riwayat menyimpan versi resep, harga bahan, biaya, harga jual dan margin. Data penjualan menyimpan HPP satuan atau HPP rekonsiliasi POS yang digunakan saat dibukukan.

## Metode biaya dan aturan kanal

| Metode | Dasar perhitungan |
| --- | --- |
| Harga beli terakhir | Nota valid paling baru berdasarkan tanggal pembelian, lalu urutan pencatatan jika tanggal sama. |
| Rata-rata pembelian tertimbang | Jumlah biaya bersih nota dibagi kuantitas pembelian dalam 7, 30, atau 90 hari. |
| Rata-rata persediaan berjalan | Nilai saldo persediaan dibagi kuantitas stok berdasarkan mutasi yang sudah dibukukan. |

Nota bertanggal mundur masuk ke jendela pembelian berdasarkan tanggal nota, sedangkan nilai stok berjalan berubah pada saat pembukuan. Untuk bahan hasil produksi yang belum pernah dibeli, kalkulator memakai nilai batch produksi sebagai sumber biaya pada metode terakhir atau tertimbang. Bahan yang belum punya biaya valid ditandai **Harga belum lengkap**.

Laba kotor per porsi memakai harga setelah diskon merchant. Voucher yang didanai platform mengurangi tagihan pelanggan dan dapat memengaruhi basis komisi setelah diskon, sementara penerimaan merchant tetap mendapat pendanaan voucher tersebut. Kontribusi mengurangi komisi dan biaya layanan/pembayaran. Biaya per transaksi dialokasikan menurut jumlah porsi yang dikonfigurasi. Periksa kesesuaian basis dengan laporan masing-masing kanal.

Aktifkan **Gunakan HPP dinamis untuk penjualan dan rekonsiliasi POS baru** di Pengaturan HPP setelah resep dan harga siap. HPP manual khusus kanal tetap didahulukan saat digunakan. Aturan komisi dan promo modul HPP dipakai untuk simulasi. Penjualan settlement dan rekap memakai potongan aktual yang sudah dicatat. Rekap tanpa rincian item tetap memerlukan HPP manual atau metode estimasi impor ERP.

## Model dan migrasi

- `0017_smart_hpp` menambah konfigurasi bahan, yield dan biaya batch menu, waste dan substitusi resep, serta nilai rata-rata setelah mutasi. Model baru adalah `HPPPolicy`, `HPPPurchase`, `HPPRecipeVersion`, `HPPChannelRule`, `HPPSnapshot`, dan `HPPProduction`.
- `0018_hpp_channel_promos_and_variants` menambah relasi menu induk varian dan diskon platform berbasis persentase.
- Katalog, stok, pengguna, cabang, transaksi dan form ERP lama tetap menggunakan tabel yang sama. Resep antarcabang dapat disalin melalui **Impor menu dari cabang lain**, lalu diedit sebagai resep lokal.

## Batas penggunaan

- Riwayat rata-rata stok sebelum pembaruan bisa belum lengkap karena mutasi lama tidak menyimpan nilai rata-rata setelah mutasi. Resep dari tanggal sebelum versi pertama juga mungkin belum tersedia. Perbandingan kanal untuk tanggal referensi lampau memakai aturan harga saat kalkulasi. Untuk mengetahui angka yang pernah dipakai, buka snapshot tersimpan.
- Pembatalan nota terperinci hanya tersedia selama baris pembelian masih menjadi mutasi terakhir bahan. Pembelian yang sudah diikuti mutasi memerlukan koreksi stok dan biaya terpisah agar transaksi setelahnya tetap dapat diaudit.
- Peringatan ditampilkan per bahan/menu pada dashboard. Selisih pemakaian berbasis opname adalah estimasi, terutama bila ada penjualan harian tanpa mutasi item. Tidak ada akses cabang tambahan di luar kebijakan akses ERP yang sudah ada.
