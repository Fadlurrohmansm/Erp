from datetime import date
from decimal import Decimal as D
from django.test import TestCase
from django.contrib.auth import get_user_model
from django.urls import reverse
from .models import Employee,Payroll
from .payroll_calculation import snapshot_payroll
class DeductionRoundingTests(TestCase):
    def setUp(self):
        self.client.force_login(get_user_model().objects.create_user('roundtester',password='testing'))
        self.e=Employee.objects.create(employee_code='ROUND',full_name='Contoh',position='Crew',hire_date=date(2026,1,1),base_salary=1500000,punctual_bonus_per_day=0)
    def test_new_prorata_rounds_and_totals_consistent(self):
        p=Payroll(employee=self.e,month=10,year=2026,start_date=date(2026,10,24),end_date=date(2026,10,30),manual_deduction=100000,deduction_note='Kasbon minggu ini')
        snapshot_payroll(p);p.save()
        self.assertEqual(p.base_salary,339000);self.assertEqual(p.net_salary,239000)
        response=self.client.get(reverse('payroll_preview',args=[p.pk]))
        self.assertContains(response,'Kasbon minggu ini');self.assertContains(response,'Rp339.000');self.assertNotContains(response,'Potongan manual')
        self.assertEqual(self.client.get(reverse('payroll_pdf',args=[p.pk])).status_code,200)
    def test_old_snapshot_rounds_payable_without_mutating_attendance(self):
        p=Payroll.objects.create(employee=self.e,month=10,year=2026,base_salary=D('338709.68'),manual_deduction=100000)
        self.assertEqual(p.payable_base_salary,339000);self.assertEqual(p.net_salary,239000)
        self.assertEqual(p.deduction_label,'Potongan')
        p.pay_scheme='daily';self.assertEqual(p.payable_base_salary,D('338709.68'))
    def test_edit_note_is_saved_and_escaped(self):
        p=Payroll.objects.create(employee=self.e,month=10,year=2026,base_salary=1500000)
        data={'employee':self.e.pk,'month':10,'year':2026,'manual_deduction':200000,'deduction_note':'<b>Kasbon</b>','notes':''}
        self.assertEqual(self.client.post(reverse('payroll_edit',args=[p.pk]),data).status_code,302)
        p.refresh_from_db();self.assertEqual(p.deduction_note,'<b>Kasbon</b>')
        self.assertContains(self.client.get(reverse('payroll_preview',args=[p.pk])),'&lt;b&gt;Kasbon&lt;/b&gt;')
