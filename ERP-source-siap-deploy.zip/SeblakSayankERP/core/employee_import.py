from django.db import transaction
from django.db.models import F
from django.core.exceptions import ValidationError
from .models import Employee,EmployeeBranchAccess
from .employee_scope import employee_visibility

@transaction.atomic
def import_employees(source_id,target_id,ids):
    if source_id==target_id:raise ValidationError('Pilih cabang sumber yang berbeda.')
    ids={int(i) for i in ids}
    source=Employee._base_manager.filter(employee_visibility(source_id),pk__in=ids).distinct()
    if source.count()!=len(ids):raise ValidationError('Pilihan karyawan tidak tersedia di cabang sumber.')
    # Serializes imports and attendance edits on SQLite; no employee data is changed.
    Employee._base_manager.filter(pk__in=ids).update(base_salary=F('base_salary'))
    added=skipped=0
    for employee in source:
        if employee.branch_id==target_id or EmployeeBranchAccess.objects.filter(employee=employee,branch_id=target_id).exists():
            skipped+=1;continue
        conflict=Employee._base_manager.filter(employee_visibility(target_id),employee_code__iexact=employee.employee_code).exclude(pk=employee.pk).exists()
        if conflict:raise ValidationError('Kode '+employee.employee_code+' sudah dipakai orang lain di cabang tujuan. Ubah kode yang bentrok di cabang asalnya; sistem tidak menggabungkan orang berdasarkan nama/kode.')
        _,created=EmployeeBranchAccess.objects.get_or_create(employee=employee,branch_id=target_id)
        added+=int(created);skipped+=int(not created)
    return added,skipped
