from datetime import date
from decimal import Decimal
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from .models import Employee, Attendance, Payroll
from .forms import AttendanceForm, PayrollForm, EmployeeForm


class PayrollAttendanceTests(TestCase):
    def setUp(self):
        self.employee = Employee.objects.create(employee_code='EMP01', full_name='Pengujian', position='Crew', hire_date=date(2026, 1, 1), base_salary=1200000, fuel_allowance=100000, punctual_bonus_per_day=5000)
        self.client.force_login(get_user_model().objects.create_user('tester', password='test-only-password'))

    def attendance_data(self, **extra):
        return dict(employee=self.employee.pk, date='2026-10-01', status='present', punctual='True', **extra)

    def payroll_data(self, **extra):
        data = dict(employee=self.employee.pk, month=10, year=2026, manual_deduction='20000', notes='Tes')
        data.update(extra)
        return data

    def test_payroll_snapshot_and_pdf(self):
        for day, status, punctual in [(1,'present',True),(2,'present',False),(3,'late',False),(4,'off',False),(5,'sick',False),(6,'leave',False),(7,'absent',False)]:
            Attendance.objects.create(employee=self.employee, date=date(2026,10,day), status=status, punctual=punctual)
        response = self.client.post(reverse('payroll_create'), self.payroll_data())
        self.assertEqual(response.status_code,302)
        p = Payroll.objects.get()
        self.assertEqual((p.present_days,p.late_days,p.off_days,p.sick_days,p.leave_days,p.absent_days,p.punctual_days),(2,1,1,1,1,1,1))
        self.assertEqual(p.net_salary,Decimal('1285000'))
        self.employee.fuel_allowance=999999
        self.employee.save()
        Attendance.objects.filter(status='present').update(punctual=False)
        self.client.post(reverse('payroll_edit',args=[p.pk]),self.payroll_data(manual_deduction='10000'))
        p.refresh_from_db()
        self.assertEqual(p.net_salary,Decimal('1295000'))
        pdf=self.client.get(reverse('payroll_pdf',args=[p.pk]))
        self.assertEqual(pdf.status_code,200)
        self.assertTrue(pdf.content.startswith(b'%PDF'))
        self.client.post(reverse('payroll_create'), self.payroll_data())
        self.assertEqual(Payroll.objects.count(),1)

    def test_invalid_money_and_year(self):
        for data in [self.payroll_data(manual_deduction='-1'), self.payroll_data(year=9999)]:
            self.assertFalse(PayrollForm(data).is_valid())
        self.client.post(reverse('payroll_create'),self.payroll_data(manual_deduction='99999999'))
        self.assertFalse(Payroll.objects.exists())

    def test_calendar_validation_no_bad_write(self):
        url=reverse('attendance_list')+'?month=2026-10'
        data=self.attendance_data(check_in='broken')
        self.assertEqual(self.client.post(url,data).status_code,200)
        self.assertFalse(Attendance.objects.exists())
        data=self.attendance_data(check_in='13:00',check_out='12:00')
        self.assertFalse(AttendanceForm(data).is_valid())
        data=self.attendance_data();data['date']='2025-01-01'
        self.assertFalse(AttendanceForm(data).is_valid())

    def test_off_quota_and_duplicate_day(self):
        url=reverse('attendance_list')+'?month=2026-10'
        for day in range(1,4):
            data=self.attendance_data();data.update(date=f'2026-10-0{day}',status='off',punctual='yes')
            self.assertEqual(self.client.post(url,data).status_code,302)
        self.client.post(url,data)
        self.assertEqual(Attendance.objects.count(),3)
        self.assertFalse(Attendance.objects.filter(punctual=True).exists())
        response=self.client.get(url)
        self.assertEqual(response.context['excess_leave'],1)
        self.client.post(reverse('payroll_create'), self.payroll_data())
        self.assertEqual(Payroll.objects.get().excess_off_days,1)

    def test_pages_and_login(self):
        for name in ['dashboard','employee_list','employee_create','attendance_list','attendance_create','payroll_list','payroll_create']:
            self.assertEqual(self.client.get(reverse(name)).status_code,200,name)
        self.client.logout()
        self.assertEqual(self.client.get(reverse('payroll_list')).status_code,302)

    def test_edit_excessive_deduction_preserves_saved_payroll(self):
        self.client.post(reverse('payroll_create'),self.payroll_data())
        p=Payroll.objects.get()
        self.client.post(reverse('payroll_edit',args=[p.pk]),self.payroll_data(manual_deduction='99999999'))
        p.refresh_from_db()
        self.assertEqual(p.manual_deduction,Decimal('20000'))

    def test_employee_negative_allowance_and_quota(self):
        data=dict(employee_code='EMP02',full_name='Baru',position='Crew',hire_date='2026-01-01',base_salary='1200000',status='active',monthly_leave_quota=32,fuel_allowance='-1',punctual_bonus_per_day='-1')
        form=EmployeeForm(data)
        self.assertFalse(form.is_valid())
        for field in ['monthly_leave_quota','punctual_bonus_per_day']:
            self.assertIn(field,form.errors)
