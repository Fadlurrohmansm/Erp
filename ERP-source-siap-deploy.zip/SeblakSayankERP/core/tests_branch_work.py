from datetime import date
from unittest.mock import patch
from django.test import TestCase
from django.contrib.auth import get_user_model
from django.urls import reverse
from tenancy.models import Branch
from core.models import Employee,Attendance
from core.forms import AttendanceForm

class BranchWorkTests(TestCase):
    def setUp(self):
        self.a=Branch.objects.first()
        self.b=Branch.objects.create(name='Cabang Kedua')
        self.e=Employee.objects.create(branch=self.a,employee_code='TEST',full_name='Tim',position='Crew',hire_date=date(2024,1,31))
        self.client.force_login(get_user_model().objects.create_user('branchwork',password='testing'))
    def test_rename_preserves_relations_and_checks_duplicates(self):
        url=reverse('branch_edit',args=[self.a.pk])
        self.assertEqual(self.client.post(url,{'name':self.a.name}).status_code,302)
        self.assertEqual(self.client.post(url,{'name':'Cabang Kedua'}).status_code,200)
        self.client.post(url,{'name':'Nama Baru'})
        self.e.refresh_from_db();self.assertEqual(self.e.branch.name,'Nama Baru')
    def test_tenure_end_of_month_and_future(self):
        with patch('django.utils.timezone.localdate',return_value=date(2025,2,28)):
            self.assertEqual(self.e.tenure,'1 tahun 1 bulan')
            self.e.hire_date=date(2026,1,1)
            self.assertEqual(self.e.tenure,'Belum mulai bekerja')
    def test_work_branch_saved_without_moving_employee_or_attendance(self):
        response=self.client.post(reverse('attendance_list')+'?month=2026-10&employee='+str(self.e.pk),{'employee':self.e.pk,'date':'2026-10-28','status':'present','punctual':'yes','work_branch':self.b.pk})
        self.assertEqual(response.status_code,302)
        record=Attendance.objects.get(employee=self.e)
        self.assertEqual(record.work_branch,self.b);self.assertEqual(record.branch,self.a)
        self.assertTrue(record.punctual)
        self.assertContains(self.client.get(reverse('attendance_list')+'?month=2026-10&employee='+str(self.e.pk)),'Cabang Kedua')
        self.assertContains(self.client.get(reverse('employee_list')),'LAMA BEKERJA')
    def test_omitted_work_branch_defaults_home_and_invalid_id_rejected(self):
        data={'employee':self.e.pk,'date':'2026-10-28','status':'present','punctual':True}
        form=AttendanceForm(data);self.assertTrue(form.is_valid(),form.errors)
        self.assertEqual(form.save().work_branch,self.a)
        data['work_branch']='999999'
        self.assertFalse(AttendanceForm(data).is_valid())
