from django.contrib import admin
from .models import Employee, Attendance, Payroll
from .forms import EmployeeForm,AttendanceForm


@admin.register(Employee)
class EmployeeAdmin(admin.ModelAdmin):
    form=EmployeeForm
    list_display = (
        "employee_code",
        "full_name",
        "position",
        "phone",
        "base_salary",
        "status",
    )

    list_filter = ("status", "position")
    search_fields = ("employee_code", "full_name", "phone")
    ordering = ("full_name",)



@admin.register(Attendance)
class AttendanceAdmin(admin.ModelAdmin):
    form=AttendanceForm
    list_display = (
        "employee",
        "date",
        "status",
        "check_in",
        "check_out",
    )
    list_filter = ("date", "status")
    search_fields = (
        "employee__full_name",
        "employee__employee_code",
    )
    date_hierarchy = "date"

@admin.register(Payroll)
class PayrollAdmin(admin.ModelAdmin):
    # Rekap dibuat lewat alur payroll agar snapshot konsisten.
    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False

    list_display = (
        "employee",
        "month",
        "year",
        "base_salary",
        "punctual_days",
        "punctual_bonus",
        "manual_deduction",
        "net_salary",
    )

    list_filter = ("year", "month")
    search_fields = (
        "employee__full_name",
        "employee__employee_code",
    )
