import calendar
from datetime import timedelta
from decimal import Decimal, ROUND_HALF_UP
from django.core.exceptions import ValidationError
from .models import Attendance,Payroll


def money(value):
    return Decimal(value).quantize(Decimal('.01'),rounding=ROUND_HALF_UP)


def prorate(monthly,start,end):
    result=Decimal(0);current=start
    while current<=end:
        result+=monthly/Decimal(calendar.monthrange(current.year,current.month)[1])
        current+=timedelta(days=1)
    return money(result)


def check_overlap(payroll):
    start,end=payroll.period_bounds
    for other in Payroll.objects.filter(employee=payroll.employee).exclude(pk=payroll.pk):
        a,b=other.period_bounds
        if start<=b and end>=a:raise ValidationError('Periode payroll bertumpuk dengan '+other.period_label)


def snapshot_payroll(payroll):
    payroll.deduction_policy=current_deduction_policy()
    employee=payroll.employee;role=employee.role
    payroll.role_name=role.name if role else employee.position
    payroll.pay_scheme=role.pay_scheme if role else employee.pay_scheme
    payroll.daily_rate=role.daily_rate if role else employee.daily_rate
    monthly=role.base_salary if role else employee.base_salary
    payroll.monthly_salary_rate=monthly
    start,end=payroll.period_bounds
    records=Attendance.objects.filter(employee=employee,date__range=(start,end))
    for field,status in [('off_days','off'),('sick_days','sick'),('present_days','present'),('late_days','late'),('absent_days','absent'),('leave_days','leave')]:
        setattr(payroll,field,records.filter(status=status).count())
    payroll.punctual_days=records.filter(status='present',punctual=True).count()
    payroll.punctual_bonus_per_day=employee.punctual_bonus_per_day
    payroll.monthly_leave_quota=employee.monthly_leave_quota
    if payroll.pay_scheme=='daily':
        if payroll.daily_rate<=0:raise ValidationError('Tarif gaji harian belum diatur untuk jabatan/karyawan.')
        payroll.base_salary=money(payroll.daily_rate*(payroll.present_days+payroll.late_days))
        payroll.fuel_allowance=Decimal(0)
    else:
        payroll.base_salary=prorate(monthly,start,end) if payroll.start_date else monthly
        payroll.base_salary=payroll.payable_base_salary
        payroll.fuel_allowance=prorate(employee.fuel_allowance,start,end) if payroll.start_date else employee.fuel_allowance
    snapshot_attendance_details(payroll)


def attendance_review(payroll):
    start,end=payroll.period_bounds
    records={r.date:r for r in Attendance.objects.filter(employee=payroll.employee,date__range=(start,end))}
    rows=[];day=start
    while day<=end:
        record=records.get(day)
        eligible=bool(record and record.status=='present' and record.punctual)
        reason=('Belum ada absensi' if record is None else 'Memenuhi bonus' if eligible else 'Tidak ditandai tepat waktu' if record.status=='present' else 'Status bukan Masuk')
        rows.append({'date':day,'status':record.get_status_display() if record else 'Belum diisi','eligible':eligible,'reason':reason})
        day+=timedelta(days=1)
    return {'rows':rows,'current_punctual':sum(r['eligible'] for r in rows),'saved_punctual':payroll.punctual_days,'missing_days':sum(r['status']=='Belum diisi' for r in rows),'changed':sum(r['eligible'] for r in rows)!=payroll.punctual_days}


def refresh_attendance(payroll):
    if payroll.pk and payroll.payments.filter(voided=False).exists():raise ValidationError('Payroll sudah dibayar. Koreksi pencatatan pembayaran sebelum menghitung ulang.')
    # Preserve the original pay policy and rates; refresh attendance counters only.
    start,end=payroll.period_bounds
    records=Attendance.objects.filter(employee=payroll.employee,date__range=(start,end))
    for field,status in [('off_days','off'),('sick_days','sick'),('present_days','present'),('late_days','late'),('absent_days','absent'),('leave_days','leave')]:
        setattr(payroll,field,records.filter(status=status).count())
    payroll.punctual_days=records.filter(status='present',punctual=True).count()
    if payroll.pay_scheme=='daily':payroll.base_salary=money(payroll.daily_rate*(payroll.present_days+payroll.late_days))
    snapshot_attendance_details(payroll)
    if payroll.net_salary<0:raise ValidationError('Hasil hitung ulang lebih kecil dari potongan. Sesuaikan potongan terlebih dahulu; data belum disimpan.')
    payroll.save(update_fields=['off_days','sick_days','present_days','late_days','absent_days','leave_days','punctual_days','base_salary','work_branches','deduction_details','automatic_deduction','deduction_policy','monthly_salary_rate','updated_at'])


def current_deduction_policy():
    from .models import PayrollDeductionPolicy
    policy=PayrollDeductionPolicy.objects.first()
    fields=['enabled','deduct_leave','deduct_sick','deduct_absent','deduct_excess_off']
    return {**{field:bool(getattr(policy,field,False)) for field in fields},'quota_mode':policy.quota_mode if policy else 'shared','daily_amount':str(policy.daily_amount if policy else 0)}


def branch_work_summary(payroll):
    start,end=payroll.period_bounds
    rows={}
    for record in Attendance.objects.filter(employee=payroll.employee,date__range=(start,end),status__in=['present','late']).select_related('work_branch','branch'):
        branch=record.work_branch or record.branch
        row=rows.setdefault(branch.pk,{'id':branch.pk,'name':branch.name,'days':0})
        row['days']+=1
    return sorted(rows.values(),key=lambda row:row['name']) or [{'id':payroll.employee.branch_id,'name':payroll.employee.branch.name,'days':0}]


def attendance_deductions(payroll):
    policy=payroll.deduction_policy
    if payroll.pay_scheme=='daily' or not policy.get('enabled'):return []
    start,end=payroll.period_bounds
    beginning=start.replace(day=1)
    records=Attendance.objects.filter(employee=payroll.employee,date__range=(beginning,end)).order_by('date')
    used={};details=[]
    labels={'leave':'Izin','sick':'Sakit','absent':'Tidak hadir','off':'Libur melebihi jatah'}
    for record in records:
        month=(record.date.year,record.date.month)
        shared=policy.get('quota_mode','separate')=='shared'
        if record.status in (['off','leave','sick'] if shared else ['off']):used[month]=used.get(month,0)+1
        if record.date<start:continue
        status=record.status
        eligible=bool(policy.get('deduct_'+status)) if status in ['leave','sick','absent'] else bool(status=='off' and policy.get('deduct_excess_off') and used.get(month,0)>payroll.monthly_leave_quota)
        if shared and status in ['off','leave','sick']:
            eligible=used.get(month,0)>payroll.monthly_leave_quota
        if not eligible:continue
        rate=Decimal(policy.get('daily_amount','0'))
        if not rate:rate=payroll.monthly_salary_rate/Decimal(calendar.monthrange(*month)[1])
        amount=money(rate)
        details.append({'date':record.date.isoformat(),'status':status,'label':labels[status],'amount':str(amount)})
    return details


def snapshot_attendance_details(payroll):
    payroll.work_branches=branch_work_summary(payroll)
    payroll.deduction_details=attendance_deductions(payroll)
    payroll.automatic_deduction=sum((Decimal(row['amount']) for row in payroll.deduction_details),Decimal(0))
