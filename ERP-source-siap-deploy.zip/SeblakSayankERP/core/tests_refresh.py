from datetime import date
from django.test import TestCase
from django.contrib.auth import get_user_model
from django.urls import reverse
from .models import Employee,Attendance,Payroll,PayrollExtra
from .payroll_calculation import snapshot_payroll,attendance_review

class PayrollRefreshTests(TestCase):
    def setUp(self):
        self.client.force_login(get_user_model().objects.create_user('refreshowner',password='testing'))
        self.e=Employee.objects.create(employee_code='RAHMANQA',full_name='Rahman QA',position='Crew',hire_date=date(2026,1,1),base_salary=1200000,punctual_bonus_per_day=10000)
        for day in range(24,29):Attendance.objects.create(employee=self.e,date=date(2026,10,day),status='present',punctual=True)
        self.p=Payroll(employee=self.e,month=10,year=2026,start_date=date(2026,10,24),end_date=date(2026,10,30))
        snapshot_payroll(self.p);self.p.save()
    def test_exact_24_to_30_inclusive_and_refresh_stale_five(self):
        self.assertEqual(self.p.punctual_days,5)
        for day in [29,30]:Attendance.objects.create(employee=self.e,date=date(2026,10,day),status='present',punctual=True)
        review=attendance_review(self.p);self.assertEqual(len(review['rows']),7);self.assertEqual(review['current_punctual'],7);self.assertTrue(review['changed'])
        self.assertContains(self.client.get(reverse('payroll_edit',args=[self.p.pk])),'30/10/2026')
        self.e.punctual_bonus_per_day=99999;self.e.save()
        PayrollExtra.objects.create(payroll=self.p,description='Bensin',amount=200000)
        url=reverse('payroll_refresh',args=[self.p.pk])
        self.client.get(url);self.p.refresh_from_db();self.assertEqual(self.p.punctual_days,5)
        self.client.post(url,{});self.p.refresh_from_db();self.assertEqual(self.p.punctual_days,5)
        self.assertEqual(self.client.post(url,{'confirm':'on'}).status_code,302)
        self.p.refresh_from_db();self.assertEqual(self.p.punctual_days,7);self.assertEqual(self.p.punctual_bonus,70000);self.assertEqual(self.p.manual_bonus,200000)
        self.client.post(url,{'confirm':'on'});self.assertEqual(Payroll.objects.count(),1)
    def test_missing_and_unflagged_days_are_explained(self):
        Attendance.objects.filter(date=date(2026,10,24)).update(punctual=False)
        review=attendance_review(self.p)
        self.assertEqual(review['current_punctual'],4);self.assertEqual(review['missing_days'],2)
        self.assertEqual(review['rows'][0]['reason'],'Tidak ditandai tepat waktu')
    def test_daily_refresh_preserves_rate_and_negative_salary_rolls_back(self):
        self.p.pay_scheme='daily';self.p.daily_rate=50000;self.p.base_salary=250000;self.p.manual_deduction=200000;self.p.save()
        Attendance.objects.all().delete()
        self.assertEqual(self.client.post(reverse('payroll_refresh',args=[self.p.pk]),{'confirm':'on'}).status_code,200)
        self.p.refresh_from_db();self.assertEqual(self.p.present_days,5);self.assertEqual(self.p.base_salary,250000)
