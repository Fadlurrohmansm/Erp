from datetime import date
from decimal import Decimal as D
from django.test import TestCase
from django.contrib.auth import get_user_model
from django.urls import reverse
from .models import JobRole,Employee,Attendance,Payroll
from .forms import PayrollForm
from operations.reporting import summary

class WeeklyPayrollTests(TestCase):
    def setUp(self):
        self.client.force_login(get_user_model().objects.create_user('weeklyowner',password='testing'))
        self.role=JobRole.objects.create(name='Dapur',pay_scheme='daily',daily_rate=50000)
        self.e=Employee.objects.create(employee_code='W01',full_name='Tim Dapur',position='Dapur',role=self.role,hire_date=date(2026,1,1),base_salary=1200000,fuel_allowance=100000,punctual_bonus_per_day=0)
        self.data={'employee':self.e.pk,'period_type':'range','start_date':'2026-10-01','end_date':'2026-10-07','manual_deduction':0,'notes':'Minggu 1'}
        for day,status in [(1,'present'),(2,'present'),(3,'late'),(4,'sick'),(5,'leave'),(6,'off'),(7,'absent')]:
            Attendance.objects.create(employee=self.e,date=date(2026,10,day),status=status)
    def make(self,data=None):
        response=self.client.post(reverse('payroll_create'),data or self.data)
        self.assertEqual(response.status_code,302)
        return Payroll.objects.latest('id')
    def test_daily_attended_days_only_inclusive(self):
        p=self.make();self.assertEqual(p.base_salary,150000);self.assertEqual(p.net_salary,150000);self.assertEqual(p.fuel_allowance,0)
        self.assertEqual(p.role_name,'Dapur');self.assertEqual(p.period_bounds,(date(2026,10,1),date(2026,10,7)))
        self.assertContains(self.client.get(reverse('payroll_list')),'01/10/2026 - 07/10/2026')
        self.assertEqual(self.client.get(reverse('payroll_pdf',args=[p.pk])).status_code,200)
    def test_no_attendance_no_base_salary(self):
        Attendance.objects.all().delete();p=self.make();self.assertEqual(p.net_salary,0)
    def test_weekly_next_period_allowed_overlaps_blocked_monthly_blocked(self):
        self.make()
        self.assertFalse(PayrollForm({**self.data,'start_date':'2026-10-07','end_date':'2026-10-14'}).is_valid())
        self.make({**self.data,'start_date':'2026-10-08','end_date':'2026-10-14'})
        self.assertEqual(Payroll.objects.count(),2)
        self.assertFalse(PayrollForm({'employee':self.e.pk,'period_type':'monthly','month':10,'year':2026,'manual_deduction':0}).is_valid())
    def test_legacy_monthly_blocks_weekly(self):
        Payroll.objects.create(employee=self.e,month=10,year=2026,base_salary=1000)
        self.assertFalse(PayrollForm(self.data).is_valid())
    def test_monthly_prorate_and_cross_month_report_end_date(self):
        self.role.pay_scheme='monthly';self.role.base_salary=3100000;self.role.save()
        p=self.make();self.assertEqual(p.base_salary,700000)
        p.delete()
        p=self.make({**self.data,'start_date':'2026-10-30','end_date':'2026-11-02'})
        self.assertEqual(p.base_salary,D('407000'));self.assertEqual(p.month,11)
        self.assertEqual(summary(date(2026,10,1),date(2026,10,31))['payroll'],0)
        self.assertEqual(summary(date(2026,11,1),date(2026,11,30))['payroll'],p.net_salary)
    def test_edit_preserves_daily_snapshot_and_bonus_works(self):
        p=self.make();self.role.daily_rate=90000;self.role.save();Attendance.objects.all().delete()
        data={**self.data,'extras-TOTAL_FORMS':1,'extras-INITIAL_FORMS':0,'extras-0-description':'Bensin','extras-0-amount':'200000'}
        self.assertEqual(self.client.post(reverse('payroll_edit',args=[p.pk]),data).status_code,302)
        p.refresh_from_db();self.assertEqual(p.daily_rate,50000);self.assertEqual(p.base_salary,150000);self.assertEqual(p.net_salary,350000)
    def test_invalid_ranges_and_missing_rate(self):
        for override in [{'start_date':'2026-10-08'},{'start_date':''},{'end_date':'2028-10-01'},{'start_date':'2025-12-31'}]:
            self.assertFalse(PayrollForm({**self.data,**override}).is_valid())
        self.role.daily_rate=0;self.role.save()
        self.assertEqual(self.client.post(reverse('payroll_create'),self.data).status_code,200)
        self.assertFalse(Payroll.objects.exists())
    def test_roles_crud_and_delete_preserves_employee_policy(self):
        for name in ['role_list','role_create']:self.assertEqual(self.client.get(reverse(name)).status_code,200)
        self.assertEqual(self.client.post(reverse('role_create'),{'name':'Kasir','pay_scheme':'monthly','base_salary':1500000,'daily_rate':0}).status_code,302)
        self.assertEqual(self.client.post(reverse('role_edit',args=[self.role.pk]),{'name':'Tim Dapur','pay_scheme':'daily','base_salary':0,'daily_rate':60000}).status_code,302)
        url=reverse('role_delete',args=[self.role.pk]);self.client.get(url);self.assertTrue(JobRole.objects.filter(pk=self.role.pk).exists())
        self.assertEqual(self.client.post(url,{'confirm':'on'}).status_code,302)
        self.e.refresh_from_db();self.assertIsNone(self.e.role);self.assertEqual(self.e.daily_rate,60000);self.assertEqual(self.e.pay_scheme,'daily')
        self.assertEqual(Attendance.objects.count(),7);self.assertEqual(self.make().base_salary,180000)
