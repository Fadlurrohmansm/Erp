from datetime import date
from decimal import Decimal
from django.test import TestCase, Client
from django.contrib.auth import get_user_model
from django.urls import reverse
from .models import Employee, Attendance, Payroll, PayrollExtra
from operations.reporting import summary

class PayrollChangesTests(TestCase):
    def setUp(self):
        self.user=get_user_model().objects.create_user('owner', password='testing')
        self.client.force_login(self.user)
        self.e=Employee.objects.create(employee_code='NEW',full_name='Nama Tes',position='Crew',hire_date=date(2026,1,1),base_salary=1200000,fuel_allowance=100000)
        Attendance.objects.create(employee=self.e,date=date(2026,10,1),status='present',punctual=True)
        self.base={'employee':self.e.pk,'month':10,'year':2026,'manual_deduction':'0','notes':'Catatan', 'extras-TOTAL_FORMS':'2','extras-INITIAL_FORMS':'0','extras-0-description':'Bensin tambahan','extras-0-amount':'200000','extras-1-description':'Bonus target','extras-1-amount':'50000'}

    def create(self):
        self.assertEqual(self.client.post(reverse('payroll_create'),self.base).status_code,302)
        return Payroll.objects.get()

    def test_manual_bonus_total_pdf_and_monthly_report(self):
        p=self.create()
        self.assertEqual(p.manual_bonus,Decimal('250000'))
        self.assertEqual(p.net_salary,Decimal('1560000'))
        self.assertEqual(summary(date(2026,10,1),date(2026,10,31))['payroll'],Decimal('1560000'))
        self.assertContains(self.client.get(reverse('payroll_list')),'Bensin tambahan')
        self.assertEqual(self.client.get(reverse('payroll_pdf',args=[p.pk])).status_code,200)

    def test_edit_bonus_and_delete_row_keeps_snapshot(self):
        p=self.create();rows=list(p.extras.all())
        self.e.base_salary=9000000;self.e.save()
        Attendance.objects.all().delete()
        data={**self.base,'extras-INITIAL_FORMS':'2','extras-0-id':rows[0].pk,'extras-0-amount':'300000','extras-1-id':rows[1].pk,'extras-1-DELETE':'on'}
        self.assertEqual(self.client.post(reverse('payroll_edit',args=[p.pk]),data).status_code,302)
        p.refresh_from_db()
        self.assertEqual(p.manual_bonus,300000);self.assertEqual(p.base_salary,1200000);self.assertEqual(p.punctual_days,1)
        self.assertEqual(p.extras.count(),1)
        self.assertEqual(p.net_salary,1610000)

    def test_invalid_bonus_and_excessive_deduction_atomic(self):
        for overrides in [{'extras-0-amount':'-1'},{'extras-0-amount':'0'},{'extras-0-description':' '},{'manual_deduction':'99999999'}]:
            self.assertEqual(self.client.post(reverse('payroll_create'),{**self.base,**overrides}).status_code,200)
            self.assertFalse(Payroll.objects.exists());self.assertFalse(PayrollExtra.objects.exists())

    def test_deduction_can_include_manual_bonus(self):
        p_data={**self.base,'manual_deduction':'1500000'}
        self.assertEqual(self.client.post(reverse('payroll_create'),p_data).status_code,302)
        self.assertEqual(Payroll.objects.get().net_salary,60000)

    def test_missing_management_cannot_erase_existing_bonus(self):
        p=self.create()
        data={k:v for k,v in self.base.items() if not k.startswith('extras-')}
        self.assertEqual(self.client.post(reverse('payroll_edit',args=[p.pk]),data).status_code,200)
        self.assertEqual(p.extras.count(),2)

    def test_delete_payroll_confirmation_preserves_attendance_and_allows_recreate(self):
        p=self.create();url=reverse('payroll_delete',args=[p.pk])
        self.assertEqual(self.client.get(url).status_code,200)
        self.assertEqual(self.client.post(url,{}).status_code,200)
        self.assertTrue(Payroll.objects.exists())
        self.assertEqual(self.client.post(url,{'confirm':'on'}).status_code,302)
        self.assertFalse(Payroll.objects.exists());self.assertFalse(PayrollExtra.objects.exists())
        self.assertTrue(Attendance.objects.exists());self.assertTrue(Employee.objects.exists())
        self.assertEqual(summary(date(2026,10,1),date(2026,10,31))['payroll'],0)
        self.create()

    def test_employee_delete_with_dependents_only_after_confirmation(self):
        self.create()
        another=Employee.objects.create(employee_code='OTHER',full_name='Lain',position='Crew',hire_date=date(2026,1,1))
        url=reverse('employee_delete',args=[self.e.pk])
        self.assertContains(self.client.get(url),'1 absensi dan 1 payroll')
        self.client.post(url,{})
        self.assertTrue(Employee.objects.filter(pk=self.e.pk).exists())
        self.assertEqual(self.client.post(url,{'confirm':'on'}).status_code,302)
        self.assertFalse(Employee.objects.filter(pk=self.e.pk).exists())
        self.assertTrue(Employee.objects.filter(pk=another.pk).exists())
        self.assertFalse(Attendance.objects.exists());self.assertFalse(Payroll.objects.exists());self.assertFalse(PayrollExtra.objects.exists())

    def test_delete_csrf_and_auth(self):
        p=self.create()
        client=Client(enforce_csrf_checks=True);client.force_login(self.user)
        for url in [reverse('employee_delete',args=[self.e.pk]),reverse('payroll_delete',args=[p.pk])]:
            self.assertEqual(client.post(url,{'confirm':'on'}).status_code,403)
            self.client.logout();self.assertEqual(self.client.post(url,{'confirm':'on'}).status_code,302)
        self.assertTrue(Payroll.objects.exists())
