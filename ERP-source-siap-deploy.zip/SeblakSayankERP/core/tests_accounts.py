from django.test import TestCase
from django.contrib.auth import get_user_model
from django.urls import reverse

class LoginAccountTests(TestCase):
    def setUp(self):
        self.admin=get_user_model().objects.create_superuser('accountadmin',password='AdminFixture!942')
        self.client.force_login(self.admin)
    def test_create_regular_account_and_no_privilege_injection(self):
        response=self.client.post(reverse('account_create'),{'username':'newoperator','first_name':'Operator','password1':'NewFixture!56381','password2':'NewFixture!56381','is_superuser':'on','is_staff':'on'})
        self.assertEqual(response.status_code,302)
        user=get_user_model().objects.get(username='newoperator')
        self.assertTrue(user.check_password('NewFixture!56381'));self.assertFalse(user.is_superuser);self.assertFalse(user.is_staff)
        self.assertEqual(self.client.get(reverse('account_settings')).status_code,200)
    def test_nonadmin_cannot_create_accounts(self):
        operator=get_user_model().objects.create_user('ordinary',password='Fixture!935')
        self.client.force_login(operator)
        response=self.client.post(reverse('account_create'),{'username':'forbidden','password1':'NewFixture!56381','password2':'NewFixture!56381'})
        self.assertEqual(response.status_code,403);self.assertFalse(get_user_model().objects.filter(username='forbidden').exists())
        self.assertNotContains(self.client.get(reverse('account_settings')),'Buat akun login baru')
    def test_password_change_requires_old_and_keeps_current_session(self):
        url=reverse('account_password_change')
        response=self.client.post(url,{'old_password':'wrong','new_password1':'ChangedFixture!94831','new_password2':'ChangedFixture!94831'})
        self.assertEqual(response.status_code,200);self.admin.refresh_from_db();self.assertTrue(self.admin.check_password('AdminFixture!942'))
        response=self.client.post(url,{'old_password':'AdminFixture!942','new_password1':'ChangedFixture!94831','new_password2':'ChangedFixture!94831'})
        self.assertEqual(response.status_code,302);self.admin.refresh_from_db();self.assertTrue(self.admin.check_password('ChangedFixture!94831'))
        self.assertEqual(self.client.get(reverse('account_settings')).status_code,200)
    def test_password_validation_and_auth_required(self):
        response=self.client.post(reverse('account_create'),{'username':'bad','password1':'123','password2':'123'})
        self.assertEqual(response.status_code,200);self.assertFalse(get_user_model().objects.filter(username='bad').exists())
        self.client.logout()
        for name in ['account_settings','account_password_change']:self.assertEqual(self.client.get(reverse(name)).status_code,302)
