from datetime import date
from django.test import TestCase
from django.contrib.auth import get_user_model
from django.urls import reverse
from .models import Employee
from .forms import EmployeeForm
class EmployeeAttendanceUITests(TestCase):
    def setUp(self):
        self.client.force_login(get_user_model().objects.create_user('uitester',password='testing'))
        self.e=Employee.objects.create(employee_code='UI01',full_name='Tim UI',position='Crew',hire_date=date(2026,1,1),fuel_allowance=100000)
    def test_fuel_field_removed_but_existing_value_preserved(self):
        self.assertNotIn('fuel_allowance',EmployeeForm().fields)
        response=self.client.get(reverse('employee_edit',args=[self.e.pk]))
        self.assertNotContains(response,'name="fuel_allowance"')
        data=dict(employee_code='UI01',full_name='Tim UI',position='Crew',hire_date='2026-01-01',base_salary='1200000',monthly_leave_quota=2,punctual_bonus_per_day=10000,status='active',fuel_allowance=999999)
        self.assertEqual(self.client.post(reverse('employee_edit',args=[self.e.pk]),data).status_code,302)
        self.e.refresh_from_db();self.assertEqual(self.e.fuel_allowance,100000)
    def test_calendar_days_have_progressive_enhancement_hook(self):
        response=self.client.get(reverse('attendance_list')+f'?employee={self.e.pk}&month=2026-10&day=26')
        self.assertContains(response,'data-attendance-date')
        self.assertContains(response,'value="2026-10-26"')
