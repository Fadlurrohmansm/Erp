from datetime import date
from decimal import Decimal
from django.test import TestCase
from django.contrib.auth import get_user_model
from django.urls import reverse
from tenancy.models import Branch
from .models import Employee,Attendance,Payroll,PayrollDeductionPolicy
from .payroll_calculation import snapshot_payroll,refresh_attendance

class AutomaticDeductionTests(TestCase):
    def setUp(self):
        self.user=get_user_model().objects.create_user('deduct',password='testing');self.client.force_login(self.user)
        self.employee=Employee.objects.create(employee_code='AD',full_name='Tim Potongan',position='Crew',hire_date=date(2026,1,1),base_salary=1550000,monthly_leave_quota=2)
        self.a=self.employee.branch;self.b=Branch.objects.create(name='Cabang B')
        self.policy=PayrollDeductionPolicy.objects.create(enabled=True,daily_amount=50000,quota_mode='separate')
    def payroll(self,start=date(2026,10,24),end=date(2026,10,30)):
        p=Payroll(employee=self.employee,month=end.month,year=end.year,start_date=start,end_date=end)
        snapshot_payroll(p);return p
    def attendance(self,day,status,branch=None):
        return Attendance.objects.create(employee=self.employee,date=day,status=status,work_branch=branch)
    def test_weekly_uses_monthly_off_quota_and_each_selected_status(self):
        for day in [1,2,24]:self.attendance(date(2026,10,day),'off')
        for day,status in [(25,'leave'),(26,'sick'),(27,'absent'),(28,'present')]:self.attendance(date(2026,10,day),status,self.a)
        for day in [29,30]:self.attendance(date(2026,10,day),'present',self.b)
        p=self.payroll();self.assertEqual(p.automatic_deduction,150000)
        self.assertEqual([r['status'] for r in p.deduction_details],['off','leave','absent'])
        p.save();self.assertEqual(sum(r['days'] for r in p.branch_work_rows),3)
        response=self.client.get(reverse('payroll_preview',args=[p.pk]));self.assertContains(response,'Cabang B: 2 hari');self.assertContains(response,'Potongan izin')
        self.assertEqual(self.client.get(reverse('payroll_pdf',args=[p.pk])).status_code,200)
        self.policy.deduct_leave=False;self.policy.save();refresh_attendance(p)
        self.assertEqual(p.automatic_deduction,150000)
        self.client.post(reverse('payroll_refresh',args=[p.pk]),{'confirm':'on','apply_current_policy':'on'})
        p.refresh_from_db();self.assertEqual(p.automatic_deduction,100000)
    def test_month_reset_and_calendar_rate(self):
        self.policy.daily_amount=0;self.policy.save()
        for d in [date(2026,10,1),date(2026,10,2),date(2026,10,26),date(2026,11,1),date(2026,11,2),date(2026,11,3)]:self.attendance(d,'off')
        p=self.payroll(date(2026,10,25),date(2026,11,7))
        self.assertEqual(p.automatic_deduction,Decimal('101666.67'))
        self.assertEqual(len(p.deduction_details),2)
    def test_daily_no_double_deduction_and_single_branch_name(self):
        self.employee.pay_scheme='daily';self.employee.daily_rate=50000;self.employee.save()
        self.attendance(date(2026,10,24),'present',self.b);self.attendance(date(2026,10,25),'absent')
        p=self.payroll();self.assertEqual(p.base_salary,50000);self.assertEqual(p.automatic_deduction,0);p.save()
        response=self.client.get(reverse('payroll_preview',args=[p.pk]))
        self.assertContains(response,'Cabang B');self.assertNotContains(response,'Cabang B: 1 hari')
    def test_legacy_unchanged_until_explicit_policy_apply(self):
        p=Payroll.objects.create(employee=self.employee,month=10,year=2026,base_salary=1550000)
        self.attendance(date(2026,10,25),'leave')
        refresh_attendance(p);self.assertEqual(p.automatic_deduction,0)
        self.client.post(reverse('payroll_refresh',args=[p.pk]),{'confirm':'on','apply_current_policy':'on'})
        p.refresh_from_db();self.assertEqual(p.automatic_deduction,50000)
    def test_negative_net_rejected_atomically(self):
        self.attendance(date(2026,10,24),'leave')
        p=Payroll.objects.create(employee=self.employee,month=10,year=2026,start_date=date(2026,10,24),end_date=date(2026,10,24),base_salary=10000,monthly_salary_rate=1550000)
        response=self.client.post(reverse('payroll_refresh',args=[p.pk]),{'confirm':'on','apply_current_policy':'on'})
        self.assertEqual(response.status_code,200);p.refresh_from_db();self.assertEqual(p.automatic_deduction,0);self.assertEqual(p.deduction_policy,{})

    def test_shared_quota_two_off_then_sick_leave_charged(self):
        self.policy.quota_mode='shared';self.policy.save()
        for day,status in [(1,'off'),(2,'off'),(24,'sick'),(25,'leave')]:self.attendance(date(2026,10,day),status)
        p=self.payroll();self.assertEqual(p.automatic_deduction,100000)
        self.assertEqual([r['status'] for r in p.deduction_details],['sick','leave'])
        p.save()
        response=self.client.get(reverse('attendance_list'),{'employee':self.employee.pk,'month':'2026-10'})
        self.assertEqual(response.context['off_days'],4);self.assertEqual(response.context['remaining_leave'],0);self.assertEqual(response.context['excess_leave'],2)
    def test_shared_quota_first_two_sick_leave_are_paid_then_off_charged(self):
        self.policy.quota_mode='shared';self.policy.save()
        for day,status in [(24,'sick'),(25,'leave'),(26,'off')]:self.attendance(date(2026,10,day),status)
        p=self.payroll();self.assertEqual(p.automatic_deduction,50000)
        self.assertEqual([r['status'] for r in p.deduction_details],['off'])
        self.assertEqual(p.quota_used_days,3)
    def test_shared_quota_resets_next_month(self):
        self.policy.quota_mode='shared';self.policy.save()
        for day,status in [(date(2026,10,1),'off'),(date(2026,10,2),'off'),(date(2026,10,26),'leave'),(date(2026,11,1),'sick'),(date(2026,11,2),'leave'),(date(2026,11,3),'off')]:self.attendance(day,status)
        p=self.payroll(date(2026,10,25),date(2026,11,7))
        self.assertEqual(p.automatic_deduction,100000)
        self.assertEqual([r['date'] for r in p.deduction_details],['2026-10-26','2026-11-03'])
