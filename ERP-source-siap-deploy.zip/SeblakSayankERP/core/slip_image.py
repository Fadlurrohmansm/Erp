"""Render the complete PDF slip into one printable PNG, without external executables."""
from io import BytesIO


def pdf_to_png(pdf_bytes):
    import pypdfium2 as pdfium
    from PIL import Image

    pages = []
    try:
        with pdfium.PdfDocument(pdf_bytes) as document:
            for index in range(len(document)):
                page = document[index]
                try:
                    bitmap = page.render(scale=2)
                    try:
                        pages.append(bitmap.to_pil().convert('RGB'))
                    finally:
                        bitmap.close()
                finally:
                    page.close()
        width = max(page.width for page in pages)
        height = sum(page.height for page in pages)
        with Image.new('RGB', (width, height), 'white') as combined:
            top = 0
            for page in pages:
                combined.paste(page, ((width - page.width) // 2, top))
                top += page.height
            output = BytesIO()
            combined.save(output, format='PNG', dpi=(144, 144))
            return output.getvalue()
    finally:
        for page in pages:
            page.close()
