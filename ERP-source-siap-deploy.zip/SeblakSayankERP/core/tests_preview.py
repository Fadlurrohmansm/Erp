from datetime import date
from django.test import TestCase
from django.contrib.auth import get_user_model
from django.urls import reverse
from .models import Employee,Payroll,PayrollExtra
class PayrollPreviewTests(TestCase):
    def setUp(self):
        self.client.force_login(get_user_model().objects.create_user('previewowner',password='testing'))
        e=Employee.objects.create(employee_code='PREV',full_name='Tim Contoh',position='Dapur',hire_date=date(2026,1,1))
        self.p=Payroll.objects.create(employee=e,month=10,year=2026,start_date=date(2026,10,24),end_date=date(2026,10,30),base_salary=300000,punctual_days=7,punctual_bonus_per_day=10000)
        PayrollExtra.objects.create(payroll=self.p,description='<script>test</script> bensin',amount=200000)
    def test_preview_saved_totals_and_no_writes(self):
        response=self.client.get(reverse('payroll_preview',args=[self.p.pk]))
        self.assertContains(response,'Rp570.000');self.assertContains(response,'7 hari');self.assertContains(response,'24/10/2026 - 30/10/2026')
        self.assertContains(response,'&lt;script&gt;test&lt;/script&gt;');self.assertNotContains(response,'<script>test</script>')
        self.assertEqual(response['Cache-Control'],'private, no-store');self.assertEqual(Payroll.objects.count(),1)
    def test_inline_pdf_and_download(self):
        url=reverse('payroll_pdf',args=[self.p.pk])
        for suffix,prefix in [('', 'attachment'),('?inline=1','inline')]:
            response=self.client.get(url+suffix)
            self.assertEqual(response['Content-Type'],'application/pdf');self.assertTrue(response.content.startswith(b'%PDF'));self.assertTrue(response['Content-Disposition'].startswith(prefix))
    def test_auth_and_unknown(self):
        self.assertEqual(self.client.get(reverse('payroll_preview',args=[999999])).status_code,404)
        self.client.logout();self.assertEqual(self.client.get(reverse('payroll_preview',args=[self.p.pk])).status_code,302)

    def test_png_download(self):
        from io import BytesIO
        from PIL import Image
        response = self.client.get(reverse('payroll_pdf', args=[self.p.pk]) + '?format=png')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response['Content-Type'], 'image/png')
        self.assertEqual(response['Content-Disposition'], 'attachment; filename="slipgaji_tim_contoh_30_oktober.png"')
        self.assertEqual(response['Cache-Control'], 'private, no-store')
        with Image.open(BytesIO(response.content)) as image:
            self.assertEqual(image.format, 'PNG')
            self.assertGreater(image.width, 1100)
            self.assertGreater(image.height, 1600)

    def test_png_multiple_pages(self):
        from io import BytesIO
        from reportlab.pdfgen import canvas
        from PIL import Image
        from .slip_image import pdf_to_png
        source = BytesIO()
        doc = canvas.Canvas(source, pagesize=(100, 150))
        for text in ['One', 'Two']:
            doc.drawString(10, 50, text)
            doc.showPage()
        doc.save()
        with Image.open(BytesIO(pdf_to_png(source.getvalue()))) as image:
            self.assertEqual(image.size, (200, 600))
