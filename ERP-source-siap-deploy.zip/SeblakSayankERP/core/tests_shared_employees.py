from datetime import date
from django.test import TestCase
from django.contrib.auth import get_user_model
from django.urls import reverse
from django import forms
from tenancy.models import Branch
from tenancy.scope import current_branch
from tenancy.forms import ScopedForm
from .models import Employee,Attendance,EmployeeBranchAccess,Payroll
from .employee_import import import_employees
from .forms import AttendanceForm
from django.core.exceptions import ValidationError

class SharedEmployeeTests(TestCase):
    def setUp(self):
        self.user=get_user_model().objects.create_user('sharedpeople',password='testing');self.client.force_login(self.user)
        self.a=Branch.objects.first();self.b=Branch.objects.create(name='Cabang B');self.c=Branch.objects.create(name='Cabang C')
        self.e=Employee.objects.create(employee_code='SH1',full_name='Rahman Bersama',position='Crew',hire_date=date(2026,1,1),base_salary=1500000)
        self.record=Attendance.objects.create(employee=self.e,date=date(2026,10,24),status='present',punctual=True,work_branch=self.a)
    def switch(self,branch):self.client.post(reverse('branch_switch'),{'branch_id':branch.pk})
    def test_import_uses_same_employee_and_attendance_bidirectionally(self):
        self.switch(self.b)
        response=self.client.post(reverse('employee_import_branch'),{'source':self.a.pk,'employees':[self.e.pk],'confirm':'on'})
        self.assertEqual(response.status_code,302);self.assertEqual(Employee._base_manager.count(),1);self.assertEqual(Attendance._base_manager.count(),1)
        response=self.client.get(reverse('employee_list'));self.assertContains(response,'Rahman Bersama');self.assertContains(response,'Absensi tersinkron')
        self.assertContains(self.client.get(reverse('attendance_list'),{'employee':self.e.pk,'month':'2026-10'}),'Tepat waktu')
        self.client.post(reverse('attendance_list')+f'?month=2026-10&employee={self.e.pk}',{'employee':self.e.pk,'date':'2026-10-24','status':'sick','punctual':'no','notes':'Diedit dari B'})
        self.record.refresh_from_db();self.assertEqual(self.record.status,'sick');self.assertEqual(self.record.branch,self.a)
        self.switch(self.a)
        self.assertContains(self.client.get(reverse('attendance_list'),{'employee':self.e.pk,'month':'2026-10','day':24}),'Diedit dari B')
        self.client.post(reverse('attendance_edit',args=[self.record.pk]),{'employee':self.e.pk,'date':'2026-10-24','status':'present','punctual':True,'work_branch':self.c.pk,'notes':'Balik dari A'})
        self.switch(self.b);self.assertContains(self.client.get(reverse('attendance_list'),{'employee':self.e.pk,'month':'2026-10','day':24}),'Balik dari A')
        self.assertEqual(Attendance._base_manager.count(),1)
    def test_no_access_without_link_and_import_is_idempotent(self):
        self.switch(self.b);self.assertNotContains(self.client.get(reverse('employee_list')),'Rahman Bersama')
        self.assertEqual(self.client.get(reverse('attendance_edit',args=[self.record.pk])).status_code,404)
        self.assertEqual(import_employees(self.a.pk,self.b.pk,[self.e.pk]),(1,0))
        self.assertEqual(import_employees(self.a.pk,self.b.pk,[self.e.pk]),(0,1))
        self.assertEqual(EmployeeBranchAccess.objects.count(),1)
    def test_multiple_branches_never_duplicate_dashboard_attendance(self):
        import_employees(self.a.pk,self.b.pk,[self.e.pk]);import_employees(self.a.pk,self.c.pk,[self.e.pk])
        for branch in [self.a,self.b,self.c]:
            self.switch(branch)
            response=self.client.get(reverse('dashboard'),{'attendance_month':'2026-10'})
            self.assertEqual(response.context['attendance_rows'][0]['present'],1)
    def test_payroll_and_master_changes_only_home_branch(self):
        import_employees(self.a.pk,self.b.pk,[self.e.pk]);self.switch(self.b)
        response=self.client.post(reverse('payroll_create'),{'employee':self.e.pk,'period_type':'range','start_date':'2026-10-24','end_date':'2026-10-30','manual_deduction':0})
        self.assertEqual(response.status_code,200);self.assertFalse(Payroll.objects.exists());self.assertContains(response,'cabang asal')
        self.client.post(reverse('employee_delete',args=[self.e.pk]),{'confirm':'on'});self.assertTrue(Employee._base_manager.filter(pk=self.e.pk).exists())
        self.switch(self.a);self.client.post(reverse('employee_delete',args=[self.e.pk]),{'confirm':'on'});self.assertTrue(Employee._base_manager.filter(pk=self.e.pk).exists())
    def test_conflicting_code_does_not_merge_or_partially_import(self):
        other=Employee.objects.create(branch=self.b,employee_code='SH1',full_name='Orang berbeda',position='Crew',hire_date=date(2026,1,1))
        with self.assertRaises(ValidationError):import_employees(self.a.pk,self.b.pk,[self.e.pk])
        self.assertFalse(EmployeeBranchAccess.objects.exists());self.assertEqual(Employee._base_manager.count(),2)
    def test_frozen_employee_choices_refresh_visibility(self):
        import_employees(self.a.pk,self.b.pk,[self.e.pk])
        token=current_branch.set(self.a.pk)
        class Reused(ScopedForm):employee=forms.ModelChoiceField(queryset=Employee.objects.filter(status='active'))
        current_branch.reset(token)
        token=current_branch.set(self.b.pk)
        try:self.assertTrue(Reused().fields['employee'].queryset.filter(pk=self.e.pk).exists())
        finally:current_branch.reset(token)
