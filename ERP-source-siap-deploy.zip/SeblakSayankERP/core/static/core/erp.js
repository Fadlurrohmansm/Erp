'use strict';
const section = document.querySelector('.app')?.dataset.section || '';
document.querySelectorAll('[data-nav]').forEach(el => {if(el.dataset.nav.split(' ').some(prefix=>section===prefix || section.startsWith(prefix+'_')))el.classList.add('active');});
const navToggle = document.getElementById('nav-toggle');
function closeNav(){document.getElementById('sidebar')?.classList.remove('open');document.body.classList.remove('nav-open');navToggle?.setAttribute('aria-expanded','false');}
navToggle?.addEventListener('click',()=>{const open=document.getElementById('sidebar').classList.toggle('open');document.body.classList.toggle('nav-open',open);navToggle.setAttribute('aria-expanded',String(open));});
document.getElementById('nav-shade')?.addEventListener('click',closeNav);
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeNav();});
document.querySelectorAll('[data-confirm]').forEach(form=>form.addEventListener('submit',e=>{if(!window.confirm(form.dataset.confirm))e.preventDefault();}));
const rupiah = value => new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',minimumFractionDigits:0,maximumFractionDigits:2}).format(value);
const priceData = document.getElementById('product-prices');
const prices = priceData ? JSON.parse(priceData.textContent) : {};
const ratesData = document.getElementById('channel-rates');
const rates = ratesData ? JSON.parse(ratesData.textContent) : {};
function updateSale(){
 if(!priceData)return;
 let subtotal=0; document.querySelectorAll('.sale-row').forEach(row=>{if(row.querySelector('[name$="-DELETE"]')?.checked)return;const qty=Number(row.querySelector('[name$="-quantity"]')?.value)||0;const price=Number(row.querySelector('[name$="-unit_price"]')?.value)||0;subtotal+=qty*price;});
 const channel=document.getElementById('id_channel')?.value;const rate=rates[channel]||{voucher:0,commission:0};const voucher=Math.round(subtotal*Number(rate.voucher)/100*100)/100;const commission=Math.round((subtotal-voucher)*Number(rate.commission)/100*100)/100;
 for(const [id,value] of Object.entries({'preview-subtotal':subtotal,'preview-voucher':voucher,'preview-commission':commission,'preview-net':subtotal-voucher-commission})){const el=document.getElementById(id);if(el)el.textContent=rupiah(value);}
 const formula=document.getElementById('channel-formula');if(formula)formula.textContent=`Subsidi voucher ${rate.voucher}% · Komisi ${rate.commission}% setelah voucher`;
}
function bindRows(container){container.querySelectorAll('.sale-row select[name$="-product"]').forEach(select=>{if(select.dataset.bound)return;select.dataset.bound='1';select.addEventListener('change',()=>{const field=select.closest('.sale-row').querySelector('[name$="-unit_price"]');field.value=prices[select.value]||'';updateSale();});});}
document.querySelectorAll('[data-add-row]').forEach(button=>button.addEventListener('click',()=>{const prefix=button.dataset.addRow;const total=document.getElementById(`id_${prefix}-TOTAL_FORMS`);if(Number(total.value)>=100)return;const template=document.getElementById(`${prefix}-empty`);const container=document.getElementById(`${prefix}-rows`);container.insertAdjacentHTML('beforeend',template.innerHTML.replaceAll('__prefix__',total.value));total.value=Number(total.value)+1;bindRows(container);updateSale();}));
document.addEventListener('input',updateSale);document.addEventListener('change',e=>{if(e.target.matches('[name$="-DELETE"]'))e.target.closest('.recipe-row,.sale-row')?.classList.toggle('deleted',e.target.checked);updateSale();});
bindRows(document);updateSale();
document.querySelectorAll('[data-print]').forEach(btn=>btn.addEventListener('click',()=>window.print()));

// Selecting an attendance date preserves the current viewport.
(function(){
 if(!document.querySelector('.calendar-layout'))return;
 const key='attendance-scroll:'+location.pathname;
 function remember(){try{sessionStorage.setItem(key,JSON.stringify({y:window.scrollY,time:Date.now()}));}catch(_){}}
 try{const saved=JSON.parse(sessionStorage.getItem(key)||'null');sessionStorage.removeItem(key);if(saved&&Date.now()-saved.time<30000)requestAnimationFrame(()=>window.scrollTo({top:saved.y,behavior:'instant'}));}catch(_){}
 let controller;
 document.addEventListener('click',async function(event){
  const link=event.target.closest('a[data-attendance-date],a[data-attendance-month]');
  if(!link||event.button!==0||event.ctrlKey||event.metaKey||event.shiftKey||event.altKey)return;
  event.preventDefault();
  const url=new URL(link.href,location.href),y=window.scrollY;
  controller?.abort();const current=new AbortController();controller=current;
  document.querySelector('.calendar-layout')?.setAttribute('aria-busy','true');
  try{
   const response=await fetch(url,{signal:current.signal,credentials:'same-origin'});
   if(!response.ok||response.redirected)throw new Error('reload');
   const html=new DOMParser().parseFromString(await response.text(),'text/html');
   if(current.signal.aborted)return;
   const next=html.querySelector('.calendar-layout'),previous=document.querySelector('.calendar-layout');
   if(!next||!previous)throw new Error('reload');
   const checkedDates=new Set(Array.from(previous.querySelectorAll('[data-attendance-check]:checked'),input=>input.value));
   previous.replaceWith(next);history.replaceState(null,'',url);
   const filters=html.querySelector('.attendance-filters');
   if(filters)document.querySelector('.attendance-filters')?.replaceWith(filters);
   next.querySelectorAll('[data-attendance-check]').forEach(input=>input.checked=checkedDates.has(input.value));
   updateAttendanceSelection();
   next.querySelector('td.selected a')?.focus({preventScroll:true});
   window.scrollTo({top:y,behavior:'instant'});
  }catch(error){if(error.name!=='AbortError'){remember();location.assign(url);}}
  finally{if(controller===current)document.querySelector('.calendar-layout')?.removeAttribute('aria-busy');}
 });
 document.addEventListener('submit',function(event){if(event.target.matches('.calendar-layout form[method="post"],.attendance-filters form'))remember();});
})();

// Keep menu choices across pagination/filtering in the same tab and active branch.
(function menuCategorySelection(){
 const form=document.getElementById('menu-category-form');
 if(!form)return;
 const key=form.dataset.selectionKey;
 const boxes=Array.from(form.querySelectorAll('input[name="selected"]'));
 let chosen={};
 const read=()=>{
  try{
   const value=JSON.parse(sessionStorage.getItem(key)||'{}');
   if(value && typeof value==='object' && !Array.isArray(value)){
    return Object.fromEntries(Object.entries(value).filter(([id,name])=>/^\d+$/.test(id)&&typeof name==='string').slice(0,5000));
   }
  }catch(error){}
  return {};
 };
 const save=()=>{try{sessionStorage.setItem(key,JSON.stringify(chosen));}catch(error){}};
 const render=()=>{
  boxes.forEach(box=>{box.checked=Object.hasOwn(chosen,box.value);});
  form.querySelector('#menu-selected-all').value=JSON.stringify(Object.keys(chosen));
  form.querySelector('#menu-selection-count').textContent=String(Object.keys(chosen).length);
  const list=form.querySelector('#menu-selection-names');
  list.replaceChildren();
  Object.entries(chosen).forEach(([id,name])=>{const li=document.createElement('li');li.textContent=name;list.appendChild(li);});
  form.querySelectorAll('[data-select-category]').forEach(toggle=>{
   const group=Array.from(toggle.closest('.menu-category-card').querySelectorAll('input[name="selected"]'));
   const checked=group.filter(box=>box.checked).length;
   toggle.checked=group.length>0 && checked===group.length;
   toggle.indeterminate=checked>0 && checked<group.length;
  });
 };
 const update=(box)=>{if(box.checked)chosen[box.value]=box.dataset.productName;else delete chosen[box.value];};
 if(form.dataset.clearSelection==='yes'){try{sessionStorage.removeItem(key);}catch(error){}}
 chosen=read();render();
 boxes.forEach(box=>box.addEventListener('change',()=>{update(box);save();render();}));
 form.querySelectorAll('[data-select-category]').forEach(toggle=>toggle.addEventListener('change',()=>{
  toggle.closest('.menu-category-card').querySelectorAll('input[name="selected"]').forEach(box=>{box.checked=toggle.checked;update(box);});
  save();render();
 }));
 form.querySelector('#menu-selection-clear').addEventListener('click',()=>{chosen={};save();render();});
 form.addEventListener('submit',()=>{boxes.forEach(update);save();form.querySelector('#menu-selected-all').value=JSON.stringify(Object.keys(chosen));});
 window.addEventListener('pageshow',()=>{chosen=read();render();});
})();

(function menuLayoutControls(){
 const form=document.getElementById('menu-layout-form');if(!form)return;
 const all=form.querySelector('[name="show_all"]');
 const choices=form.querySelectorAll('[name="visible_categories"],[name="show_uncategorized"]');
 const update=()=>choices.forEach(input=>{input.disabled=all.checked;});
 all.addEventListener('change',update);update();
})();

(function actionConfirmation(){
 const dialog=document.getElementById('action-confirm-dialog');if(!dialog||!dialog.showModal)return;
 const content=document.getElementById('action-confirm-content'),title=document.getElementById('action-confirm-title');
 let controller,opener;
 dialog.querySelector('[data-close-action-dialog]').addEventListener('click',()=>dialog.close());
 dialog.addEventListener('close',()=>{controller?.abort();opener?.focus();});
 async function openConfirmation(url,trigger,options={}){
  opener=trigger;controller?.abort();controller=new AbortController();
  title.textContent='Konfirmasi';content.textContent='Memuat rincian…';dialog.showModal();
  try{
   const response=await fetch(url.href,{...options,credentials:'same-origin',signal:controller.signal});
   if(!response.ok||new URL(response.url).pathname!==url.pathname){dialog.close();location.assign(response.redirected?response.url:location.href);return;}
   const doc=new DOMParser().parseFromString(await response.text(),'text/html');
   const form=doc.querySelector('#main-content form[method="post"]');
   if(!form)throw new Error('Form tidak ditemukan');
   title.textContent=doc.querySelector('.page-heading h1')?.textContent||'Konfirmasi';
   const info=doc.querySelector('#main-content .info-banner')?.textContent||doc.querySelector('#main-content .form-heading p')?.textContent||'';
   const objectName=doc.querySelector('.page-heading p:not(.eyebrow):not(.subtext)')?.textContent||doc.querySelector('.page-heading .subtext')?.textContent||'';
   const description=document.createElement('p');description.className='action-dialog-description';description.textContent=[objectName,info].filter(Boolean).join(' — ');
   const confirm=form.querySelector('[name="confirm"]');
   if(confirm){const field=confirm.closest('.field');if(field)field.remove();else confirm.remove();const hidden=document.createElement('input');hidden.type='hidden';hidden.name='confirm';hidden.value='on';form.appendChild(hidden);}
   form.action=url.href;
   form.querySelectorAll('a').forEach(a=>{if(['Batal','Kembali'].includes(a.textContent.trim()))a.addEventListener('click',e=>{e.preventDefault();dialog.close();});});
   form.addEventListener('submit',()=>form.querySelectorAll('button[type="submit"],button:not([type])').forEach(b=>{b.disabled=true;}));
   content.replaceChildren(description,form);
  }catch(error){if(error.name!=='AbortError'){title.textContent='Konfirmasi belum dapat dibuka';content.textContent='Muat ulang halaman lalu coba lagi. Belum ada data yang dihapus.';}}
 }
 document.addEventListener('click',event=>{
  const bulk=event.target.closest('[data-bulk-delete-url]');
  if(bulk){
   const form=document.getElementById('menu-category-form');
   const ids=form.querySelector('#menu-selected-all').value;
   if(!ids||ids==='[]'){window.alert('Centang minimal satu menu terlebih dahulu.');return;}
   const body=new FormData();
   ['csrfmiddlewaretoken','_branch_id'].forEach(name=>body.set(name,form.querySelector('[name="'+name+'"]').value));
   body.set('selected_all',ids);body.set('preview','on');
   openConfirmation(new URL(bulk.dataset.bulkDeleteUrl,location.href),bulk,{method:'POST',body});return;
  }
  const link=event.target.closest('a[href]');
  if(!link||event.ctrlKey||event.metaKey||event.shiftKey||event.altKey||event.button!==0)return;
  const url=new URL(link.href,location.href);
  if(url.origin!==location.origin||!(/\/(delete|cancel)\/$/).test(url.pathname))return;
  event.preventDefault();openConfirmation(url,link);
 });
})();

(function reportPeriodControls(){
 const mode=document.getElementById('report-mode');if(!mode)return;
 const update=()=>document.querySelectorAll('[data-report-period]').forEach(label=>{label.hidden=label.dataset.reportPeriod!==mode.value;});
 mode.addEventListener('change',update);update();
})();

(function quotaPolicyControls(){
 const mode=document.getElementById('id_quota_mode');if(!mode)return;
 const update=()=>['deduct_leave','deduct_sick','deduct_excess_off'].forEach(name=>{
  const field=document.getElementById('id_'+name)?.closest('.field');if(field)field.hidden=mode.value==='shared';
 });mode.addEventListener('change',update);update();
})();

// Delegated handlers also work after the calendar is replaced without a page jump.
function updateAttendanceSelection(){
 const dates=Array.from(document.querySelectorAll('[data-attendance-check]'));
 const count=dates.filter(input=>input.checked).length;
 const all=document.querySelector('[data-attendance-all]');
 if(all){all.checked=dates.length>0&&count===dates.length;all.indeterminate=count>0&&count<dates.length;}
 const label=document.querySelector('[data-attendance-count]');
 const button=document.querySelector('[data-attendance-save]');
 if(label)label.textContent=count+' tanggal dipilih';
 if(button)button.textContent=count?'Simpan '+count+' tanggal':'Simpan kehadiran';
}
document.addEventListener('change',event=>{
 if(event.target.matches('[data-attendance-all]')){
  document.querySelectorAll('[data-attendance-check]').forEach(input=>input.checked=event.target.checked);
  updateAttendanceSelection();
 }
 if(event.target.matches('[data-attendance-check]'))updateAttendanceSelection();
});
document.addEventListener('click',event=>{
 if(!event.target.closest('[data-attendance-clear]'))return;
 document.querySelectorAll('[data-attendance-check]').forEach(input=>input.checked=false);
 updateAttendanceSelection();
});

// Dashboard period filters keep the viewport at the section being inspected.
(function dashboardFilterScroll(){
 if(!document.querySelector('.dashboard-heading'))return;
 const key='erp-dashboard-scroll:'+location.pathname;
 function remember(){
  try{sessionStorage.setItem(key,JSON.stringify({y:window.scrollY,time:Date.now()}));}catch(_){}
 }
 try{
  const saved=JSON.parse(sessionStorage.getItem(key)||'null');
  sessionStorage.removeItem(key);
  if(saved&&Number.isFinite(saved.y)&&Date.now()-saved.time<30000){
   const restore=()=>requestAnimationFrame(()=>window.scrollTo({top:saved.y,behavior:'instant'}));
   restore();
   if(document.readyState!=='complete')window.addEventListener('load',restore,{once:true});
  }
 }catch(_){}
 document.addEventListener('submit',event=>{
  if(event.target.matches('form.dashboard-filter'))remember();
 });
 // Capture also covers the attendance "Sejak awal" button using form.submit().
 document.addEventListener('click',event=>{
  if(event.target.closest('form.dashboard-filter button'))remember();
 },true);
})();

// Drag over dates to select a contiguous range; a regular click still opens a day.
(function attendanceDragSelection(){
 let gesture=null,suppressClick=false;
 function finish(){
  gesture=null;document.body.classList.remove('attendance-dragging');
 }
 document.addEventListener('pointerdown',event=>{
  if(event.button!==0||event.pointerType==='touch'||event.ctrlKey||event.metaKey)return;
  if(event.target.closest('.attendance-date-check'))return;
  const cell=event.target.closest('.calendar td');
  const input=cell?.querySelector('[data-attendance-check]');
  if(!input)return;
  const dates=Array.from(cell.closest('.calendar').querySelectorAll('[data-attendance-check]'));
  gesture={id:event.pointerId,x:event.clientX,y:event.clientY,dates,start:dates.indexOf(input),baseline:dates.map(item=>item.checked),value:!input.checked,active:false};
 });
 document.addEventListener('pointermove',event=>{
  if(!gesture||event.pointerId!==gesture.id)return;
  if(!gesture.active&&Math.hypot(event.clientX-gesture.x,event.clientY-gesture.y)<6)return;
  const cell=document.elementFromPoint(event.clientX,event.clientY)?.closest('.calendar td');
  const input=cell?.querySelector('[data-attendance-check]');
  const end=gesture.dates.indexOf(input);
  if(end<0)return;
  gesture.active=true;document.body.classList.add('attendance-dragging');
  const low=Math.min(gesture.start,end),high=Math.max(gesture.start,end);
  gesture.dates.forEach((item,index)=>item.checked=index>=low&&index<=high?gesture.value:gesture.baseline[index]);
  updateAttendanceSelection();event.preventDefault();
 },{passive:false});
 document.addEventListener('pointerup',event=>{
  if(!gesture||event.pointerId!==gesture.id)return;
  suppressClick=gesture.active;
  if(suppressClick){event.preventDefault();setTimeout(()=>suppressClick=false,0);}
  finish();
 });
 document.addEventListener('click',event=>{
  if(!suppressClick)return;
  event.preventDefault();event.stopImmediatePropagation();suppressClick=false;
 },true);
 document.addEventListener('dragstart',event=>{
  if(event.target.closest('.calendar'))event.preventDefault();
 });
 document.addEventListener('pointercancel',finish);
 window.addEventListener('blur',finish);
})();
