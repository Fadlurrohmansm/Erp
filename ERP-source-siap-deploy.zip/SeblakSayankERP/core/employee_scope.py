from django.db import models
from django.db.models import Q
from tenancy.scope import current_branch


def employee_visibility(branch_id):
    from .models import EmployeeBranchAccess
    shared=EmployeeBranchAccess.objects.filter(branch_id=branch_id).values('employee_id')
    return Q(branch_id=branch_id)|Q(pk__in=shared)


class EmployeeManager(models.Manager):
    def get_queryset(self):
        qs=super().get_queryset()
        branch=current_branch.get()
        return qs.filter(employee_visibility(branch)).distinct() if branch is not None else qs


class AttendanceManager(models.Manager):
    def get_queryset(self):
        qs=super().get_queryset()
        branch=current_branch.get()
        if branch is None:return qs
        from .models import EmployeeBranchAccess
        shared=EmployeeBranchAccess.objects.filter(branch_id=branch).values('employee_id')
        return qs.filter(Q(employee__branch_id=branch)|Q(employee_id__in=shared))


def fresh_employee_queryset(queryset,branch_id):
    # Replace a prior request's visibility predicate, preserving status/name filters.
    qs=queryset.all()
    def scope_only(node):
        if hasattr(node,'children'):return bool(node.children) and all(scope_only(child) for child in node.children)
        target=getattr(getattr(node,'lhs',None),'target',None)
        if getattr(getattr(getattr(node,'rhs',None),'model',None),'__name__',None)=='EmployeeBranchAccess':return True
        return getattr(target,'name',None)=='branch' and getattr(getattr(target,'model',None),'__name__',None) in ('Employee','EmployeeBranchAccess')
    qs.query.where.children=[child for child in qs.query.where.children if not scope_only(child)]
    return qs.filter(employee_visibility(branch_id)).distinct()
