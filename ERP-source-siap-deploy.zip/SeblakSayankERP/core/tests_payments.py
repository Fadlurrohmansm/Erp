from datetime import date
from decimal import Decimal
from django.test import TestCase
from django.urls import reverse
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from tenancy.models import Branch
from .models import Employee,Payroll,PayrollPayment
from .payments import record_payment,payment_summary,cancel_payment

class PayrollPaymentTests(TestCase):
    def setUp(self):
        self.user=get_user_model().objects.create_user('salary-payment',password='testing');self.client.force_login(self.user)
        self.employee=Employee.objects.create(employee_code='PAY',full_name='Tim Gaji',position='Crew',hire_date=date(2026,1,1))
        self.p=Payroll.objects.create(employee=self.employee,month=9,year=2026,base_salary=350000,punctual_days=2,punctual_bonus_per_day=10000,manual_deduction=10000)
    def test_snapshot_amount_actual_payment_month_and_duplicate_protection(self):
        payment=record_payment(self.p.pk,date(2026,10,1),'Transfer bank',self.user)
        self.assertEqual(payment.amount,360000)
        self.assertEqual(payment_summary(date(2026,9,1),date(2026,9,30))['total'],0)
        self.assertEqual(payment_summary(date(2026,10,1),date(2026,10,31))['total'],360000)
        with self.assertRaises(ValidationError):record_payment(self.p.pk,date(2026,10,2),'Ulang',self.user)
        self.assertEqual(PayrollPayment.objects.count(),1)
        response=self.client.get(reverse('payroll_list'),{'paid_month':'2026-10'})
        self.assertContains(response,'Rp360.000');self.assertEqual(response.context['paid_summary']['employee_count'],1)
        self.assertEqual(self.client.get(reverse('dashboard'),{'month':'2026-10'}).context['salary_paid']['total'],360000)
    def test_cancel_keeps_history_and_allows_correct_payment(self):
        old=record_payment(self.p.pk,date(2026,9,30),'Salah tanggal',self.user)
        self.client.post(reverse('payroll_payment_cancel',args=[old.pk]),{'reason':'Koreksi tanggal'})
        old.refresh_from_db();self.assertTrue(old.voided)
        self.assertEqual(payment_summary(date(2026,9,1),date(2026,9,30))['total'],0)
        new=record_payment(self.p.pk,date(2026,10,1),'Tanggal benar',self.user)
        self.assertEqual(PayrollPayment.objects.count(),2);self.assertEqual(new.amount,old.amount)
        self.assertEqual(payment_summary(date(2026,10,1),date(2026,10,31))['count'],1)
    def test_paid_slip_cannot_edit_refresh_or_delete_and_employee_preserved(self):
        record_payment(self.p.pk,date(2026,10,1),'',self.user)
        self.assertEqual(self.client.post(reverse('payroll_edit',args=[self.p.pk]),{'manual_deduction':9999}).status_code,302)
        self.assertEqual(self.client.post(reverse('payroll_refresh',args=[self.p.pk]),{'confirm':'on'}).status_code,302)
        self.client.post(reverse('payroll_delete',args=[self.p.pk]),{'confirm':'on'})
        self.client.post(reverse('employee_delete',args=[self.employee.pk]),{'confirm':'on'})
        self.p.refresh_from_db();self.assertEqual(self.p.manual_deduction,10000);self.assertTrue(Employee.objects.filter(pk=self.employee.pk).exists())
    def test_cross_branch_hidden_and_unpaid_not_counted(self):
        other=Branch.objects.create(name='Cabang lain pembayaran')
        employee=Employee.objects.create(branch=other,employee_code='B',full_name='Tim B',position='Crew',hire_date=date(2026,1,1))
        p=Payroll.objects.create(branch=other,employee=employee,month=10,year=2026,base_salary=999000)
        record_payment(p.pk,date(2026,10,1),'',self.user)
        response=self.client.get(reverse('payroll_list'),{'paid_month':'2026-10'})
        self.assertEqual(response.context['paid_summary']['total'],0)
        self.assertEqual(self.client.get(reverse('payroll_pay',args=[p.pk])).status_code,404)
    def test_form_rejects_future_zero_and_get_has_no_payment_side_effect(self):
        from django.utils import timezone
        from datetime import timedelta
        url=reverse('payroll_pay',args=[self.p.pk])
        self.assertEqual(self.client.get(url).status_code,200);self.assertFalse(PayrollPayment.objects.exists())
        self.client.post(url,{'paid_date':(timezone.localdate()+timedelta(days=1)).isoformat()})
        self.assertFalse(PayrollPayment.objects.exists())
        self.p.base_salary=0;self.p.manual_deduction=0;self.p.punctual_days=0;self.p.save()
        with self.assertRaises(ValidationError):record_payment(self.p.pk,date(2026,10,1),'',self.user)
    def test_correct_payment_route_and_legacy_unpaid(self):
        self.assertIsNone(self.p.active_payment)
        self.assertEqual(self.client.post(reverse('payroll_pay',args=[self.p.pk]),{'paid_date':'2026-10-01','notes':'Tunai','expected_amount':'360000'}).status_code,302)
        self.assertEqual(self.p.active_payment.amount,360000)
        self.client.logout();self.assertEqual(self.client.get(reverse('payroll_list')).status_code,302)

    def test_stale_payment_amount_rejected(self):
        response=self.client.post(reverse('payroll_pay',args=[self.p.pk]),{'paid_date':'2026-10-01','expected_amount':'350000'})
        self.assertEqual(response.status_code,200);self.assertFalse(PayrollPayment.objects.exists())
