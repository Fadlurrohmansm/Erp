from tenancy.forms import ScopedForm,ScopedModelForm

from django import forms
from django.utils import timezone
from datetime import date
from .models import Employee, Attendance, Payroll, JobRole


class EmployeeForm(ScopedModelForm):
    class Meta:
        model = Employee
        fields = [
            "employee_code",
            "full_name",
            "phone",
            "role",
            "position",
            "hire_date",
            "base_salary",
            "monthly_leave_quota",
            "punctual_bonus_per_day",
            "status",
            "notes",
        ]

        labels = {"employee_code": "Kode karyawan", "full_name": "Nama lengkap", "phone": "Nomor telepon", "position": "Jabatan", "hire_date": "Mulai bekerja", "base_salary": "Gaji pokok bulanan", "status": "Status karyawan", "notes": "Catatan"}
        widgets = {
            "hire_date": forms.DateInput(
                attrs={"type": "date"}
            ),
            "notes": forms.Textarea(
                attrs={"rows": 3}
            ),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['position'].required = False
        self.fields['position'].label = 'Jabatan lama / keterangan (bila tanpa aturan jabatan)'
        self.fields['base_salary'].help_text = 'Digunakan bila tidak memilih jabatan. Jika memilih jabatan, nominal mengikuti pengaturan jabatan.'

    def clean(self):
        data = super().clean()
        from tenancy.scope import current_branch
        selected=current_branch.get()
        if self.instance.pk and selected is not None and self.instance.branch_id!=selected:
            raise forms.ValidationError('Data utama karyawan bersama hanya dapat diubah dari cabang asalnya. Absensi dapat diubah dari cabang terhubung.')
        if self.instance.pk and data.get('employee_code'):
            from .employee_scope import employee_visibility
            for branch_id in self.instance.branch_accesses.values_list('branch_id',flat=True):
                if Employee._base_manager.filter(employee_visibility(branch_id),employee_code__iexact=data['employee_code']).exclude(pk=self.instance.pk).exists():
                    self.add_error('employee_code','Kode ini sudah dipakai karyawan lain pada cabang terhubung.')
                    break
        role = data.get('role')
        if role:
            data['position'] = role.name
        elif not data.get('position'):
            self.add_error('position','Pilih jabatan atau isi nama jabatan lama.')
        return data

    def save(self, commit=True):
        employee = super().save(commit=False)
        if employee.role_id:
            employee.position = employee.role.name
            employee.pay_scheme = employee.role.pay_scheme
            employee.base_salary = employee.role.base_salary
            employee.daily_rate = employee.role.daily_rate
        if commit:employee.save()
        return employee


class AttendanceForm(ScopedModelForm):
    def clean(self):
        data=super().clean()
        if not data.get('work_branch'):
            employee=data.get('employee')
            if employee:
                from tenancy.scope import current_branch
                from tenancy.models import Branch
                selected=current_branch.get()
                data['work_branch']=Branch.objects.get(pk=selected) if selected else employee.branch
        return data

    class Meta:
        model = Attendance
        fields = [
            "employee",
            "date",
            "work_branch",
            "status",
            "punctual",
            "check_in",
            "check_out",
            "notes",
        ]
        labels = {"employee": "Karyawan", "date": "Tanggal", "status": "Kehadiran", "punctual": "Memenuhi bonus tepat waktu", "check_in": "Jam masuk", "check_out": "Jam pulang", "notes": "Catatan"}
        widgets = {
            "date": forms.DateInput(attrs={"type": "date"}),
            "status": forms.Select(),
            "punctual": forms.Select(),
            "check_in": forms.TimeInput(attrs={"type": "time"}),
            "check_out": forms.TimeInput(attrs={"type": "time"}),
        }
        
class PayrollForm(ScopedModelForm):
    period_type = forms.ChoiceField(label='Jenis periode', choices=[('range','Rentang tanggal / mingguan'),('monthly','Bulanan')], required=False)
    class Meta:
        model = Payroll
        fields = ['employee','period_type','start_date','end_date','month','year','manual_deduction','deduction_note','notes']
        labels = {'employee':'Karyawan','month':'Bulan (untuk payroll bulanan)','year':'Tahun (untuk payroll bulanan)','manual_deduction':'Potongan manual','deduction_note':'Catatan potongan (contoh: Kasbon / cicilan)','notes':'Catatan slip gaji'}
        widgets = {'start_date': forms.DateInput(attrs={'type':'date'},format='%Y-%m-%d'), 'end_date':forms.DateInput(attrs={'type':'date'},format='%Y-%m-%d')}
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.fields['month'].required=False;self.fields['year'].required=False
        if self.instance.pk:
            self.fields['period_type'].initial='range' if self.instance.start_date else 'monthly'
            for field in ['employee','period_type','start_date','end_date','month','year']:self.fields[field].disabled=True
    def clean(self):
        import calendar
        data=super().clean()
        kind=data.get('period_type') or ('range' if data.get('start_date') or data.get('end_date') else 'monthly')
        employee=data.get('employee');start=data.get('start_date');end=data.get('end_date')
        from tenancy.scope import current_branch
        selected=current_branch.get()
        if employee and selected is not None and employee.branch_id!=selected:
            self.add_error('employee','Payroll karyawan bersama dibuat di cabang asal '+employee.branch.name+' agar tidak terjadi pembayaran ganda.')
        if kind=='range':
            if not start:self.add_error('start_date','Isi tanggal awal.')
            if not end:self.add_error('end_date','Isi tanggal akhir.')
            if not start or not end:return data
            if start>end or (end-start).days>365 or start.year<2020 or end.year>2100:
                raise forms.ValidationError('Rentang tanggal tidak valid; maksimal 366 hari antara 2020–2100.')
            if employee and start<employee.hire_date:raise forms.ValidationError('Tanggal awal sebelum karyawan mulai bekerja.')
            data['month']=end.month;data['year']=end.year
        else:
            month=data.get('month');year=data.get('year')
            if not month:self.add_error('month','Pilih bulan.')
            if year is None or not 2020<=year<=2100:
                self.add_error('year','Tahun harus antara 2020 dan 2100.');return data
            if not month:return data
            start=date(year,month,1);end=date(year,month,calendar.monthrange(year,month)[1])
            data['start_date']=None;data['end_date']=None
            if employee and employee.hire_date>end:raise forms.ValidationError('Periode payroll sebelum karyawan mulai bekerja.')
        if data.get('manual_deduction',0)<0:self.add_error('manual_deduction','Potongan tidak boleh negatif.')
        if employee:
            for other in Payroll.objects.filter(employee=employee).exclude(pk=self.instance.pk):
                a,b=other.period_bounds
                if start<=b and end>=a:raise forms.ValidationError('Periode bertumpuk dengan payroll yang sudah ada: '+other.period_label)
        return data

class JobRoleForm(ScopedModelForm):
    class Meta:
        model=JobRole
        fields=['name','pay_scheme','base_salary','daily_rate']
    def clean(self):
        data=super().clean()
        field='daily_rate' if data.get('pay_scheme')=='daily' else 'base_salary'
        if data.get(field) is not None and data[field]<=0:self.add_error(field,'Nominal sistem gaji yang dipilih harus lebih dari 0.')
        return data


from django.forms import inlineformset_factory
from .models import PayrollExtra

class PayrollExtraForm(ScopedModelForm):
    class Meta:
        model = PayrollExtra
        fields = ['description', 'amount']
        widgets = {'description': forms.TextInput(attrs={'placeholder': 'Contoh: Bensin tambahan bulan ini'}), 'amount': forms.NumberInput(attrs={'min': '.01', 'step': '.01'})}

PayrollExtraFormSet = inlineformset_factory(Payroll, PayrollExtra, form=PayrollExtraForm, extra=1, can_delete=True, max_num=50, validate_max=True)

class DeleteConfirmationForm(ScopedForm):
    confirm = forms.BooleanField(label='Saya memahami data terkait akan dihapus permanen dan laporan keuangan akan berubah.')


from .models import SlipLayout
class SlipLayoutForm(ScopedModelForm):
    class Meta:
        model=SlipLayout
        fields=['title','show_work_branches','show_employee_code','show_position','show_base_salary','show_fuel','show_punctual_bonus','show_extras','show_deduction','show_attendance','show_rate_details','show_notes','show_footer','footer']
        widgets={'footer':forms.Textarea(attrs={'rows':3})}


class PayrollDeductionPolicyForm(ScopedModelForm):
    class Meta:
        from .models import PayrollDeductionPolicy
        model=PayrollDeductionPolicy
        fields=['enabled','quota_mode','deduct_leave','deduct_sick','deduct_absent','deduct_excess_off','daily_amount']


from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import get_user_model

class LoginAccountForm(UserCreationForm):
    class Meta(UserCreationForm.Meta):
        model=get_user_model()
        fields=['username','first_name','email']
        labels={'username':'Nama pengguna','first_name':'Nama tampilan','email':'Email (opsional)'}


class PayrollPaymentForm(ScopedForm):
    expected_amount=forms.DecimalField(widget=forms.HiddenInput,max_digits=14,decimal_places=2)
    paid_date=forms.DateField(label='Tanggal pembayaran',initial=timezone.localdate,widget=forms.DateInput(attrs={'type':'date'},format='%Y-%m-%d'))
    notes=forms.CharField(label='Catatan pembayaran (opsional)',required=False,max_length=255)
    def clean_paid_date(self):
        from django.utils import timezone
        day=self.cleaned_data['paid_date']
        if day>timezone.localdate():raise forms.ValidationError('Tanggal pembayaran tidak boleh di masa depan.')
        return day
