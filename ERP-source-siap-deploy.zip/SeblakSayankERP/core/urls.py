
from django.urls import path
from . import views

urlpatterns = [
    path('employees/import-branch/',views.employee_import_branch,name='employee_import_branch'),
    path('payroll/<int:payroll_id>/pay/',views.payroll_pay,name='payroll_pay'),
    path('payroll/payments/<int:payment_id>/cancel/',views.payroll_payment_cancel,name='payroll_payment_cancel'),
    path('account/',views.account_settings,name='account_settings'),
    path('account/create/',views.account_create,name='account_create'),
    path('account/password/',views.account_password_change,name='account_password_change'),
    path('payroll/deductions/',views.payroll_deduction_settings,name='payroll_deduction_settings'),
    path('payroll/layout/',views.slip_layout_settings,name='slip_layout_settings'),
    path("payroll/<int:payroll_id>/preview/",views.payroll_preview,name="payroll_preview"),
    path("payroll/<int:payroll_id>/refresh/",views.payroll_refresh,name="payroll_refresh"),
    path('roles/',views.role_list,name='role_list'),
    path('roles/add/',views.role_form,name='role_create'),
    path('roles/<int:role_id>/edit/',views.role_form,name='role_edit'),
    path('roles/<int:role_id>/delete/',views.role_delete,name='role_delete'),
    path("payroll/<int:payroll_id>/delete/", views.payroll_delete, name="payroll_delete"),
    path("", views.dashboard, name="dashboard"),
    path("employees/", views.employee_list, name="employee_list"),
    path("employees/add/", views.employee_create, name="employee_create"),
    path(
        "employees/<int:employee_id>/edit/",
        views.employee_edit,
        name="employee_edit",
    ),
    path(
        "employees/<int:employee_id>/delete/",
        views.employee_delete,
        name="employee_delete",
    ),
        
path("attendance/", views.attendance_list, name="attendance_list"),
path("attendance/add/", views.attendance_create, name="attendance_create"),
path(
    "attendance/<int:attendance_id>/edit/",
    views.attendance_edit,
    name="attendance_edit",
),
path("payroll/", views.payroll_list, name="payroll_list"),
path("payroll/add/", views.payroll_create, name="payroll_create"),
path(
    "payroll/<int:payroll_id>/edit/",
    views.payroll_edit,
    name="payroll_edit",
),
path(
    "payroll/<int:payroll_id>/pdf/",
    views.payroll_pdf,
    name="payroll_pdf",
),
]
