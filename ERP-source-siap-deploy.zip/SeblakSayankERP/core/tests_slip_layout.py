from datetime import date
from io import BytesIO
from django.test import TestCase
from django.contrib.auth import get_user_model
from django.urls import reverse
from pypdf import PdfReader
from .models import Employee,Payroll,PayrollExtra,SlipLayout
class SlipLayoutTests(TestCase):
    def setUp(self):
        self.client.force_login(get_user_model().objects.create_user('layouttester',password='testing'))
        e=Employee.objects.create(employee_code='LAYOUT',full_name='Tim Layout',position='Crew',hire_date=date(2026,1,1))
        self.p=Payroll.objects.create(employee=e,month=10,year=2026,base_salary=1000000,fuel_allowance=100000,punctual_days=7,punctual_bonus_per_day=10000,manual_deduction=50000,deduction_note='Kasbon khusus',notes='Catatan khusus')
        PayrollExtra.objects.create(payroll=self.p,description='Target khusus',amount=200000)
    def test_defaults_preserve_sections(self):
        response=self.client.get(reverse('payroll_preview',args=[self.p.pk]))
        self.assertContains(response,'Rekap absensi tersimpan');self.assertContains(response,'Kasbon khusus');self.assertContains(response,'Rp1.320.000')
    def test_hidden_sections_same_total_in_preview_and_pdf(self):
        SlipLayout.objects.create(pk=1,title='SLIP RINGKAS',show_attendance=False,show_extras=False,show_deduction=False,show_fuel=False,show_punctual_bonus=False,show_notes=False,show_employee_code=False,show_position=False,show_footer=False)
        response=self.client.get(reverse('payroll_preview',args=[self.p.pk]))
        for text in ['Rekap absensi tersimpan','Kasbon khusus','Target khusus','Catatan khusus','Uang bensin','LAYOUT']:
            self.assertNotContains(response,text)
        self.assertContains(response,'Rp1.320.000');self.assertContains(response,'SLIP RINGKAS')
        text=''.join(page.extract_text() for page in PdfReader(BytesIO(self.client.get(reverse('payroll_pdf',args=[self.p.pk])).content)).pages)
        self.assertIn('1.320.000',text)
        for hidden in ['REKAP ABSENSI','Kasbon khusus','Target khusus','Catatan khusus','Uang bensin']:
            self.assertNotIn(hidden,text)
        self.p.refresh_from_db();self.assertEqual(self.p.net_salary,1320000);self.assertEqual(self.p.punctual_days,7)
    def test_settings_persist_and_login(self):
        data={'title':'Slip Pilihan','show_attendance':'on','show_base_salary':'on','footer':'Terima kasih <b>tim</b>','show_footer':'on'}
        self.assertEqual(self.client.post(reverse('slip_layout_settings'),data).status_code,302)
        config=SlipLayout.objects.get(pk=1);self.assertTrue(config.show_attendance);self.assertFalse(config.show_fuel)
        self.assertContains(self.client.get(reverse('payroll_preview',args=[self.p.pk])),'&lt;b&gt;tim&lt;/b&gt;')
        self.client.logout();self.assertEqual(self.client.get(reverse('slip_layout_settings')).status_code,302)
