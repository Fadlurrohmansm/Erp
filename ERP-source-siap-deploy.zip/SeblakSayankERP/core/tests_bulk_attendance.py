from datetime import date
from django.test import TestCase
from django.contrib.auth import get_user_model
from django.urls import reverse
from .models import Employee, Attendance, EmployeeBranchAccess
from tenancy.models import Branch


class BulkAttendanceTests(TestCase):
    def setUp(self):
        self.client.force_login(get_user_model().objects.create_user('bulk-attendance',password='testing'))
        self.employee=Employee.objects.create(employee_code='BULK',full_name='Rahman',position='Crew',hire_date=date(2026,10,20))
        self.branch=Branch.objects.first()
        self.url=reverse('attendance_list')+'?month=2026-10&employee='+str(self.employee.pk)
        self.data={'employee':self.employee.pk,'date':'2026-10-24','dates':['2026-10-24','2026-10-25','2026-10-26'],'status':'present','punctual':'yes','work_branch':self.branch.pk,'notes':'Shift bersama'}

    def test_multi_date_create_and_update(self):
        Attendance.objects.create(employee=self.employee,date=date(2026,10,24),status='sick')
        response=self.client.post(self.url,self.data)
        self.assertEqual(response.status_code,302)
        rows=Attendance.objects.filter(employee=self.employee)
        self.assertEqual(rows.count(),3)
        self.assertTrue(all(row.punctual and row.notes=='Shift bersama' and row.work_branch_id==self.branch.pk for row in rows))
        self.client.post(self.url,{**self.data,'status':'off'})
        self.assertEqual(Attendance.objects.filter(status='off',punctual=False).count(),3)

    def test_invalid_dates_roll_back_entire_batch(self):
        for dates in [['2026-10-24','2026-10-19'],['2026-10-24','2026-11-01'],['bad'],['2026-10-24']*32]:
            response=self.client.post(self.url,{**self.data,'dates':dates})
            self.assertEqual(response.status_code,200)
            self.assertFalse(Attendance.objects.exists())

    def test_single_day_and_duplicate_dates(self):
        data={**self.data};data.pop('dates')
        self.assertEqual(self.client.post(self.url,data).status_code,302)
        self.client.post(self.url,{**self.data,'dates':['2026-10-25','2026-10-25']})
        self.assertEqual(Attendance.objects.count(),2)
        self.assertContains(self.client.get(self.url),'form="attendance-entry"')

    def test_shared_identity_and_foreign_employee(self):
        other=Branch.objects.create(name='Cabang B')
        self.client.post(reverse('branch_switch'),{'branch_id':other.pk})
        self.client.post(self.url,self.data)
        self.assertFalse(Attendance._base_manager.exists())
        EmployeeBranchAccess.objects.create(employee=self.employee,branch=other)
        response=self.client.post(self.url,{**self.data,'work_branch':other.pk})
        self.assertEqual(response.status_code,302)
        self.assertEqual(Attendance._base_manager.filter(employee=self.employee,branch=self.branch,work_branch=other).count(),3)
