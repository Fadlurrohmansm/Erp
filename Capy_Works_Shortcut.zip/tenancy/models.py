from django.db import models
from .scope import current_branch,default_branch

PUNCTUALITY_WEEKDAY_FIELDS = (
    'punctuality_cutoff_monday',
    'punctuality_cutoff_tuesday',
    'punctuality_cutoff_wednesday',
    'punctuality_cutoff_thursday',
    'punctuality_cutoff_friday',
    'punctuality_cutoff_saturday',
    'punctuality_cutoff_sunday',
)


class Branch(models.Model):
    name=models.CharField('Nama cabang',max_length=100,unique=True)
    punctuality_cutoff = models.TimeField('Batas hadir tepat waktu', null=True, blank=True)
    punctuality_cutoff_monday = models.TimeField('Senin', null=True, blank=True)
    punctuality_cutoff_tuesday = models.TimeField('Selasa', null=True, blank=True)
    punctuality_cutoff_wednesday = models.TimeField('Rabu', null=True, blank=True)
    punctuality_cutoff_thursday = models.TimeField('Kamis', null=True, blank=True)
    punctuality_cutoff_friday = models.TimeField('Jumat', null=True, blank=True)
    punctuality_cutoff_saturday = models.TimeField('Sabtu', null=True, blank=True)
    punctuality_cutoff_sunday = models.TimeField('Minggu', null=True, blank=True)

    def punctuality_cutoff_for(self, day):
        weekday_cutoff = getattr(self, PUNCTUALITY_WEEKDAY_FIELDS[day.weekday()])
        return self.punctuality_cutoff if weekday_cutoff is None else weekday_cutoff

    class Meta:ordering=['name']
    def __str__(self):return self.name

class BranchManager(models.Manager):
    def get_queryset(self):
        qs=super().get_queryset()
        selected=current_branch.get()
        return qs.filter(branch_id=selected) if selected is not None else qs

class BranchScopedModel(models.Model):
    branch=models.ForeignKey(Branch,on_delete=models.PROTECT,default=default_branch,editable=False)
    objects=BranchManager()
    class Meta:abstract=True
