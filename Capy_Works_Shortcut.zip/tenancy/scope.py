from contextvars import ContextVar
current_branch = ContextVar('current_branch', default=None)

def default_branch():
    selected=current_branch.get()
    if selected is not None:return selected
    from .models import Branch
    # Older migrations call this default before all Branch columns exist.
    branch_id = Branch.objects.order_by('pk').values_list('pk', flat=True).first()
    return branch_id if branch_id is not None else Branch.objects.create(name='Cabang Utama').pk
