from datetime import timedelta
from decimal import Decimal


def dashboard_display(day, today, start, end, daily):
    """Build the calendar and chart from the dates and totals already on the dashboard."""
    weekdays = ('Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min')
    monday = day - timedelta(days=day.weekday())
    week = [
        {'date': monday + timedelta(days=index), 'label': label}
        for index, label in enumerate(weekdays)
    ]

    values = {row['date']: row for row in daily}
    amounts = [amount for row in daily for amount in (row['total'], row['gross_profit'])]
    lower = min([0, *amounts])
    upper = max([0, *amounts])
    spread = upper - lower or Decimal(1)
    baseline = (upper / spread) * 100 if amounts else 100

    def bar(value):
        return {
            'top': f'{(upper - max(0, value)) / spread * 100:.4f}',
            'height': f'{abs(value) / spread * 100:.4f}',
        }

    days = []
    for offset in range((end - start).days + 1):
        date = start + timedelta(days=offset)
        row = values.get(date)
        days.append({
            'date': date,
            'row': row,
            'revenue': bar(row['total']) if row else None,
            'profit': bar(row['gross_profit']) if row else None,
            'tick': date == start or date == end or date.day in (5, 10, 15, 20, 25),
        })

    return {
        'week': week,
        'prev_week': (day - timedelta(days=7)).isoformat(),
        'next_week': (day + timedelta(days=7)).isoformat(),
        'bars': days,
        'baseline': f'{baseline:.4f}',
        'today_selected': day == today,
    }
