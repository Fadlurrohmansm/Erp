import hashlib
import io
import uuid
from collections import defaultdict
from datetime import datetime
from decimal import Decimal, InvalidOperation
from zipfile import ZipFile, BadZipFile
from django.core.exceptions import ValidationError
from django.db import transaction
from django.utils import timezone
from .models import Product, Sale, Channel, POSCostImport, POSProductAlias, BusinessSettings
from .services import money, post_daily_recap
from .pos_quantities import pos_quantities, classify


def parse_pos_xlsx(raw):
    if len(raw)>5*1024*1024:
        raise ValidationError('XLSX maksimal 5 MB.')
    try:
        with ZipFile(io.BytesIO(raw)) as archive:
            if sum(i.file_size for i in archive.infolist())>30*1024*1024:
                raise ValidationError('Ukuran isi XLSX terlalu besar.')
        from openpyxl import load_workbook
        workbook=load_workbook(io.BytesIO(raw),read_only=True,data_only=False)
    except ValidationError: raise
    except Exception: raise ValidationError('XLSX tidak dapat dibaca. Gunakan ekspor asli POS.')
    try:
        if 'Riwayat Penjualan' not in workbook.sheetnames:
            raise ValidationError('Sheet Riwayat Penjualan tidak ditemukan. Format POS ini belum didukung.')
        sheet=workbook['Riwayat Penjualan']
        rows=sheet.iter_rows(values_only=True)
        headers=[str(x or '').strip() for x in next(rows, ())]
        required=['No. Struk','Tanggal','Nama Outlet','Nama Produk','Jumlah Produk','Status','Total','Produk Ekstra','Harga Produk Ekstra']
        if any(k not in headers for k in required):
            raise ValidationError('Kolom POS tidak lengkap atau format berubah.')
        config=BusinessSettings.objects.filter(pk=1).first()
        noncash=config.pos_noncash_method if config else 'qris'
        payments={key:{'orders':0,'amount':Decimal(0)} for key in ['cash','qris','transfer','noncash','mixed','unknown']}
        dates=set();outlets=set();seen=set();items=defaultdict(lambda:Decimal(0));current=None;count=0;footer=None;qty_total=Decimal(0);revenue=Decimal(0);discounts=Decimal(0);line_subtotal=Decimal(0)
        for n,row in enumerate(rows,2):
            if n>10002:raise ValidationError('Maksimal 10.000 baris POS.')
            if not any(x is not None for x in row):continue
            data=dict(zip(headers,row))
            name=str(data.get('Nama Produk') or '').strip()
            if name.casefold()=='total' and not data.get('No. Struk'):
                if footer is not None:raise ValidationError('Baris total berulang.')
                try:footer=Decimal(str(data.get('Jumlah Produk')))
                except InvalidOperation:raise ValidationError('Jumlah pada baris Total tidak valid.')
                continue
            if footer is not None:raise ValidationError('Ada baris data setelah Total; impor ditolak.')
            if data.get('No. Struk'):
                ident=str(data['No. Struk']).strip()
                if ident in seen:raise ValidationError(f'Baris {n}: nomor struk berulang.')
                seen.add(ident)
                try:
                    day=datetime.strptime(str(data['Tanggal']), '%d-%m-%Y').date()
                except (ValueError,TypeError):raise ValidationError(f'Baris {n}: tanggal harus DD-MM-YYYY.')
                if day>timezone.localdate():raise ValidationError('Tanggal POS masih di masa depan.')
                status=str(data['Status'] or '').upper().strip()
                if status!='LUNAS':raise ValidationError(f'Baris {n}: status harus LUNAS. Ekspor hanya transaksi selesai, tanpa refund/batal.')
                current=day
                dates.add(day.isoformat());outlets.add(str(data['Nama Outlet']))
                try:total=Decimal(str(data['Total']))
                except InvalidOperation:raise ValidationError(f'Baris {n}: total struk tidak valid.')
                if not total.is_finite() or total<0:raise ValidationError('Total struk tidak valid.')
                for key in ['Pajak Transaksi','Ongkos Kirim','Kemasan']:
                    value=data.get(key)
                    if value not in [None,'',0]:raise ValidationError(f'Baris {n}: pajak/ongkir/kemasan tambahan perlu ditinjau manual.')
                try:discount=Decimal(str(data.get('Diskon Transaksi') or 0))
                except InvalidOperation:raise ValidationError('Diskon transaksi tidak valid.')
                if not discount.is_finite() or discount<0:raise ValidationError('Diskon transaksi tidak valid.')
                discounts+=discount
                payment=str(data.get('Metode Pembayaran') or '').strip().casefold()
                payment_methods={'tunai':'cash','cash':'cash','non tunai':noncash,'non-tunai':noncash,'qris':'qris','transfer':'transfer','bank transfer':'transfer','debit':'noncash','kartu':'noncash'}
                parts=[part.strip() for part in payment.split(',')]
                if payment and any(not part or part not in payment_methods for part in parts):
                    raise ValidationError(f'Baris {n}: metode pembayaran {payment} belum didukung.')
                keys={payment_methods[part] for part in parts if part}
                # Split amounts are absent in this POS export. Count the receipt once.
                payment_key='mixed' if len(keys)>1 else next(iter(keys),None)
                payment_key=payment_key or 'unknown'
                payments[payment_key]['orders']+=1
                payments[payment_key]['amount']+=total
                revenue+=total;count+=1
            if current is None or not name:raise ValidationError(f'Baris {n}: menu tidak memiliki struk induk atau nama kosong.')
            extra=data.get('Produk Ekstra')
            if extra not in [None,'','-'] or data.get('Harga Produk Ekstra') not in [None,'',0]:
                raise ValidationError(f'Baris {n}: produk ekstra belum didukung. Ekspor ekstra sebagai baris menu terpisah agar HPP tidak hilang.')
            try:qty=Decimal(str(data['Jumlah Produk']))
            except InvalidOperation:raise ValidationError(f'Baris {n}: jumlah produk tidak valid.')
            if not qty.is_finite() or qty<=0 or qty>100000 or qty!=qty.to_integral_value():raise ValidationError(f'Baris {n}: jumlah porsi harus bilangan bulat positif.')
            if len(name)>255:raise ValidationError('Nama produk terlalu panjang.')
            if 'Subtotal' in headers:
                try:line=Decimal(str(data.get('Subtotal')))
                except InvalidOperation:raise ValidationError(f'Baris {n}: subtotal menu tidak valid.')
                if not line.is_finite() or line<0:raise ValidationError('Subtotal menu tidak valid.')
                line_subtotal+=line
            items[name]+=qty;qty_total+=qty
        if len(dates)!=1 or len(outlets)!=1:raise ValidationError('Gunakan ekspor satu hari dan satu outlet untuk setiap impor.')
        if footer is not None and footer!=qty_total:raise ValidationError('Jumlah menu tidak cocok dengan baris Total POS.')
        if 'Subtotal' in headers and line_subtotal-discounts!=revenue:raise ValidationError('Total struk tidak cocok dengan subtotal menu dikurangi diskon transaksi.')
        if not items or len(items)>100:raise ValidationError('File kosong atau lebih dari 100 nama menu berbeda.')
        return dict(id=str(uuid.uuid4()),fingerprint=hashlib.sha256(raw).hexdigest(),date=next(iter(dates)),outlet=next(iter(outlets)),orders=count,payments={k:{'orders':v['orders'],'amount':str(v['amount'])} for k,v in payments.items()},classification_pending=bool(config and config.pos_count_mode=='product'),**pos_quantities([dict(name=k,quantity=v,sales_kind=classify(k,None,config)) for k,v in items.items()]),pos_revenue=str(revenue),subtotal=str(revenue+discounts),discounts=str(discounts),items=[dict(name=k,quantity=str(v)) for k,v in sorted(items.items())])
    finally:workbook.close()


def snapshot_lines(draft,mappings):
    result=[]
    config=BusinessSettings.objects.filter(pk=1).first()
    from .hpp import CostBook, policy_for, sale_quote
    books = {}
    for i,item in enumerate(draft['items']):
        product=Product.objects.prefetch_related('recipes__ingredient').get(pk=mappings[f'product_{i}'].pk)
        channel=draft.get('channel','Offline')
        override=product.manual_channel_cost(channel)
        policy = policy_for(product.branch_id)
        basis = 'HPP manual ' + channel if override is not None else 'Resep / HPP dasar'
        evidence = {}
        if policy.apply_to_sales and override is None:
            if product.branch_id not in books:
                day = datetime.strptime(draft['date'], '%Y-%m-%d').date()
                books[product.branch_id] = CostBook(product.branch_id, day, policy.method, policy.window)
            cost, quote = sale_quote(product, channel, books[product.branch_id])
            from .hpp import serializable
            evidence = {'cost_evidence': serializable(quote)}
            basis = policy.get_method_display()
        else:
            cost = money(product.cost_for_channel(channel))
        if cost < 0:
            raise ValidationError(f'HPP {product.name} tidak boleh negatif.')
        result.append(dict(sales_kind=classify(item['name'],product,config),source_name=item['name'],product_id=product.pk,product_name=product.name,quantity=item['quantity'],unit_cost=str(cost),cost_basis=basis,**evidence,total=str(money(cost*Decimal(item['quantity'])))))
    return result


@transaction.atomic
def commit_pos_cost(draft,user):
    total=sum((Decimal(x['total']) for x in draft['lines']),Decimal(0))
    if draft.get('create_offline'):
        channel=Channel.objects.get(pk=draft['channel_id'])
        if channel.name.casefold()!='offline':raise ValidationError('Pembuatan omzet dari POS hanya untuk kanal Offline.')
        if Sale.objects.filter(date=draft['date'],channel=channel,status='posted').exists():raise ValidationError('Rekap Offline sudah dibuat sejak pratinjau. Ulangi impor agar tidak ganda.')
        sale=post_daily_recap(data=dict(token=uuid.uuid4(),date=datetime.strptime(draft['date'],'%Y-%m-%d').date(),channel=channel,order_count=draft['orders'],subtotal=Decimal(draft['subtotal']),voucher_amount=Decimal(draft['discounts']),commission_amount=Decimal(0),other_fees=Decimal(0),cost=total,notes='Penjualan Offline dari POS XLSX'),user=user)
    else:
        sale=Sale.objects.select_for_update().get(pk=draft['sale_id'])
    if not sale.is_recap or sale.status!='posted' or sale.date.isoformat()!=draft['date']:
        raise ValidationError('Rekap berubah atau dibatalkan. Ulangi impor POS.')
    if POSCostImport.objects.filter(fingerprint=draft['fingerprint']).exists() or POSCostImport.objects.filter(sale=sale).exists():
        raise ValidationError('File atau rekap ini sudah memiliki impor HPP POS. Tidak ada data yang ditambahkan.')
    if sale.channel.name.casefold() == 'offline' and sale.net_revenue != Decimal(draft['pos_revenue']):
        raise ValidationError('Total rekap Offline berubah sejak pratinjau. Ulangi impor.')
    if not draft.get('create_offline') and str(sale.cost)!=draft['previous_cost']:
        raise ValidationError('HPP rekap berubah sejak pratinjau. Ulangi impor.')
    total=sum((Decimal(x['total']) for x in draft['lines']),Decimal(0))
    for line in draft['lines']:
        POSProductAlias.objects.update_or_create(name=line['source_name'].casefold(),defaults={'product_id':line['product_id']})
    record=POSCostImport.objects.create(fingerprint=draft['fingerprint'],sale=sale,filename=draft['filename'],lines=draft['lines'],payments=draft.get('payments',{}),previous_cost=Decimal(0) if draft.get('create_offline') else sale.cost,total_cost=total,created_by=user)
    sale.cost=total;sale.cost_estimated=False
    sale.notes=(sale.notes[:170]+' · HPP resep dari POS XLSX')
    sale.save(update_fields=['cost','cost_estimated','notes'])
    return record


def prepare_pos_report(upload, channel):
    report = parse_pos_xlsx(upload.read())
    report['filename'] = upload.name[:255]
    sales = Sale.objects.filter(date=report['date'], channel=channel, status='posted')
    sale = sales.filter(is_recap=True).first()
    if not sale and sales.exists():
        raise ValidationError('Penjualan sudah tercatat sebagai transaksi. Periksa rekap kanal dan tanggal ini.')
    existing = POSCostImport.objects.filter(sale=sale).first() if sale else None
    offline = channel.name.casefold() == 'offline'
    if offline and sale and sale.net_revenue != Decimal(report['pos_revenue']):
        raise ValidationError('Total Offline POS berbeda dari rekap yang ada. Koreksi rekap lebih dahulu.')
    if existing and existing.fingerprint == report['fingerprint'] and not existing.payments and offline:
        report.update(stage='payment_preview', payment_record_id=existing.pk, sale_id=sale.pk,
                      channel=sale.channel_name, classification_pending=False)
        report.pop('others', None)
        report.update(existing.quantities)
    else:
        if existing or POSCostImport.objects.filter(fingerprint=report['fingerprint']).exists():
            raise ValidationError('File atau rekap ini sudah pernah diimpor dari POS.')
        if not sale and not offline:
            raise ValidationError('Belum ada settlement/rekap aktif untuk kanal dan tanggal ini. Impor settlement online dahulu.')
        report.update(stage='mapping', sale_id=sale.pk if sale else None, channel=channel.name,
                      channel_id=channel.pk, previous_cost=str(sale.cost) if sale else '0.00',
                      create_offline=not sale)
    return report


def prepare_pos_batch(uploads, channel):
    reports, dates, outlets = [], {}, set()
    for upload in uploads:
        try:
            report = prepare_pos_report(upload, channel)
            if report['date'] in dates:
                raise ValidationError(f"Tanggal {report['date']} juga ada di {dates[report['date']]}. Pilih satu laporan lengkap per tanggal.")
            outlets.add(report['outlet'].strip().casefold())
            if len(outlets) > 1:
                raise ValidationError('File berasal dari outlet berbeda. Unggah per outlet.')
        except ValidationError as exc:
            raise ValidationError([f'{upload.name} — {message}' for message in exc.messages]) from exc
        dates[report['date']] = upload.name
        reports.append(report)
    reports.sort(key=lambda report: report['date'])
    if len(reports) == 1:
        return reports[0]

    quantities = defaultdict(Decimal)
    for report in reports:
        if report['stage'] == 'mapping':
            for item in report['items']:
                quantities[item['name']] += Decimal(item['quantity'])
    return {
        'id': str(uuid.uuid4()), 'reports': reports,
        'stage': 'mapping' if quantities else 'payment_preview',
        'items': [{'name': name, 'quantity': str(total)} for name, total in sorted(quantities.items())],
    }


def map_pos_batch(draft, mappings):
    products = {item['name']: mappings[f'product_{i}'] for i, item in enumerate(draft['items'])}
    reports = []
    for report in draft.get('reports', [draft]):
        if report['stage'] == 'payment_preview':
            reports.append(report)
            continue
        line_mappings = {f'product_{i}': products[item['name']] for i, item in enumerate(report['items'])}
        lines = snapshot_lines(report, line_mappings)
        mapped = {**report}
        mapped.pop('others', None)
        mapped.update(pos_quantities(lines), lines=lines, classification_pending=False,
                      total_cost=str(sum((Decimal(line['total']) for line in lines), Decimal(0))),
                      stage='preview')
        reports.append(mapped)
    return {**draft, 'reports': reports, 'stage': 'preview'} if 'reports' in draft else reports[0]


@transaction.atomic
def commit_pos_batch(draft, user):
    records = []
    for report in draft.get('reports', [draft]):
        try:
            if report['stage'] == 'payment_preview':
                sale = Sale.objects.select_for_update().get(pk=report['sale_id'])
                record = POSCostImport.objects.select_for_update().get(
                    pk=report['payment_record_id'], fingerprint=report['fingerprint'], sale_id=report['sale_id'],
                )
                if record.payments or sale.status != 'posted':
                    raise ValidationError('Rekap berubah atau rincian pembayaran sudah tersedia.')
                if sale.net_revenue != Decimal(report['pos_revenue']):
                    raise ValidationError('Total pembayaran berbeda dari rekap.')
                record.payments = report['payments']
                record.save(update_fields=['payments'])
            else:
                record = commit_pos_cost(report, user)
        except (ValidationError, Sale.DoesNotExist, POSCostImport.DoesNotExist, Channel.DoesNotExist) as exc:
            reason = ' '.join(exc.messages) if isinstance(exc, ValidationError) else 'Rekap berubah. Unggah ulang laporan.'
            raise ValidationError(f"{report['filename']} — {reason}") from exc
        records.append(record)
    return records
