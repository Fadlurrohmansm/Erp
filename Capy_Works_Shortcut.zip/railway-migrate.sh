#!/bin/sh
set -eu
export DATABASE_URL="${DATABASE_URL_UNPOOLED:?Missing unpooled database URL}"
exec python manage.py migrate --noinput
