#!/bin/sh
set -eu
if [ "${ERP_DATABASE_CONNECTION:-pooled}" = direct ]; then
  DATABASE_URL="${DATABASE_URL_UNPOOLED:?Missing direct database URL}"
else
  DATABASE_URL="${DATABASE_URL_POOLED:?Missing pooled database URL}"
fi
export DATABASE_URL
exec python -m gunicorn config.wsgi:application --bind "0.0.0.0:${PORT:-8080}" --workers 1 --threads 4 --timeout 120
