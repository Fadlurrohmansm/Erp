import base64
import binascii
import json
import logging
import re
from urllib.parse import quote, urlencode, urlsplit

from django.conf import settings
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.http import HttpResponse, HttpResponseForbidden, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_GET, require_POST

from .portal_models import AttendancePushSubscription, EmployeeCheckIn

logger = logging.getLogger(__name__)
PUSH_PATHS = {
    'fcm.googleapis.com': '/fcm/send/',
    'updates.push.services.mozilla.com': '/wpush/v2/',
    'web.push.apple.com': '/',
}
MAX_DEVICES = 5


def push_configured():
    return bool(settings.ERP_PUSH_PUBLIC_KEY and settings.ERP_PUSH_PRIVATE_KEY and settings.ERP_PUSH_SUBJECT)


def valid_endpoint(endpoint):
    if not isinstance(endpoint, str) or len(endpoint) > 800 or not re.fullmatch(r'https://[A-Za-z0-9._~:/-]+', endpoint):
        return False
    parsed = urlsplit(endpoint)
    prefix = PUSH_PATHS.get(parsed.netloc)
    return bool(prefix and parsed.path.startswith(prefix) and len(parsed.path) > len(prefix))


def valid_key(key, size, prefix=None):
    if not isinstance(key, str) or len(key) > 100 or not re.fullmatch(r'[A-Za-z0-9_-]+={0,2}', key):
        return False
    try:
        decoded = base64.urlsafe_b64decode(key + '=' * (-len(key) % 4))
    except (ValueError, binascii.Error):
        return False
    return len(decoded) == size and (prefix is None or decoded.startswith(prefix))


@never_cache
@login_required
@require_GET
def attendance_notifications(request):
    if not request.user.is_superuser:
        return HttpResponseForbidden()
    check_ins = EmployeeCheckIn.objects.select_related(
        'attendance__employee', 'attendance__branch', 'attendance__work_branch',
    ).order_by('-recorded_at', '-pk')[:50]
    return render(request, 'core/attendance_notifications.html', {
        'check_ins': check_ins,
        'push_public_key': settings.ERP_PUSH_PUBLIC_KEY if push_configured() else '',
    })


def android_maps_intent(coordinates, fallback):
    query = quote(coordinates, safe='')
    fallback = quote(fallback, safe='')
    return (
        f'intent:0,0?q={query}#Intent;scheme=geo;'
        f'package=com.google.android.apps.maps;S.browser_fallback_url={fallback};end'
    )


@never_cache
@login_required
@require_GET
def attendance_notification_location(request, check_in_id):
    if not request.user.is_superuser:
        return HttpResponseForbidden()
    check_in = get_object_or_404(EmployeeCheckIn, pk=check_in_id)
    coordinates = f'{check_in.latitude},{check_in.longitude}'
    query = urlencode({'api': '1', 'query': coordinates})
    maps_url = f'https://www.google.com/maps/search/?{query}'
    platform = request.headers.get('Sec-CH-UA-Platform', '').strip('"')
    is_android = platform == 'Android' or 'Android' in request.headers.get('User-Agent', '')
    if not is_android:
        response = redirect(maps_url)
    elif request.GET.get('buka') == 'pilih':
        response = render(request, 'core/attendance_maps.html', {
            'app_url': android_maps_intent(coordinates, maps_url),
            'maps_url': maps_url,
        })
    else:
        fallback = request.build_absolute_uri(f'{request.path}?buka=pilih')
        # Django's general redirect helper only accepts HTTP(S) and FTP schemes.
        # Both the intent package and its coordinate values are constructed here.
        response = HttpResponse(status=302, headers={'Location': android_maps_intent(coordinates, fallback)})
    response['Referrer-Policy'] = 'no-referrer'
    return response


@never_cache
@login_required
@require_POST
def attendance_push_subscription(request):
    if not request.user.is_superuser:
        return HttpResponseForbidden()
    if len(request.body) > 4096:
        return JsonResponse({'error': 'Data perangkat terlalu besar.'}, status=400)
    try:
        data = json.loads(request.body)
    except ValueError:
        return JsonResponse({'error': 'Data perangkat tidak valid.'}, status=400)
    if not isinstance(data, dict) or not valid_endpoint(data.get('endpoint')):
        return JsonResponse({'error': 'Layanan notifikasi browser ini belum didukung.'}, status=400)
    endpoint = data['endpoint']
    if data.get('remove') is True:
        AttendancePushSubscription.objects.filter(user=request.user, endpoint=endpoint).delete()
        return JsonResponse({'subscribed': False})
    keys = data.get('keys')
    if not isinstance(keys, dict) or not valid_key(keys.get('p256dh'), 65, b'\x04') or not valid_key(keys.get('auth'), 16):
        return JsonResponse({'error': 'Kunci notifikasi browser tidak valid.'}, status=400)
    if not push_configured():
        return JsonResponse({'error': 'Notifikasi HP belum tersedia.'}, status=503)
    with transaction.atomic():
        get_user_model().objects.select_for_update().get(pk=request.user.pk)
        devices = AttendancePushSubscription.objects.filter(user=request.user).exclude(endpoint=endpoint)
        if devices.count() >= MAX_DEVICES:
            return JsonResponse({'error': 'Maksimal lima perangkat. Nonaktifkan salah satunya terlebih dahulu.'}, status=409)
        AttendancePushSubscription.objects.update_or_create(
            endpoint=endpoint,
            defaults={'user': request.user, 'p256dh': keys['p256dh'], 'auth': keys['auth']},
        )
    return JsonResponse({'subscribed': True})


def notify_attendance_owner(check_in_id, device_label=''):
    if not push_configured():
        return

    from pywebpush import WebPushException, webpush
    from requests import RequestException, Session

    class PushSession(Session):
        def request(self, *args, **kwargs):
            kwargs['allow_redirects'] = False
            return super().request(*args, **kwargs)

    subscriptions = AttendancePushSubscription.objects.filter(
        user__is_active=True, user__is_superuser=True,
    )
    payload = json.dumps({
        'checkIn': check_in_id,
        'device': device_label,
        'path': reverse('attendance_notification_location', args=[check_in_id]),
    })
    with PushSession() as session:
        for device in subscriptions:
            if not valid_endpoint(device.endpoint):
                continue
            try:
                webpush(
                    subscription_info={
                        'endpoint': device.endpoint,
                        'keys': {'p256dh': device.p256dh, 'auth': device.auth},
                    },
                    data=payload,
                    vapid_private_key=settings.ERP_PUSH_PRIVATE_KEY,
                    vapid_claims={'sub': settings.ERP_PUSH_SUBJECT},
                    ttl=3600,
                    timeout=2,
                    requests_session=session,
                )
            except WebPushException as exc:
                status = exc.response.status_code if exc.response is not None else None
                if status in (404, 410):
                    subscriptions.filter(pk=device.pk, p256dh=device.p256dh, auth=device.auth).delete()
                else:
                    logger.warning('Attendance push not sent (%s)', status)
            except (RequestException, ValueError):
                logger.warning('Attendance push delivery failed')
