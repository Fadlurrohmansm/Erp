from django.conf import settings
from django.db import models


class EmployeePortalAccount(models.Model):
    employee = models.OneToOneField(
        'core.Employee', on_delete=models.PROTECT, related_name='portal_account',
    )
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name='employee_portal_account',
    )


class EmployeeCheckIn(models.Model):
    attendance = models.OneToOneField(
        'core.Attendance', on_delete=models.CASCADE, related_name='portal_check_in',
    )
    account = models.ForeignKey(EmployeePortalAccount, on_delete=models.PROTECT)
    recorded_at = models.DateTimeField()
    punctuality_cutoff = models.TimeField(null=True, blank=True)
    previous_punctual = models.BooleanField(null=True, blank=True)
    latitude = models.DecimalField(max_digits=9, decimal_places=6)
    longitude = models.DecimalField(max_digits=9, decimal_places=6)
    accuracy = models.DecimalField(max_digits=9, decimal_places=2)
    device_label = models.CharField(max_length=110, blank=True)

    class Meta:
        constraints = [
            models.CheckConstraint(
                condition=models.Q(latitude__gte=-90, latitude__lte=90),
                name='employee_checkin_latitude_range',
            ),
            models.CheckConstraint(
                condition=models.Q(longitude__gte=-180, longitude__lte=180),
                name='employee_checkin_longitude_range',
            ),
            models.CheckConstraint(
                condition=models.Q(accuracy__gte=0),
                name='employee_checkin_accuracy_nonnegative',
            ),
        ]


class AttendancePushSubscription(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    endpoint = models.URLField(max_length=800, unique=True)
    p256dh = models.CharField(max_length=100)
    auth = models.CharField(max_length=100)
