from datetime import date, datetime, time
from unittest.mock import patch
from zoneinfo import ZoneInfo

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from core.models import Attendance, Employee
from core.portal_models import EmployeePortalAccount
from tenancy.models import Branch


class WeekdayCutoffTests(TestCase):
    friday = date(2026, 11, 27)
    saturday = date(2026, 11, 28)

    def setUp(self):
        self.branch = Branch.objects.first()
        self.branch.punctuality_cutoff = time(13)
        self.branch.punctuality_cutoff_friday = time(14)
        self.branch.save()
        self.employee = Employee.objects.create(
            branch=self.branch, employee_code='SHIFT', full_name='Crew',
            position='Crew', hire_date=date(2026, 11, 1),
        )
        self.owner = get_user_model().objects.create_superuser('cutoff-owner')

    def test_owner_saves_and_clears_friday_override(self):
        self.client.force_login(self.owner)
        url = reverse('attendance_cutoff')
        self.assertContains(self.client.get(url), 'Jumat')
        self.assertRedirects(self.client.post(url, {
            'punctuality_cutoff': '13:00', 'punctuality_cutoff_friday': '14:30',
        }), reverse('attendance_list'))
        self.branch.refresh_from_db()
        self.assertEqual(self.branch.punctuality_cutoff_for(self.friday), time(14, 30))
        self.assertEqual(self.branch.punctuality_cutoff_for(self.saturday), time(13))

        self.client.post(url, {'punctuality_cutoff': '13:00', 'punctuality_cutoff_friday': ''})
        self.branch.refresh_from_db()
        self.assertEqual(self.branch.punctuality_cutoff_for(self.friday), time(13))

    def test_bulk_attendance_uses_each_date(self):
        self.client.force_login(self.owner)
        response = self.client.post(reverse('attendance_list') + '?month=2026-11', {
            'employee': self.employee.pk, 'date': self.friday.isoformat(),
            'dates': [self.friday.isoformat(), self.saturday.isoformat()],
            'status': 'present', 'punctual': 'yes', 'check_in': '13:30',
            'work_branch': self.branch.pk,
        })
        self.assertEqual(response.status_code, 302)
        self.assertTrue(Attendance.objects.get(employee=self.employee, date=self.friday).punctual)
        self.assertFalse(Attendance.objects.get(employee=self.employee, date=self.saturday).punctual)

    def test_portal_records_cutoff_and_preserves_it_after_change(self):
        staff = get_user_model().objects.create_user('cutoff-staff')
        EmployeePortalAccount.objects.create(user=staff, employee=self.employee)
        self.client.force_login(staff)
        now = datetime(2026, 11, 27, 14, tzinfo=ZoneInfo('Asia/Jakarta'))
        home = reverse('employee_portal:home')
        with patch('core.portal_views.timezone.now', return_value=now):
            self.assertContains(self.client.get(home), '14:00 WIB')
            self.assertRedirects(self.client.post(reverse('employee_portal:check_in'), {
                'latitude': '-7.96', 'longitude': '112.62', 'accuracy': '10',
            }), home)
            record = Attendance.objects.get(employee=self.employee, date=self.friday)
            self.assertTrue(record.punctual)
            self.assertEqual(record.portal_check_in.punctuality_cutoff, time(14))
            Branch.objects.filter(pk=self.branch.pk).update(punctuality_cutoff_friday=time(12))
            self.assertContains(self.client.get(home), '14:00 WIB')
