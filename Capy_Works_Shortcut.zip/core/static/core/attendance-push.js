(() => {
  const panel = document.querySelector('#attendance-push');
  const button = panel.querySelector('button');
  const status = panel.querySelector('[role="status"]');
  const token = panel.querySelector('[name="csrfmiddlewaretoken"]').value;
  if (!('serviceWorker' in navigator) || !('PushManager' in window) || !('Notification' in window)) {
    status.textContent = 'Browser ini belum mendukung notifikasi absen. Riwayat absen tetap tersedia di bawah.';
    return;
  }

  function applicationKey(value) {
    const padded = value.replace(/-/g, '+').replace(/_/g, '/').padEnd(Math.ceil(value.length / 4) * 4, '=');
    return Uint8Array.from(atob(padded), character => character.charCodeAt(0));
  }

  async function saveDevice(data) {
    const response = await fetch(panel.dataset.endpoint, {
      method: 'POST',
      credentials: 'same-origin',
      headers: {'Content-Type': 'application/json', 'X-CSRFToken': token},
      body: JSON.stringify(data),
    });
    if (!response.ok || response.redirected) {
      const result = await response.json().catch(() => ({}));
      throw new Error(result.error || 'Pengaturan belum tersimpan. Buka ulang halaman, lalu coba lagi.');
    }
  }

  function showCurrent(subscription) {
    button.textContent = subscription ? 'Nonaktifkan notifikasi di perangkat ini' : 'Aktifkan notifikasi di perangkat ini';
    status.textContent = subscription ? 'Notifikasi absen aktif di perangkat ini.' : 'Izinkan notifikasi untuk menerima pemberitahuan absen masuk.';
    button.hidden = false;
  }

  navigator.serviceWorker.ready.then(async registration => {
    let subscription = await registration.pushManager.getSubscription();
    showCurrent(subscription);
    button.addEventListener('click', async () => {
      button.disabled = true;
      try {
        if (subscription) {
          const endpoint = subscription.endpoint;
          await saveDevice({endpoint, remove: true});
          await subscription.unsubscribe();
          subscription = null;
        } else {
          const created = await registration.pushManager.subscribe({
            userVisibleOnly: true,
            applicationServerKey: applicationKey(panel.dataset.publicKey),
          });
          try {
            await saveDevice(created.toJSON());
            subscription = created;
          } catch (error) {
            await created.unsubscribe();
            throw error;
          }
        }
        showCurrent(subscription);
      } catch (error) {
        status.textContent = Notification.permission === 'denied'
          ? 'Izin notifikasi diblokir. Ubah izin situs ini di pengaturan browser.'
          : error.message;
      } finally {
        button.disabled = false;
      }
    });
  }).catch(() => {
    status.textContent = 'Pengaturan notifikasi belum bisa dimuat. Buka ulang halaman untuk mencoba lagi.';
  });
})();
