'use strict';

for (const form of document.querySelectorAll('[data-slip-png]')) {
  const button = form.querySelector('button');
  const status = form.querySelector('[role="status"]');
  const label = button.textContent;

  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (button.disabled) return;

    button.disabled = true;
    button.textContent = 'Menyiapkan PNG…';
    status.textContent = '';

    try {
      const url = new URL(form.action);
      url.searchParams.set('format', 'png');
      const response = await fetch(url, {credentials: 'same-origin', cache: 'no-store'});
      if (response.redirected || response.status === 401 || response.status === 403) {
        status.textContent = 'Sesi masuk perlu diperbarui. Muat ulang halaman, lalu coba lagi.';
        return;
      }
      if (!response.ok || response.headers.get('Content-Type')?.split(';')[0] !== 'image/png') {
        throw new Error('Invalid PNG response');
      }

      const png = await response.blob();
      const signature = new Uint8Array(await png.slice(0, 8).arrayBuffer());
      const expected = [137, 80, 78, 71, 13, 10, 26, 10];
      if (!expected.every((byte, index) => signature[index] === byte)) {
        throw new Error('Invalid PNG signature');
      }

      const disposition = response.headers.get('Content-Disposition') || '';
      const filename = disposition.match(/filename="([^"]+\.png)"/i)?.[1] || 'slipgaji.png';
      const objectUrl = URL.createObjectURL(png);
      const link = document.createElement('a');
      link.href = objectUrl;
      link.download = filename;
      link.hidden = true;
      document.body.appendChild(link);
      link.click();
      link.remove();
      setTimeout(() => URL.revokeObjectURL(objectUrl), 60000);
    } catch {
      status.textContent = 'PNG belum bisa diunduh. Coba lagi.';
    } finally {
      button.disabled = false;
      button.textContent = label;
    }
  });
}
