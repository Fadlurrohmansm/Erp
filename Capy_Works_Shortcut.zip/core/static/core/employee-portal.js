'use strict';

const checkIn = document.getElementById('staff-check-in');
if (checkIn) {
  const button = checkIn.querySelector('button[type=submit]');
  const feedback = checkIn.querySelector('.staff-feedback');
  let locationReady = false;
  let locating = false;

  function fail(message) {
    locating = false;
    button.disabled = false;
    button.textContent = 'Absen masuk';
    feedback.textContent = message;
  }

  checkIn.addEventListener('submit', event => {
    if (locationReady) return;
    event.preventDefault();
    if (locating) return;
    if (!navigator.geolocation) {
      fail('Buka portal lewat HTTPS di browser HP yang mendukung lokasi.');
      return;
    }
    locating = true;
    button.disabled = true;
    button.textContent = 'Membaca lokasi…';
    feedback.textContent = 'Izinkan akses lokasi untuk melanjutkan.';
    const model = navigator.userAgentData?.getHighEntropyValues?.(['model'])
      .then(data => data.model || '').catch(() => '');
    const deviceModel = Promise.race([model || '', new Promise(resolve => setTimeout(() => resolve(''), 350))]);
    navigator.geolocation.getCurrentPosition(
      async ({coords}) => {
        if (![coords.latitude, coords.longitude, coords.accuracy].every(Number.isFinite)) {
          fail('Lokasi belum terbaca. Coba lagi.');
          return;
        }
        checkIn.elements.latitude.value = coords.latitude.toFixed(6);
        checkIn.elements.longitude.value = coords.longitude.toFixed(6);
        checkIn.elements.accuracy.value = coords.accuracy.toFixed(2);
        if (checkIn.elements.device_model) checkIn.elements.device_model.value = await deviceModel;
        locationReady = true;
        button.textContent = 'Menyimpan…';
        feedback.textContent = 'Lokasi terbaca. Menyimpan absensi.';
        checkIn.requestSubmit();
      },
      error => {
        fail(error.code === 1
          ? 'Izin lokasi ditolak. Aktifkan di pengaturan browser, lalu coba lagi.'
          : 'Lokasi belum terbaca. Pastikan layanan lokasi aktif, lalu coba lagi.');
      },
      {enableHighAccuracy: true, timeout: 15000, maximumAge: 0},
    );
  });
}

const employeeWorker = document.querySelector('[data-employee-worker]');
if (employeeWorker && 'serviceWorker' in navigator) {
  navigator.serviceWorker.register(employeeWorker.dataset.employeeWorker).catch(() => {});
}

const install = document.getElementById('pasang-absensi');
if (install) {
  let installPrompt;
  if (matchMedia('(display-mode: standalone)').matches || navigator.standalone) {
    install.hidden = true;
  }
  if (!install.hidden && location.hash === '#pasang-absensi') {
    install.open = true;
  }
  window.addEventListener('beforeinstallprompt', event => {
    event.preventDefault();
    installPrompt = event;
  });
  install.querySelector('summary').addEventListener('click', async event => {
    if (!installPrompt) return;
    event.preventDefault();
    const prompt = installPrompt;
    installPrompt = null;
    try {
      await prompt.prompt();
    } catch {
      install.open = true;
    }
  });
  window.addEventListener('appinstalled', () => { install.hidden = true; });
}
