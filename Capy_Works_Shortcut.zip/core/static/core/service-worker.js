// Enables installation without caching private ERP pages or data.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', event => event.waitUntil(self.clients.claim()));

self.addEventListener('push', event => {
  if (!event.data) return;
  let data;
  try {
    data = event.data.json();
  } catch {
    return;
  }
  if (!Number.isSafeInteger(data.checkIn) || data.path !== `/attendance/notifikasi/${data.checkIn}/lokasi/`) return;
  event.waitUntil(self.registration.showNotification('Absensi karyawan', {
    body: typeof data.device === 'string' && data.device
      ? `Perangkat: ${data.device}. Ketuk untuk buka Google Maps.`
      : 'Ada absen masuk baru. Ketuk untuk buka lokasi di Google Maps.',
    icon: '/static/core/icons/icon-192.png',
    tag: `attendance-${data.checkIn}`,
    data: {path: data.path},
  }));
});

self.addEventListener('notificationclick', event => {
  event.notification.close();
  const path = event.notification.data?.path;
  if (typeof path === 'string' && /^\/attendance\/notifikasi\/\d+\/lokasi\/$/.test(path)) {
    event.waitUntil(self.clients.openWindow(new URL(path, self.location.origin).href));
  }
});
