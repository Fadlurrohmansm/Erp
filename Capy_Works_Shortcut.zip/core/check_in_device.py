import re


BROWSERS = (
    ('SamsungBrowser/', 'Samsung Internet'),
    ('EdgA/', 'Edge'),
    ('EdgiOS/', 'Edge'),
    ('Edg/', 'Edge'),
    ('FxiOS/', 'Firefox'),
    ('Firefox/', 'Firefox'),
    ('OPR/', 'Opera'),
    ('CriOS/', 'Chrome'),
    ('Chrome/', 'Chrome'),
    ('Safari/', 'Safari'),
)


def device_label(request):
    agent = request.headers.get('User-Agent', '')[:1024]
    platform_hint = request.headers.get('Sec-CH-UA-Platform', '').strip('"')
    if platform_hint == 'Android' or 'Android' in agent:
        model = request.headers.get('Sec-CH-UA-Model', '').strip('"') or request.POST.get('device_model', '')
        model = model.strip()
        if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9 ._+()-]{1,63}', model) or model.casefold() in {'unknown', 'android'}:
            model = ''
        platform = f'{model} (Android)' if model else 'Android'
    elif 'iPhone' in agent:
        platform = 'iPhone'
    elif 'iPad' in agent:
        platform = 'iPad'
    elif 'Windows' in agent:
        platform = 'Windows'
    elif 'Macintosh' in agent:
        platform = 'macOS'
    elif 'Linux' in agent:
        platform = 'Linux'
    else:
        platform = ''

    browser = next((name for marker, name in BROWSERS if marker in agent), '')
    return ' · '.join(value for value in (platform, browser) if value)
