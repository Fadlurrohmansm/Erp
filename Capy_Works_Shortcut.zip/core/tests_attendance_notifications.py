import base64
import json
from datetime import date, datetime
from unittest.mock import patch
from urllib.parse import parse_qs, unquote, urlsplit
from zoneinfo import ZoneInfo

from django.contrib.auth import get_user_model
from django.test import Client, TestCase, override_settings
from django.urls import reverse

from core.models import Attendance, Employee
from core.portal_models import AttendancePushSubscription, EmployeeCheckIn, EmployeePortalAccount
from tenancy.models import Branch


class AttendanceNotificationTests(TestCase):
    def setUp(self):
        users = get_user_model().objects
        self.owner = users.create_superuser('notification-owner')
        self.staff = users.create_user('notification-staff')
        branch = Branch.objects.first()
        employee = Employee.objects.create(
            branch=branch, employee_code='PUSH', full_name='Staff Fixture',
            position='Crew', hire_date=date(2026, 11, 1),
        )
        self.account = EmployeePortalAccount.objects.create(user=self.staff, employee=employee)

    def test_portal_checkin_enqueues_once_and_owner_can_open_maps(self):
        self.client.force_login(self.staff)
        checkin_url = reverse('employee_portal:check_in')
        now = datetime(2026, 11, 27, 13, tzinfo=ZoneInfo('Asia/Jakarta'))
        location = {'latitude': '-7.96', 'longitude': '112.62', 'accuracy': '10'}
        with patch('core.portal_views.timezone.now', return_value=now):
            with patch('core.portal_views.notify_attendance_owner') as notify:
                with self.captureOnCommitCallbacks(execute=True):
                    self.client.post(
                        checkin_url, {**location, 'device_model': 'Xiaomi 15'},
                        HTTP_USER_AGENT='Mozilla/5.0 (Linux; Android 10; K) Chrome/145.0 Mobile Safari/537.36',
                    )
                    self.client.post(checkin_url, location)
                attendance = Attendance.objects.get(employee=self.account.employee)
                log = EmployeeCheckIn.objects.get(attendance=attendance)
                self.assertEqual(log.device_label, 'Xiaomi 15 (Android) · Chrome')
                notify.assert_called_once_with(log.pk, log.device_label)

        history_url = reverse('attendance_notifications')
        map_url = reverse('attendance_notification_location', args=[log.pk])
        operator = get_user_model().objects.create_user('notification-operator')
        self.client.force_login(operator)
        self.assertEqual(self.client.get(history_url).status_code, 403)
        self.assertEqual(self.client.get(map_url).status_code, 403)

        self.client.force_login(self.owner)
        history = self.client.get(history_url)
        self.assertContains(history, map_url)
        self.assertContains(history, 'Xiaomi 15 (Android) · Chrome')
        response = self.client.get(map_url)
        location = urlsplit(response.url)
        self.assertEqual(response.status_code, 302)
        self.assertEqual(location.netloc, 'www.google.com')
        self.assertEqual(parse_qs(location.query)['query'], ['-7.960000,112.620000'])
        self.assertEqual(response['Referrer-Policy'], 'no-referrer')

        mobile = {'HTTP_USER_AGENT': 'Mozilla/5.0 (Linux; Android 14) Chrome/145.0'}
        response = self.client.get(map_url, secure=True, **mobile)
        self.assertEqual(response.status_code, 302)
        intent_url = response['Location']
        self.assertIn('intent:0,0?q=-7.960000%2C112.620000#Intent;', intent_url)
        self.assertIn('scheme=geo;package=com.google.android.apps.maps;', intent_url)
        fallback = intent_url.split('S.browser_fallback_url=', 1)[1].removesuffix(';end')
        self.assertEqual(unquote(fallback), f'https://testserver{map_url}?buka=pilih')

        page = self.client.get(f'{map_url}?buka=pilih', secure=True, **mobile)
        self.assertContains(page, 'Buka aplikasi Google Maps')
        self.assertContains(page, 'Lihat di browser')
        self.assertContains(page, 'https%3A%2F%2Fwww.google.com%2Fmaps%2Fsearch%2F')
        self.assertIn('no-store', page['Cache-Control'])

    @override_settings(ERP_PUSH_PUBLIC_KEY='public', ERP_PUSH_PRIVATE_KEY='private', ERP_PUSH_SUBJECT='https://erp.example.com')
    def test_subscription_requires_owner_and_csrf(self):
        client = Client(enforce_csrf_checks=True)
        client.force_login(self.owner)
        url = reverse('attendance_push_subscription')
        data = {
            'endpoint': 'https://fcm.googleapis.com/fcm/send/test-device',
            'keys': {
                'p256dh': base64.urlsafe_b64encode(b'\x04' + b'1' * 64).decode(),
                'auth': base64.urlsafe_b64encode(b'2' * 16).decode(),
            },
        }
        self.assertEqual(client.post(url, json.dumps(data), content_type='application/json').status_code, 403)
        client.get(reverse('attendance_notifications'))
        token = client.cookies['csrftoken'].value

        def save(payload):
            return client.post(url, json.dumps(payload), content_type='application/json', HTTP_X_CSRFTOKEN=token)

        self.assertEqual(save({**data, 'endpoint': 'https://example.com/push'}).status_code, 400)
        self.assertEqual(save(data).status_code, 200)
        self.assertEqual(save(data).status_code, 200)
        self.assertEqual(AttendancePushSubscription.objects.get().user, self.owner)
        self.assertEqual(save({'endpoint': data['endpoint'], 'remove': True}).status_code, 200)
        self.assertFalse(AttendancePushSubscription.objects.exists())
