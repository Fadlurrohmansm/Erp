from django import forms
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden
from django.shortcuts import redirect, render
from django.urls import reverse

from tenancy.models import Branch, PUNCTUALITY_WEEKDAY_FIELDS


def is_punctual(check_in, cutoff):
    """The exact cutoff is included. Time is stored at one-second precision."""
    return check_in.replace(microsecond=0) <= cutoff


class AttendanceCutoffForm(forms.ModelForm):
    class Meta:
        model = Branch
        fields = ('punctuality_cutoff', *PUNCTUALITY_WEEKDAY_FIELDS)
        labels = {'punctuality_cutoff': 'Batas hadir standar'}
        widgets = {field: forms.TimeInput(format='%H:%M', attrs={'type': 'time'}) for field in fields}
        help_texts = {
            'punctuality_cutoff': 'Kosongkan untuk menonaktifkan penilaian otomatis pada hari tanpa jam khusus.',
        }

    def clean(self):
        cleaned_data = super().clean()
        for field in self.Meta.fields:
            cutoff = cleaned_data.get(field)
            if cutoff is not None:
                cleaned_data[field] = cutoff.replace(second=0, microsecond=0)
        return cleaned_data

    def save(self, commit=True):
        branch = super().save(commit=False)
        if commit and self.changed_data:
            branch.save(update_fields=self.changed_data)
        return branch


@login_required
def attendance_cutoff(request):
    if not request.user.is_superuser:
        return HttpResponseForbidden('Hanya owner yang dapat mengubah batas hadir.')

    branch = request.branch
    form = AttendanceCutoffForm(request.POST if request.method == 'POST' else None, instance=branch)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, f'Batas hadir cabang {branch.name} diperbarui.')
        return redirect('attendance_list')

    return render(request, 'core/generic_form.html', {
        'form': form,
        'page_title': f'Batas hadir · {branch.name}',
        'back_url': reverse('attendance_list'),
        'description': 'Isi jam khusus dalam WIB untuk hari dengan jadwal berbeda. Jika jam suatu hari kosong, batas standar berlaku. Absen tepat pada batas jam masih mendapat bonus.',
    })
