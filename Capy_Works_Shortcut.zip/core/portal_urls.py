from django.urls import path

from . import portal_views as views
from . import portal_pwa

app_name = 'employee_portal'

urlpatterns = [
    path('manifest.webmanifest', portal_pwa.manifest, name='manifest'),
    path('service-worker.js', portal_pwa.service_worker, name='service_worker'),
    path('', views.home, name='home'),
    path('masuk/', views.PortalLoginView.as_view(), name='login'),
    path('absen/', views.check_in, name='check_in'),
    path('keluar/', views.PortalLogoutView.as_view(), name='logout'),
    path('kelola/', views.manage_accounts, name='manage'),
    path('kelola/<int:account_id>/kata-sandi/', views.reset_password, name='reset_password'),
    path('kelola/<int:account_id>/status/', views.set_account_status, name='set_status'),
]
