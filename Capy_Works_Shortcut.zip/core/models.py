from tenancy.models import BranchScopedModel
from .employee_scope import EmployeeManager,AttendanceManager

from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from django.core.exceptions import ValidationError


class JobRole(BranchScopedModel):
    name = models.CharField('Nama jabatan', max_length=50)
    pay_scheme = models.CharField('Sistem gaji', max_length=10, choices=[('monthly','Bulanan'),('daily','Harian')], default='monthly')
    base_salary = models.DecimalField('Gaji pokok bulanan (Rp)', max_digits=12, decimal_places=2, default=0, validators=[MinValueValidator(0)])
    daily_rate = models.DecimalField('Gaji per hari hadir (Rp)', max_digits=12, decimal_places=2, default=0, validators=[MinValueValidator(0)])
    class Meta:
        ordering = ['name']
        constraints=[models.UniqueConstraint(fields=['branch','name'],name='branch_role_name')]
    def __str__(self):
        return self.name


class Employee(BranchScopedModel):
    objects=EmployeeManager()
    role = models.ForeignKey(JobRole, null=True, blank=True, on_delete=models.SET_NULL, verbose_name='Jabatan & aturan gaji')
    pay_scheme = models.CharField(max_length=10, choices=[('monthly','Bulanan'),('daily','Harian')], default='monthly')
    daily_rate = models.DecimalField(max_digits=12, decimal_places=2, default=0, validators=[MinValueValidator(0)])

    STATUS_CHOICES = [
        ("active", "Active"),
        ("inactive", "Inactive"),
    ]

    employee_code = models.CharField(
        max_length=20,
        verbose_name="Employee Code"
    )
    full_name = models.CharField(
        max_length=100,
        verbose_name="Full Name"
    )
    phone = models.CharField(
        max_length=20,
        blank=True,
        verbose_name="Phone Number"
    )
    position = models.CharField(
        max_length=50,
        verbose_name="Position"
    )
    hire_date = models.DateField(
        verbose_name="Hire Date"
    )
    base_salary = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=0,
        validators=[MinValueValidator(0)],
        verbose_name="Base Salary (IDR)"
    )
    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default="active",
        verbose_name="Employment Status"
    )
    notes = models.TextField(
        blank=True,
        verbose_name="Notes"
    )
    monthly_leave_quota = models.PositiveSmallIntegerField(default=2, validators=[MaxValueValidator(31)], verbose_name="Jatah libur per bulan")
    fuel_allowance = models.DecimalField(max_digits=12, decimal_places=2, default=0, validators=[MinValueValidator(0)], verbose_name="Uang bensin bulanan")
    punctual_bonus_per_day = models.DecimalField(max_digits=10, decimal_places=2, default=10000, validators=[MinValueValidator(0)], verbose_name="Bonus tepat waktu per hari")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["full_name"]
        constraints=[models.UniqueConstraint(fields=['branch','employee_code'],name='branch_employee_code')]
        verbose_name = "Employee"
        verbose_name_plural = "Employees"

    @property
    def tenure(self):
        from django.utils import timezone
        from calendar import monthrange
        today=timezone.localdate()
        start=self.hire_date
        if start>today:
            return 'Belum mulai bekerja'
        months=(today.year-start.year)*12+today.month-start.month
        def anniversary(n):
            y,m=divmod(start.year*12+start.month-1+n,12)
            return start.replace(year=y,month=m+1,day=min(start.day,monthrange(y,m+1)[1]))
        if anniversary(months)>today:
            months-=1
        days=(today-anniversary(months)).days
        years,months=divmod(months,12)
        parts=[]
        if years:parts.append(f'{years} tahun')
        if months:parts.append(f'{months} bulan')
        if days or not parts:parts.append(f'{days} hari')
        return ' '.join(parts)

    def __str__(self):
        return f"{self.employee_code} - {self.full_name}"



class Attendance(BranchScopedModel):
    objects=AttendanceManager()

    def save(self,*args,**kwargs):
        self.branch_id=self.employee.branch_id
        if kwargs.get('update_fields') is not None:kwargs['update_fields']=set(kwargs['update_fields'])|{'branch'}
        return super().save(*args,**kwargs)

    work_branch = models.ForeignKey('tenancy.Branch',null=True,blank=True,on_delete=models.PROTECT,related_name='work_attendances',verbose_name='Cabang bertugas')

    @property
    def work_branch_name(self):
        return str(self.work_branch or self.branch)

    STATUS_CHOICES = [
        ("present", "Masuk"),
        ("late", "Masuk (terlambat - data lama)"),
        ("leave", "Izin"),
        ("off", "Libur Jatah"),
        ("sick", "Sakit"),
        ("absent", "Tidak Hadir"),
    ]

    PUNCTUAL_CHOICES = [
        (True, "Ya"),
        (False, "Tidak"),
    ]

    employee = models.ForeignKey(
        Employee,
        on_delete=models.PROTECT,
        related_name="attendance_records",
    )
    date = models.DateField()

    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default="present",
    )

    punctual = models.BooleanField(
        default=False,
        choices=PUNCTUAL_CHOICES,
    )

    check_in = models.TimeField(null=True, blank=True)
    check_out = models.TimeField(null=True, blank=True)
    notes = models.CharField(max_length=255, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-date", "employee__full_name"]
        constraints = [
            models.UniqueConstraint(
                fields=["employee", "date"],
                name="unique_employee_attendance_per_day",
            )
        ]

    def __str__(self):
        return f"{self.employee.full_name} - {self.date}"

    def clean(self):
        super().clean()
        if self.status != "present":
            self.punctual = False
        if self.status not in ("present", "late") and (self.check_in or self.check_out):
            raise ValidationError("Jam masuk/pulang hanya boleh diisi untuk hari masuk.")
        if self.check_in and self.check_out and self.check_out <= self.check_in:
            raise ValidationError("Jam pulang harus setelah jam masuk pada hari yang sama.")
        if self.employee_id and self.date and self.date < self.employee.hire_date:
            raise ValidationError("Tanggal absensi tidak boleh sebelum tanggal mulai kerja.")

class Payroll(BranchScopedModel):
    @property
    def active_payment(self):
        return next((payment for payment in self.payments.all() if not payment.voided),None)

    automatic_deduction=models.DecimalField(max_digits=12,decimal_places=2,default=0,validators=[MinValueValidator(0)])
    deduction_details=models.JSONField(default=list,blank=True)
    deduction_policy=models.JSONField(default=dict,blank=True)
    work_branches=models.JSONField(default=list,blank=True)

    @property
    def deduction_groups(self):
        from decimal import Decimal
        groups={}
        for row in self.deduction_details:
            group=groups.setdefault(row['status'],{'label':row['label'],'days':0,'amount':Decimal(0)})
            group['days']+=1;group['amount']+=Decimal(row['amount'])
        return list(groups.values())

    @property
    def branch_work_rows(self):
        if self.work_branches:return self.work_branches
        from .payroll_calculation import branch_work_summary
        return branch_work_summary(self)

    deduction_note = models.CharField("Catatan potongan", max_length=255, blank=True)
    start_date = models.DateField('Dari tanggal', null=True, blank=True)
    end_date = models.DateField('Sampai tanggal', null=True, blank=True)
    pay_scheme = models.CharField(max_length=10, default='monthly')
    daily_rate = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    role_name = models.CharField(max_length=50, blank=True)
    monthly_salary_rate = models.DecimalField(max_digits=12, decimal_places=2, default=0)

    MONTH_CHOICES = [
        (1, "Januari"),
        (2, "Februari"),
        (3, "Maret"),
        (4, "April"),
        (5, "Mei"),
        (6, "Juni"),
        (7, "Juli"),
        (8, "Agustus"),
        (9, "September"),
        (10, "Oktober"),
        (11, "November"),
        (12, "Desember"),
    ]

    employee = models.ForeignKey(
        Employee,
        on_delete=models.PROTECT,
        related_name="payroll_records",
    )

    month = models.PositiveSmallIntegerField(
        choices=MONTH_CHOICES
    )
    year = models.PositiveSmallIntegerField()

    # Snapshot gaji saat payroll dibuat
    base_salary = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=0,
    )

    fuel_allowance = models.DecimalField(max_digits=12, decimal_places=2, default=0, validators=[MinValueValidator(0)])
    monthly_leave_quota = models.PositiveSmallIntegerField(default=0)
    off_days = models.PositiveIntegerField(default=0)
    sick_days = models.PositiveIntegerField(default=0)
    present_days = models.PositiveIntegerField(default=0)
    late_days = models.PositiveIntegerField(default=0)
    absent_days = models.PositiveIntegerField(default=0)
    leave_days = models.PositiveIntegerField(default=0)
    punctual_days = models.PositiveIntegerField(default=0)

    punctual_bonus_per_day = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=10000,
    )

    manual_deduction = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=0,
    )

    notes = models.CharField(max_length=255, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-year", "-month", "employee__full_name"]
        constraints = [
            models.UniqueConstraint(
                fields=["employee", "month", "year"],
                name="unique_employee_payroll_period",
                condition=models.Q(start_date__isnull=True),
            ),
            models.UniqueConstraint(fields=['employee','start_date','end_date'], condition=models.Q(start_date__isnull=False), name='unique_employee_payroll_date_range'),
            models.CheckConstraint(condition=(models.Q(start_date__isnull=True,end_date__isnull=True) | models.Q(start_date__isnull=False,end_date__isnull=False,start_date__lte=models.F('end_date'))), name='payroll_valid_date_range'),
        ]

    @property
    def period_bounds(self):
        import calendar
        from datetime import date
        return (self.start_date, self.end_date) if self.start_date and self.end_date else (date(self.year,self.month,1),date(self.year,self.month,calendar.monthrange(self.year,self.month)[1]))

    @property
    def period_label(self):
        if self.start_date and self.end_date:
            return f'{self.start_date:%d/%m/%Y} - {self.end_date:%d/%m/%Y}'
        return f'{self.get_month_display()} {self.year}'

    @property
    def quota_used_days(self):
        return self.off_days+self.leave_days+self.sick_days if self.deduction_policy.get('quota_mode')=='shared' else self.off_days

    @property
    def excess_off_days(self):
        return max(0, self.quota_used_days - self.monthly_leave_quota)

    @property
    def punctual_bonus(self):
        return self.punctual_bonus_per_day * self.punctual_days

    @property
    def manual_bonus(self):
        if not self.pk:
            return 0
        return sum((item.amount for item in self.extras.all()), 0)

    @property
    def payable_base_salary(self):
        from decimal import Decimal, ROUND_CEILING
        return (Decimal(self.base_salary)/1000).quantize(Decimal('1'),rounding=ROUND_CEILING)*1000 if self.pay_scheme == 'monthly' else self.base_salary

    @property
    def deduction_label(self):
        return self.deduction_note.strip() or 'Potongan'

    @property
    def net_salary(self):
        return (
            self.payable_base_salary
            + self.fuel_allowance
            + self.punctual_bonus
            + self.manual_bonus
            - self.manual_deduction
            - self.automatic_deduction
        )

    def __str__(self):
        return (
            f"{self.employee.full_name} - "
            f"{self.month}/{self.year}"
        )

class PayrollExtra(BranchScopedModel):
    payroll = models.ForeignKey(Payroll, related_name='extras', on_delete=models.CASCADE)
    description = models.CharField('Catatan bonus / tunjangan', max_length=255)
    amount = models.DecimalField('Nominal (Rp)', max_digits=12, decimal_places=2, validators=[MinValueValidator(0.01)])
    class Meta:
        ordering = ['id']
        constraints = [models.CheckConstraint(condition=models.Q(amount__gt=0), name='payroll_extra_positive')]


class SlipLayout(models.Model):
    show_work_branches=models.BooleanField("Cabang kerja dan jumlah hari",default=True)
    title = models.CharField('Judul slip',max_length=80,default='SLIP GAJI KARYAWAN')
    show_employee_code = models.BooleanField('Kode karyawan',default=True)
    show_position = models.BooleanField('Jabatan / sistem gaji',default=True)
    show_base_salary = models.BooleanField('Gaji pokok / gaji harian',default=True)
    show_fuel = models.BooleanField('Uang bensin',default=True)
    show_punctual_bonus = models.BooleanField('Bonus tepat waktu',default=True)
    show_extras = models.BooleanField('Rincian bonus / tunjangan manual',default=True)
    show_deduction = models.BooleanField('Potongan beserta catatannya',default=True)
    show_attendance = models.BooleanField('Rekap absensi dan libur',default=True)
    show_rate_details = models.BooleanField('Rincian jumlah hari dan tarif pada komponen gaji',default=True)
    show_notes = models.BooleanField('Catatan slip',default=True)
    show_footer = models.BooleanField('Catatan penutup',default=True)
    footer = models.CharField('Isi catatan penutup',max_length=500,blank=True,default='Uang makan disediakan dalam bentuk makanan, bukan uang tunai.')
    def save(self,*args,**kwargs):
        self.pk=1
        return super().save(*args,**kwargs)


class PayrollDeductionPolicy(BranchScopedModel):
    quota_mode=models.CharField('Aturan jatah libur',max_length=10,choices=[('shared','Jatah gabungan: libur + izin + sakit'),('separate','Terpisah: jatah hanya untuk Libur Jatah')],default='shared',help_text='Gabungan: jumlah hari Libur Jatah, Izin dan Sakit memakai kuota bulanan yang sama; hanya hari setelah kuota habis yang dipotong. Atur jumlah kuota di Edit karyawan. Tidak hadir tetap mengikuti pilihan tersendiri.')
    enabled=models.BooleanField('Aktifkan potongan absensi otomatis',default=False)
    deduct_leave=models.BooleanField('Potong izin per hari',default=True)
    deduct_sick=models.BooleanField('Potong sakit per hari',default=False)
    deduct_absent=models.BooleanField('Potong tidak hadir per hari',default=True)
    deduct_excess_off=models.BooleanField('Potong libur melebihi jatah bulanan',default=True)
    daily_amount=models.DecimalField('Nominal potongan per hari (Rp)',max_digits=12,decimal_places=2,default=0,validators=[MinValueValidator(0)],help_text='0 = gaji pokok bulanan dibagi jumlah hari kalender bulan tanggal absensi. Isi nominal untuk tarif tetap per hari.')
    class Meta:
        constraints=[models.UniqueConstraint(fields=['branch'],name='one_payroll_deduction_policy_branch')]


class PayrollPayment(BranchScopedModel):
    payroll=models.ForeignKey(Payroll,on_delete=models.PROTECT,related_name='payments')
    paid_date=models.DateField('Tanggal pembayaran')
    amount=models.DecimalField('Nominal dibayar',max_digits=14,decimal_places=2,validators=[MinValueValidator(0)])
    employee_name=models.CharField(max_length=100)
    period_label=models.CharField(max_length=80)
    notes=models.CharField('Catatan pembayaran',max_length=255,blank=True)
    created_by=models.ForeignKey('auth.User',on_delete=models.PROTECT,related_name='salary_payments_recorded')
    created_at=models.DateTimeField(auto_now_add=True)
    voided=models.BooleanField(default=False)
    void_reason=models.CharField(max_length=255,blank=True)
    voided_at=models.DateTimeField(null=True,blank=True)
    class Meta:
        ordering=['-paid_date','-id']
        constraints=[models.UniqueConstraint(fields=['payroll'],condition=models.Q(voided=False),name='one_active_payment_per_payroll'),models.CheckConstraint(condition=models.Q(amount__gt=0),name='payroll_payment_positive_amount')]


class EmployeeBranchAccess(models.Model):
    employee=models.ForeignKey(Employee,on_delete=models.CASCADE,related_name='branch_accesses')
    branch=models.ForeignKey('tenancy.Branch',on_delete=models.CASCADE,related_name='shared_employee_accesses')
    created_at=models.DateTimeField(auto_now_add=True)
    class Meta:
        constraints=[models.UniqueConstraint(fields=['employee','branch'],name='unique_shared_employee_branch')]


from .portal_models import AttendancePushSubscription, EmployeeCheckIn, EmployeePortalAccount
