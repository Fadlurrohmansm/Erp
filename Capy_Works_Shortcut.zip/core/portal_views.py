from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import SetPasswordForm
from django.contrib.auth.views import LoginView, LogoutView
from django.db import IntegrityError, transaction
from django.db.models import Count, Q
from django.http import HttpResponseForbidden
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse, reverse_lazy
from django.utils import timezone
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_http_methods, require_POST

from .attendance_notifications import notify_attendance_owner
from .attendance_rules import is_punctual
from .check_in_device import device_label
from .forms import DeleteConfirmationForm
from .models import Attendance, Employee
from .portal_forms import CheckInLocationForm, CreatePortalAccountForm, PortalLoginForm
from .portal_models import EmployeeCheckIn, EmployeePortalAccount


class PortalLoginView(LoginView):
    template_name = 'core/portal/login.html'
    authentication_form = PortalLoginForm

    def get_success_url(self):
        return reverse('employee_portal:home')

    def get(self, request, *args, **kwargs):
        if request.portal_account and request.portal_account.employee.status == 'active':
            return redirect('employee_portal:home')
        return super().get(request, *args, **kwargs)


class PortalLogoutView(LogoutView):
    next_page = reverse_lazy('employee_portal:login')


def _attendance(employee_id, day):
    return Attendance._base_manager.filter(employee_id=employee_id, date=day)


@never_cache
@login_required(login_url='employee_portal:login')
def home(request):
    account = request.portal_account
    if not account:
        return redirect('employee_portal:login')

    employee = account.employee
    today = timezone.localdate()
    record = _attendance(employee.pk, today).select_related('portal_check_in', 'work_branch').first()
    check_in = getattr(record, 'portal_check_in', None)
    branch = record.work_branch if record and record.work_branch_id else employee.branch
    cutoff = check_in.punctuality_cutoff if check_in else branch.punctuality_cutoff_for(today)
    attendance_totals = Attendance._base_manager.filter(
        employee_id=employee.pk, date__range=(employee.hire_date, today),
    ).aggregate(
        present=Count('pk', filter=Q(status__in=('present', 'late'))),
        not_present=Count('pk', filter=Q(status__in=('off', 'sick', 'leave'))),
    )
    unavailable = None
    if employee.status != 'active':
        unavailable = 'Akun karyawan tidak aktif. Hubungi owner.'
    elif employee.hire_date > today:
        unavailable = 'Absensi tersedia mulai tanggal mulai kerja.'
    elif record and record.status not in ('present', 'late'):
        unavailable = f'Status hari ini: {record.get_status_display()}. Hubungi owner jika perlu dikoreksi.'

    response = render(request, 'core/portal/home.html', {
        'employee': employee,
        'today': today,
        'record': record,
        'check_in': check_in,
        'cutoff': cutoff,
        'unavailable': unavailable,
        'attendance_totals': attendance_totals,
    })
    response['Permissions-Policy'] = 'geolocation=(self)'
    return response


@require_POST
@login_required(login_url='employee_portal:login')
def check_in(request):
    account = request.portal_account
    if not account:
        return HttpResponseForbidden('Gunakan akun portal karyawan untuk absen.')

    location = CheckInLocationForm(request.POST)
    if not location.is_valid():
        messages.error(request, 'Lokasi belum dapat dibaca. Aktifkan izin lokasi, lalu coba lagi.')
        return redirect('employee_portal:home')

    with transaction.atomic():
        # The owner attendance editor takes the same employee row lock.
        employee = Employee._base_manager.select_for_update().get(pk=account.employee_id)
        instant = timezone.now()
        local = timezone.localtime(instant)
        day = local.date()
        if employee.status != 'active' or employee.hire_date > day:
            messages.error(request, 'Absensi belum tersedia untuk akun ini.')
            return redirect('employee_portal:home')

        record = _attendance(employee.pk, day).select_related('portal_check_in').first()
        if record and (record.check_in or getattr(record, 'portal_check_in', None)):
            messages.info(request, 'Jam masuk hari ini sudah tercatat.')
            return redirect('employee_portal:home')
        if record and record.status not in ('present', 'late'):
            messages.error(request, 'Status absensi hari ini sudah ditentukan. Hubungi owner untuk mengoreksinya.')
            return redirect('employee_portal:home')
        if record and record.check_out and local.time() >= record.check_out:
            messages.error(request, 'Jam pulang sudah tercatat. Hubungi owner untuk mengoreksi jam masuk.')
            return redirect('employee_portal:home')

        previous_punctual = record.punctual if record else None
        if record is None:
            record = Attendance(
                employee=employee, branch_id=employee.branch_id, work_branch_id=employee.branch_id,
                date=day, status='present',
            )
        else:
            record.employee = employee
        record.check_in = local.time().replace(microsecond=0)
        branch = record.work_branch if record.work_branch_id else employee.branch
        cutoff = branch.punctuality_cutoff_for(day)
        record.punctual = (
            cutoff is not None
            and record.status == 'present'
            and is_punctual(record.check_in, cutoff)
        )
        if record.pk:
            record.save(update_fields=('check_in', 'punctual'))
        else:
            record.save()
        check_in = EmployeeCheckIn.objects.create(
            attendance=record,
            account=account,
            recorded_at=instant,
            punctuality_cutoff=cutoff,
            previous_punctual=previous_punctual,
            device_label=device_label(request),
            **location.cleaned_data,
        )
        transaction.on_commit(lambda: notify_attendance_owner(check_in.pk, check_in.device_label), robust=True)

    messages.success(request, 'Absensi berhasil. Jam masuk dan lokasi sudah tercatat.')
    return redirect('employee_portal:home')


@login_required
@require_http_methods(['GET', 'POST'])
def delete_check_in(request, check_in_id):
    if not request.user.is_superuser:
        return HttpResponseForbidden('Hanya owner yang dapat menghapus absen mandiri.')

    check_ins = EmployeeCheckIn.objects.filter(
        attendance_id__in=Attendance.objects.order_by().values('pk'),
    ).select_related('attendance__employee')
    check_in = get_object_or_404(check_ins, pk=check_in_id)
    record = check_in.attendance
    back_url = reverse('attendance_list', query={
        'month': record.date.strftime('%Y-%m'),
        'employee': record.employee_id,
        'day': record.date.day,
    })
    form = DeleteConfirmationForm(request.POST if request.method == 'POST' else None)
    if request.method == 'POST' and form.is_valid():
        with transaction.atomic():
            get_object_or_404(Employee._base_manager.select_for_update(), pk=record.employee_id)
            check_in = get_object_or_404(check_ins, pk=check_in_id)
            record = check_in.attendance
            portal_time = timezone.localtime(check_in.recorded_at).time().replace(microsecond=0)
            same_time = record.check_in == portal_time
            # Check-in timestamps precede creation of rows first written by the portal.
            if (
                check_in.previous_punctual is None
                and record.created_at >= check_in.recorded_at
                and same_time
                and record.status == 'present'
                and not record.notes
                and record.check_out is None
                and record.work_branch_id == record.branch_id
            ):
                record.delete()
            else:
                check_in.delete()
                if same_time:
                    record.check_in = None
                    fields = ['check_in']
                    if check_in.previous_punctual is not None or check_in.punctuality_cutoff is not None:
                        record.punctual = bool(check_in.previous_punctual)
                        fields.append('punctual')
                    record.save(update_fields=fields)
        messages.success(request, 'Absen mandiri berhasil dihapus.')
        return redirect(back_url)

    return render(request, 'core/delete_confirm.html', {
        'form': form,
        'page_title': 'Hapus absen mandiri',
        'object_name': f'{record.employee.full_name} · {record.date:%d/%m/%Y}',
        'description': 'Jam masuk dan lokasi dari portal akan dihapus. Catatan harian yang hanya berisi absen mandiri juga akan dihapus.',
        'back_url': back_url,
    })


@login_required
def manage_accounts(request):
    if not request.user.is_superuser:
        return HttpResponseForbidden('Hanya owner yang dapat mengelola akun karyawan.')

    form = CreatePortalAccountForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        try:
            with transaction.atomic():
                employee = Employee._base_manager.select_for_update().get(pk=form.cleaned_data['employee'].pk)
                if employee.status != 'active' or EmployeePortalAccount.objects.filter(employee=employee).exists():
                    form.add_error('employee', 'Karyawan sudah memiliki akun atau sudah tidak aktif.')
                else:
                    user = form.save(commit=False)
                    user.first_name = employee.full_name
                    user.is_staff = False
                    user.is_superuser = False
                    user.save()
                    EmployeePortalAccount.objects.create(user=user, employee=employee)
        except IntegrityError:
            form.add_error(None, 'Akun sudah dibuat atau nama pengguna sudah dipakai. Periksa daftar akun.')
        else:
            if not form.errors:
                messages.success(request, 'Akun portal karyawan dibuat.')
                return redirect('employee_portal:manage')

    accounts = EmployeePortalAccount.objects.select_related('user', 'employee__branch').order_by('employee__full_name')
    return render(request, 'core/portal/manage.html', {'form': form, 'accounts': accounts})


@login_required
def reset_password(request, account_id):
    if not request.user.is_superuser:
        return HttpResponseForbidden('Hanya owner yang dapat mengelola akun karyawan.')
    account = get_object_or_404(EmployeePortalAccount.objects.select_related('user'), pk=account_id)
    form = SetPasswordForm(account.user, request.POST or None)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, 'Kata sandi akun karyawan diperbarui.')
        return redirect('employee_portal:manage')
    return render(request, 'core/generic_form.html', {
        'form': form, 'page_title': f'Atur kata sandi akun {account.user.username}',
        'back_url': reverse('employee_portal:manage'),
    })


@require_POST
@login_required
def set_account_status(request, account_id):
    if not request.user.is_superuser:
        return HttpResponseForbidden('Hanya owner yang dapat mengelola akun karyawan.')
    account = get_object_or_404(EmployeePortalAccount.objects.select_related('user', 'employee'), pk=account_id)
    status = request.POST.get('status')
    if status == 'inactive' or (status == 'active' and account.employee.status == 'active'):
        user = account.user
        user.is_active = status == 'active'
        user.save(update_fields=('is_active',))
        messages.success(request, 'Status akun portal diperbarui.')
    else:
        messages.error(request, 'Aktifkan data karyawan terlebih dahulu.')
    return redirect('employee_portal:manage')
