from django.conf import settings
from django.contrib import messages
from django.shortcuts import redirect
from django.views.csrf import csrf_failure as default_csrf_failure
from django.views.decorators.cache import never_cache


@never_cache
def csrf_failure(request, reason=""):
    if request.resolver_match is None or request.resolver_match.view_name != "login":
        return default_csrf_failure(request, reason=reason)

    # A successful login changes the CSRF token used by other open login forms.
    if request.user.is_authenticated:
        return redirect(settings.LOGIN_REDIRECT_URL)

    messages.info(request, "Formulir masuk telah diperbarui. Silakan masukkan ulang nama pengguna dan kata sandi.")
    return redirect("login")
