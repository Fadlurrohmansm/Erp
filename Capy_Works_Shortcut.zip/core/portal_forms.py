from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.core.exceptions import ValidationError

from .models import Employee
from .portal_models import EmployeePortalAccount


class PortalLoginForm(AuthenticationForm):
    username = forms.CharField(
        label='Nama pengguna',
        widget=forms.TextInput(attrs={'autocapitalize': 'none', 'autocomplete': 'username', 'autofocus': True}),
    )
    password = forms.CharField(
        label='Kata sandi', strip=False,
        widget=forms.PasswordInput(attrs={'autocomplete': 'current-password'}),
    )
    error_messages = {
        'invalid_login': 'Nama pengguna atau kata sandi tidak cocok.',
        'inactive': 'Akun ini tidak aktif.',
    }

    def confirm_login_allowed(self, user):
        super().confirm_login_allowed(user)
        if not EmployeePortalAccount.objects.filter(user=user, employee__status='active').exists():
            raise ValidationError(self.error_messages['invalid_login'], code='invalid_login')


class CreatePortalAccountForm(UserCreationForm):
    employee = forms.ModelChoiceField(queryset=Employee._base_manager.none(), label='Karyawan')

    class Meta(UserCreationForm.Meta):
        model = get_user_model()
        fields = ('employee', 'username')
        labels = {'username': 'Nama pengguna'}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['employee'].queryset = (
            Employee._base_manager.filter(status='active', portal_account__isnull=True)
            .select_related('branch').order_by('branch__name', 'full_name')
        )
        self.fields['employee'].label_from_instance = lambda employee: (
            f'{employee.full_name} · {employee.branch.name}'
        )
        self.order_fields(['employee', 'username', 'password1', 'password2'])


class CheckInLocationForm(forms.Form):
    latitude = forms.DecimalField(min_value=-90, max_value=90, max_digits=9, decimal_places=6)
    longitude = forms.DecimalField(min_value=-180, max_value=180, max_digits=9, decimal_places=6)
    accuracy = forms.DecimalField(min_value=0, max_digits=9, decimal_places=2)
