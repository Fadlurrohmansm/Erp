from django.contrib.auth import get_user_model
from django.test import Client, TestCase
from django.urls import reverse


class LoginCSRFRecoveryTests(TestCase):
    def setUp(self):
        self.client = Client(enforce_csrf_checks=True)
        self.url = reverse("login")

    def test_stale_second_login_post_returns_signed_in_user_to_dashboard(self):
        get_user_model().objects.create_user("operator", password="OperatorFixture!832")
        self.client.get(self.url)
        token = self.client.cookies["csrftoken"].value
        form = {
            "csrfmiddlewaretoken": token,
            "username": "operator",
            "password": "OperatorFixture!832",
        }

        self.assertRedirects(self.client.post(self.url, form), "/", fetch_redirect_response=False)
        self.assertNotEqual(token, self.client.cookies["csrftoken"].value)
        self.assertRedirects(self.client.post(self.url, form), "/", fetch_redirect_response=False)

    def test_anonymous_login_with_expired_form_gets_a_fresh_form(self):
        response = self.client.post(self.url, follow=True)
        self.assertEqual(response.redirect_chain, [(self.url, 302)])
        self.assertContains(response, "Formulir masuk telah diperbarui.")
        self.assertIn("csrftoken", self.client.cookies)

    def test_other_csrf_failures_still_return_forbidden(self):
        response = self.client.post(reverse("account_password_change"))
        self.assertEqual(response.status_code, 403)
